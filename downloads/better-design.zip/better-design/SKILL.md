---
name: better-design
description: Guide de reference pour concevoir, auditer ou corriger un site web sans tomber dans les patterns visuels generiques produits par IA. Version hyper-v3, refondue pour etre plus credible, plus operable, plus nuancee, et plus utile en execution. Basee sur des patterns observables publiquement sur des SaaS de reference, puis transformee en systeme de decision, pas en liste de gouts arbitraires.
user-invocable: true
argument-hint: "[create|audit|fix] [url-or-file]"
---

# Anti-Claude Web Design — Hyper V3

## Positionnement

Ce document n'est pas un manifeste du "bon gout" universel.
Ce n'est pas non plus une copie des sites celebres du moment.

C'est un **systeme anti-generique** pour eviter les patterns les plus reconnaissables des sorties IA en frontend/UI, tout en donnant une methode plus fiable pour construire un site web qui parait concu, pas assemble.

La V2 etait forte comme liste d'interdits.
La Hyper V3 ajoute trois choses qui manquaient :

1. **Une meilleure hierarchie des regles**
   - regles dures
   - preferences fortes
   - patterns contextuels

2. **Une meilleure lecture des sections et des fonds**
   - quel type de section sert a quoi
   - quel type de fond lui convient
   - quelle matiere visuelle doit porter la section

3. **Une meilleure portee**
   - moins de dogmes absolus
   - plus de decisions conditionnelles
   - plus de correspondance marque / produit / page / audience

---

# PARTIE 0 — LA THESE CENTRALE

Le probleme principal des interfaces generees par IA n'est pas seulement la couleur, la police ou le bouton.

Le vrai probleme est le suivant :

> **Tout parait decide par defaut. Rien ne parait choisi.**

Les sorties IA ont generalement :
- le meme hero vertical
- la meme densite partout
- le meme fond sur toutes les sections
- la meme carte repetee 6 fois
- la meme accent color sur tous les objets
- la meme animation fade-in partout
- la meme structure de CTA
- la meme typographie moyenne partout

Un site fort ne gagne pas par accumulation d'effets.
Il gagne par :
- **choix de la bonne matiere visuelle**
- **construction differenciee des sections**
- **rythme**
- **hierarchie**
- **coherence marque-produit**

Formule operative Hyper V3 :

**Qualite percue = Coherence + Rythme + Matiere + Specificite - Defaults visibles**

---

# PARTIE 1 — LES 3 NIVEAUX DE REGLES

## 1.1 Regles dures

Ce sont les regles qui sont presque toujours vraies.
Si elles sont violees, le site parait rapidement generique, amateur ou purement IA.

### Regles dures

1. **Ne pas utiliser les couleurs Tailwind par defaut comme identite de marque.**
   `blue-500`, `purple-600`, `green-500` directement en accent global = signal de prototype.

2. **Ne pas appliquer le meme layout sur toutes les sections.**
   Hero centre + 5 sections centre + 3 grilles identiques = monotonie immediate.

3. **Ne pas utiliser le meme fond sur toute la page.**
   Une landing forte a besoin d'au moins 3 a 5 atmospheres visuelles distinctes.

4. **Ne pas mettre du monospace hors contexte.**
   Le mono sert a la donnee, au code, au prix, a la metadata technique, aux raccourcis clavier. Pas au corps de texte.

5. **Ne pas tout encapsuler dans des cards.**
   La card est un format. Pas un systeme universel.

6. **Ne pas utiliser un seul niveau de typographie.**
   Si tout est en 400/500 et avec des tailles trop proches, la page s'aplatit.

7. **Ne pas colorer tous les elements avec l'accent principal.**
   L'accent doit etre gere. Pas pulverise sur chaque bordure, prix, icone, badge, shadow, lien et fond.

8. **Ne pas animer tout avec la meme transition.**
   `fade-up 300ms ease` sur tout est le cousin motion du gradient Tailwind.

9. **Ne pas inventer des visuels abstraits quand le produit peut etre montre.**
   Si le produit existe, le produit doit devenir la matiere visuelle principale sur au moins une partie du site.

10. **Ne pas confondre landing, app shell, dashboard, pricing, docs et onboarding.**
    Chaque environnement a ses propres besoins. Une meme logique visuelle ne doit pas tout recouvrir.

## 1.2 Preferences fortes

Ces regles sont valables dans la majorite des cas, mais restent adaptables.

- background teinte plutot que noir ou blanc absolus
- negative tracking sur les titres display
- line-height serre sur les gros titres
- sentence case sur la plupart des CTA
- dual CTA dans la navbar landing quand le produit a un vrai funnel B2B
- variation des radius selon l'objet
- variation du spacing vertical entre sections
- hero plus court que ce que la plupart des outils generent
- sections de transition compactes apres le hero
- preuves concretes mieux que slogans vagues

## 1.3 Patterns contextuels

Ces patterns peuvent etre excellents, mais seulement si le produit ou la marque les justifient.

- stacking cards scroll
- horizontal scroll section
- mega-menu complexe
- background generatif canvas
- hero atmospherique image-led
- avant/apres multi-outils -> plateforme unifiee
- tabs produit avec preview changeante
- gross metrics sans cartes
- paper texture / editorial surfaces
- logo carousel

**Regle cle** :
Un pattern contextuel n'est jamais une obligation.
C'est une technique a degainer si elle renforce la promesse de la section.

---

# PARTIE 2 — LES 12 SIGNATURES QUI FONT "SORTIE IA"

Au lieu d'une liste trop longue d'interdits plats, Hyper V3 regroupe les erreurs selon leurs causes.

## 2.1 Signature #1 — Le site entier est construit avec un seul gabarit

Symptomes :
- tout est centre
- tout a la meme largeur
- tout a le meme fond
- tout a le meme padding
- tout est dans des cartes equivalentes

Correction :
- differencier hero / transition / demonstration / preuve / conversion
- faire varier largeur, densite, alignement, fond, matiere visuelle

## 2.2 Signature #2 — La page est coloree, mais pas dirigee

Symptomes :
- trop de couleurs accent simultanees
- couleurs arbitraires sans relation avec la marque
- overlays gradients partout
- sections sans logique de contraste

Correction :
- une couleur signature
- 1 ou 2 couleurs secondaires maximum
- des fonds construits par familles, pas par impulsion
- l'accent reserve aux points de decision et de tension

## 2.3 Signature #3 — La typographie est lisible, mais sans caractere

Symptomes :
- Inter partout, meme poids, meme tracking
- `text-xs` pour tout le secondaire
- line-height trop detendu sur les titres
- titres trop longs ou trop bavards

Correction :
- 3 a 5 niveaux de poids reellement visibles
- display plus tendu
- body plus calme
- meilleure echelle de tailles
- choix editorial sur la longueur des titres

## 2.4 Signature #4 — Les sections n'ont pas de role clair

Symptomes :
- la preuve sociale est traitee comme une grosse section hero-level
- les features sont toutes au meme niveau
- les captures produit n'ont pas de mise en scene specifique
- le CTA final ne boucle rien

Correction :
- attribuer un role a chaque bloc
- reduire les sections de transition
- construire une progression de densite
- faire du CTA final un echo du hero

## 2.5 Signature #5 — Le produit n'existe pas visuellement

Symptomes :
- illustrations abstraites a la place du produit
- generative glow partout, UI nulle part
- dashboard fictif sans details credibles

Correction :
- montrer le produit
- montrer ses artefacts
- montrer son contexte d'usage
- faire confiance au vrai output du produit

## 2.6 Signature #6 — Le dashboard est dessine comme une landing

Symptomes :
- meme hero style dans l'app
- sidebar trop epaisse ou theatrale
- topbar qui refait de la nav marketing
- cartes enormes et trop respirantes

Correction :
- le dashboard privilegie vitesse, densite, repetition fiable, affordance
- la landing privilegie desir, narration, preuve, conversion

---

# PARTIE 3 — TYPOGRAPHIE : SYSTEME, PAS DECORATION

## 3.1 Ce qu'une bonne typo doit faire

La typo ne sert pas a paraitre "premium" au sens vague.
Elle sert a :
- ordonner la page
- reduire l'ambiguite
- porter la voix de marque
- creer des contrastes nets de densite

## 3.2 Strategie recommandee

### Minimum viable solide
- 1 display font ou une variable font exploitee avec de vrais changements de poids
- 1 body font stable et lisible
- 1 mono uniquement pour les contextes techniques

### Types de combinaisons acceptables

**Option A — SaaS propre et sobre**
- Display: Geist / Plus Jakarta / Instrument Sans / Sora
- Body: Geist / Figtree / Work Sans / Inter bien cadence
- Mono: Geist Mono / IBM Plex Mono / Berkeley Mono / JetBrains Mono

**Option B — B2B editorial ou premium**
- Display: serif discrete ou grotesk plus distinctive
- Body: sans calme et dense
- Mono: reserve a la technique

**Option C — Devtools / engineering**
- Sans nette + mono credible + artefacts code reels

## 3.3 Regles typographiques Hyper V3

### Regles dures
- pas de Montserrat/Poppins comme reflexe par defaut
- pas de mono sur du texte courant
- pas de tracking-widest comme cache-misere visuel
- pas de titres display avec line-height relache
- pas de hierarchie entierement construite sur une seule graisse

### Preferences fortes
- negative tracking sur display
- clamp ou calc fluide sur le hero
- plusieurs poids visibles
- sentence case sur l'essentiel des titres et boutons
- texte secondaire plus sobre, pas juste plus petit

## 3.4 Echelle recommandee

```css
.display-xl { font-size: clamp(2.75rem, 6vw, 5rem); line-height: 1.02; letter-spacing: -0.03em; font-weight: 620; }
.display-lg { font-size: clamp(2rem, 4vw, 3.4rem); line-height: 1.06; letter-spacing: -0.025em; font-weight: 600; }
.heading-xl { font-size: 1.75rem; line-height: 1.12; letter-spacing: -0.02em; font-weight: 600; }
.heading-lg { font-size: 1.375rem; line-height: 1.18; letter-spacing: -0.015em; font-weight: 560; }
.heading-md { font-size: 1.125rem; line-height: 1.24; letter-spacing: -0.01em; font-weight: 540; }
.body-lg    { font-size: 1.0625rem; line-height: 1.5; font-weight: 420; }
.body-md    { font-size: 0.9375rem; line-height: 1.5; font-weight: 420; }
.body-sm    { font-size: 0.875rem; line-height: 1.45; font-weight: 420; }
.caption    { font-size: 0.75rem; line-height: 1.35; font-weight: 440; }
```

## 3.5 Micro-labels, eyebrows, labels de groupe

La V2 etait correcte sur un point : le micro-label decoratif est l'un des patterns IA les plus reconnaissables.

### Donc :
- pas de micro-label systematique au-dessus de chaque h2
- pas de `font-mono uppercase tracking-wide` en deco
- un eyebrow est acceptable s'il porte un vrai sens
- le seul endroit ou un label uppercase discret est souvent legitime : la navigation de dashboard et certains index structuraux

---

# PARTIE 4 — COULEUR, SURFACE, CONTRASTE

## 4.1 Systeme de couleur

La couleur doit d'abord organiser la perception.
Pas simplement "faire beau".

Il faut au minimum :
- 1 background de page
- 1 ou 2 surfaces intermediaires
- 1 surface hover/elevated
- 1 texte primary
- 1 texte secondary
- 1 texte muted
- 1 accent principal
- eventuellement 1 accent secondaire
- 1 danger
- 1 focus

## 4.2 Regles dures

- pas de palette Tailwind par defaut comme palette produit
- pas d'accent identique sur tout
- pas d'ombre coloree ajoutee par automatisme
- pas d'etats bases uniquement sur `opacity`
- pas de pur noir/pur blanc partout si la marque ne le justifie pas explicitement

## 4.3 Preferences fortes

- fond teinte plutot que noir pur
- light theme legerement chaud plutot que blanc clinique
- progression de surfaces nette
- bordures construites comme famille, pas improvisees ligne par ligne

## 4.4 Tokens minimums

```css
:root {
  --bg-base: #0b0f16;
  --bg-surface: #111722;
  --bg-elevated: #171e2c;
  --bg-section-alt: #0e141f;

  --border-primary: rgba(255,255,255,0.07);
  --border-secondary: rgba(255,255,255,0.12);
  --border-focus: rgba(92,124,250,0.5);

  --text-primary: #eef2f7;
  --text-secondary: rgba(238,242,247,0.72);
  --text-muted: rgba(238,242,247,0.46);

  --accent-primary: #5c7cfa;
  --accent-primary-hover: #4d6df0;
  --accent-secondary: #19c39c;
  --accent-danger: #f25f5c;

  --shadow-soft: 0 12px 32px rgba(0,0,0,0.18);
  --shadow-strong: 0 24px 64px rgba(0,0,0,0.24);
}
```

## 4.5 La vraie regle sur les sections colorees

Une section coloree n'est pas une section avec un accent applique au hasard.
C'est une section ou :
- la teinte du fond
- la temperature chromatique
- la matiere visuelle
- la densite du contenu

sont alignees avec son objectif.

---

# PARTIE 5 — LES 6 SYSTEMES DE FOND

C'est l'un des gros ajouts de cette Hyper V3.

Le probleme de beaucoup de sites IA n'est pas qu'ils n'ont pas de fond sophistiqué.
Le probleme est qu'ils ont **le mauvais fond pour la mauvaise section**.

## 5.1 Systeme A — Fond neutre structure par un foyer visuel

### Usage
- hero centré produit/plateforme
- proof section courte
- categories d'usage

### Description
Base sobre + un foyer lumineux ou coloré unique derrière l'element principal.

### Bon pour
- infra
- SaaS technique
- produits a message clair
- pages ou le visuel principal est une UI ou une forme centrale

### A eviter si
- la marque a besoin d'une charge emotionnelle forte
- le produit est editorial, creatif ou culturel

## 5.2 Systeme B — Fond image-led / atmospherique

### Usage
- hero premium
- campagne forte
- pages marque / manifeste
- CTA final miroir du hero

### Description
Une grande image, une scene, une ambiance, un overlay qui sert la lecture.

### Bon pour
- AI premium
- produits a forte narrativite
- produits qui ont besoin d'un imaginaire de marque

### Risque
Si mal gere, cela devient un wallpaper generique de startup AI.

### Regle
Le texte doit rester tres court. Sinon l'image perd sa fonction.

## 5.3 Systeme C — Fond texture / editorial

### Usage
- outils d'ecriture
- note-taking
- creation de contenu
- pages de manifesto ou de longue lecture

### Description
Surface calme, parfois papier, parfois bruit subtile, parfois fond chaud legerement texturé.

### Regle
La texture doit etre perceptible sans devenir un effet visible a elle seule.

## 5.4 Systeme D — Fond surface produit

### Usage
- demo produit
- features avec screenshots
- pricing clair
- onboarding marketing

### Description
Le fond est volontairement secondaire. Il met le produit en valeur au lieu de rivaliser avec lui.

### Regle
Quand le screenshot est fort, le fond doit reculer.

## 5.5 Systeme E — Fond artefact technique

### Usage
- devtools
- APIs
- email infra
- observability
- workflow automation pour engineers

### Description
Le code, le terminal, le wizard, la commande CLI, le README, le diff ou le log deviennent la matiere visuelle.

### Regle
Mieux vaut un vrai artefact de produit qu'une pseudo-illustration technique.

## 5.6 Systeme F — Fond modulaire / couches produit

### Usage
- suite produit
- workspace modulaire
- plateformes multi-cas d'usage
- pages avec plusieurs produits internes

### Description
Le fond et les blocs travaillent ensemble via couches, modules, cartes avant/arriere, profondeur legere.

### Regle
La profondeur doit aider la navigation mentale, pas servir d'effet gratuit.

## 5.7 Regle de decision rapide

### Si ta section montre surtout...
- **une promesse courte** -> Systeme A ou B
- **une UI reelle** -> Systeme D
- **du code / terminal / SDK** -> Systeme E
- **une suite de produits ou modules** -> Systeme F
- **une experience editoriale** -> Systeme C

---

# PARTIE 6 — LES 8 TYPES DE SECTIONS ET LEUR ROLE

## 6.1 Hero

### Rôle
Donner une promesse claire et choisir le ton du site.

### Les 4 modèles dominants
1. centré + produit-led
2. centré ultra-court
3. modulaire suite produit
4. image-led / atmospherique

### Interdits
- hero trop long
- 4 propositions de valeur simultanees
- bouton + bouton + 5 bullets + 3 stats + logo wall dans le meme ecran
- screenshot pose sans mise en scene

### Recette minimale
- promesse claire
- 1 a 2 CTA
- 1 preuve ou benefice concret
- 1 matiere visuelle principale, pas 4

## 6.2 Transition / proof strip

### Rôle
Réduire la friction juste après le hero.

### Formats legitimes
- logo strip compact
- 1 chiffre + 1 preuve
- mini comparison statement
- 3 badges de confiance discrets

### Regle
Cette section doit etre courte. Elle ne doit pas prendre l'ego d'une section hero.

## 6.3 Use cases / categories

### Rôle
Permettre au visiteur de se reconnaitre.

### Formats legitimes
- tabs
- cartes categories
- segmentation par role / equipe / use case
- modules suite produit

### Regle
Une bonne section categories est plus utile qu'une grille generique "Feature 1 2 3".

## 6.4 Feature showcase

### Rôle
Montrer les differences significatives du produit.

### Formats legitimes
- bento asymetrique
- rows alternees texte/visuel
- modules differencies par ambiance
- tabs avec preview

### Regle
Chaque feature importante doit avoir sa propre identite de section, pas juste un autre bloc de texte.

## 6.5 Product demo

### Rôle
Prouver le produit.

### Regles
- screenshot reel ou presque reel
- pas d'overlay gradient inutile
- pas de carte flottante deco sur la capture
- le contexte d'usage est aussi important que l'image elle-meme

## 6.6 Technical proof

### Rôle
Prouver la vitesse, la simplicite ou la credibilite technique.

### Formats legitimes
- code snippet
- commande CLI
- fichier README
- UI technique
- terminal

### Regle
Cette section a plus de force pour un public technique qu'une prose marketing embellie.

## 6.7 Testimonials / case studies

### Rôle
Externaliser la preuve.

### Regles
- privilegier 1 a 3 temoignages forts plutot qu'un carousel anonyme infini
- nom + role + entreprise + visage ou logo quand possible
- une citation doit soit porter un resultat, soit porter un point de vue memorable

## 6.8 Pricing / conversion

### Rôle
Transformer le desir en decision simple.

### Regles
- 2 a 4 plans maximum
- une hierarchie claire
- un plan mis en avant seulement si la logique commerciale est nette
- pas de rainbow de cartes pricing
- prix lisible avant tout

## 6.9 FAQ

### Rôle
Retirer le doute residuel.

### Regles
- pas centre
- pas hero-level
- prose claire
- largeur contenue

## 6.10 CTA final

### Rôle
Boucler la narration.

### Regle capitale
Le CTA final doit faire echo au hero.
Pas le recopier a l'identique, mais reprendre sa logique visuelle ou emotionnelle.

---

# PARTIE 7 — LE VRAI SUJET : LA MATIERE VISUELLE

La plupart des interfaces faibles ont des couleurs et des layouts corrects.
Mais elles n'ont pas de **matiere visuelle distinctive**.

## 7.1 Qu'est-ce que la matiere visuelle

C'est ce qui remplit la section avec quelque chose de credible.

Exemples :
- le vrai produit
- le vrai code
- le vrai document
- le vrai usage
- le vrai artefact de travail
- la vraie photo de marque
- la vraie texture de support

## 7.2 Les 7 matieres visuelles les plus fortes

1. **UI produit reelle**
2. **Artefact technique**
3. **Photo/scene de marque forte**
4. **Module / layer de suite produit**
5. **Document, fichier, note, page, README**
6. **Temoignage avec visage/logo/resultat**
7. **Objet interactif ou calculateur avec vrai sens**

## 7.3 Ce qu'il faut eviter

- blobs abstraits partout
- pseudo-illustrations tech
- mockups trop lisses sans details d'usage
- dashboards fake sans nom, sans donnee, sans contexte
- memes icones 3D ou gradients "futuristes" comme unique support visuel

## 7.4 Regle de decision

Avant de dessiner une section, demander :

> Quelle est la matiere visuelle la plus credible pour cette promesse ?

Si la reponse est "un screenshot" -> montrer le screenshot.
Si la reponse est "une commande CLI" -> montrer la commande.
Si la reponse est "une ambiance de marque" -> assumer une image-led section.

---

# PARTIE 8 — LAYOUT ET RYTHME

## 8.1 Ce qui tue la page

- meme max-width partout
- meme padding partout
- meme alignement partout
- meme format de carte partout
- meme densite partout

## 8.2 Ce qu'il faut varier

### A l'echelle de la page
- largeur des sections
- fond
- densite
- mode d'alignement
- place du visuel
- type de preuve

### A l'echelle d'une section
- ratio texte/visuel
- taille des objets
- profondeur
- tension du spacing

## 8.3 Echelle de largeurs recommandee

```css
.max-reading { max-width: 44rem; }
.max-faq     { max-width: 48rem; }
.max-content { max-width: 72rem; }
.max-wide    { max-width: 84rem; }
.max-hero    { max-width: 78rem; }
```

## 8.4 Echelle de padding recommandee

```css
.section-xs { padding-block: 2rem; }
.section-sm { padding-block: 3rem; }
.section-md { padding-block: 4.5rem; }
.section-lg { padding-block: 6rem; }
.section-xl { padding-block: 8rem; }
```

**Ne jamais appliquer la meme taille sur toute la page.**

## 8.5 Regle de progression de densite

Bon flow typique :
- hero dense et dirige
- transition courte
- categorie/use case modere
- feature forte
- preuve ou metric plus epuree
- feature 2
- temoignage
- pricing
- FAQ
- CTA final

La densite doit respirer et resserrer alternativement.

---

# PARTIE 9 — NAVBAR LANDING : SYSTEME ANTI-TEMPLATE

## 9.1 These

La navbar est l'un des composants qui trahit le plus vite une sortie IA.

Pourquoi :
- elle est souvent resolue par reflexe
- elle devient un composant de starter kit au lieu d'un objet de direction
- elle recycle la meme repartition logo / liens / login / CTA quel que soit le produit
- elle n'exprime ni la profondeur du produit, ni le type de funnel, ni le ton de marque

### Regle directrice
> Une navbar forte ne sert pas seulement a naviguer. Elle dit d'emblee quel type d'objet est le site.

---

## 9.2 Le vrai anti-pattern : la navbar SaaS-template

### Signature classique
- logo texte brut a gauche sans poids reel
- 4 a 6 liens generiques au centre
- login ghost + CTA plein a droite
- fond transparent puis blur automatique au scroll
- meme structure pour un devtool, une suite B2B, une marque premium, une fintech ou un outil editorial
- mobile converti en drawer sans hierarchie ni reprise du parti pris desktop

### Verdict
Ce n'est pas "mauvais".
C'est juste interchangeable.

---

## 9.3 Ce que montrent les references reelles

### Stripe — navbar suite-produit structuree
Ce qu'on observe :
- 4 piliers de navigation nets : Products, Solutions, Developers, Resources
- Pricing et Sign in restent visibles hors des menus
- double conversion distincte : Start now + Contact sales
- architecture de navigation pensee pour la profondeur produit, pas pour faire minimaliste

Ce que ca apprend :
- quand un produit a plusieurs couches, la navbar doit assumer la profondeur
- la conversion ne doit pas absorber l'orientation
- les mega-surfaces sont legitimes si elles servent un vrai catalogue d'entrees

### Notion — navbar multi-produits et multi-audiences
Ce qu'on observe :
- Product et Solutions sont de vrais systemes d'entree, pas juste des labels vagues
- le menu expose plusieurs produits nommes : Notion, Calendar, Mail, AI, Agents, Enterprise Search, Docs, Projects
- la navigation est autant organisee par produit que par audience et cas d'usage

Ce que ca apprend :
- quand l'offre s'elargit, la navbar doit reduire l'ambiguite par familles nettes
- le bon mega-menu ne "montre pas tout" ; il montre les axes de reconnaissance les plus utiles

### Figma — navbar dense mais lisible
Ce qu'on observe :
- plusieurs familles fortes : Products, Solutions, Community, Resources
- menu de produits riche mais avec labels comprehensibles et sous-structures visibles
- Log in, Contact sales et Get started sont assumes comme actions separees

Ce que ca apprend :
- une navbar dense peut rester credible si le naming est precis
- la densite ne tue pas la clarte si la hierarchie est nette

### Cursor — navbar devtool credible
Ce qu'on observe :
- Product ouvre des entrees specifiques et techniques : Agents, Code Review, Cloud, Tab, CLI, Marketplace
- Resources regroupe Changelog, Blog, Docs, Community, Help, Workshops, Forum, Careers
- les actions en haut restent tres produit : Sign in, Contact sales, Download

Ce que ca apprend :
- pour un devtool, la barre doit paraitre utile avant de paraitre marketing
- des entrees techniques concretes donnent plus de credibilite qu'une prose de marque trop polie

### Perplexity Docs — navbar docs/search
Ce qu'on observe :
- Docs, Cookbook, API Reference et Search sont traites comme les vraies entrees
- la navigation assume la recherche et la consultation, pas la mise en scene marketing

Ce que ca apprend :
- une navbar documentation doit etre orientee recherche, reperage, categories, pas persuasion

### Vercel — separation marketing / produit / app navigation
Ce qu'on observe :
- la navigation marketing reste large et category-led
- le dashboard a recemment ete repense avec sidebar redimensionnable, tabs unifies, ordre optimise pour les workflows frequents, et mobile en bottom bar une main

Ce que ca apprend :
- il faut separer explicitement la logique de navigation marketing de la logique d'usage produit
- une meme grammaire ne doit pas recouvrir landing, docs et app shell

---

## 9.4 Regles dures

1. **Ne jamais laisser la navbar etre choisie par defaut.**
   Son archetype doit etre decide explicitement.

2. **La navbar doit correspondre au type de page.**
   Homepage de marque, landing produit, docs, pricing, product tour et dashboard n'ont pas la meme barre.

3. **La navbar doit correspondre au type de produit.**
   Devtool, suite B2B, fintech, produit editorial, marque premium, outil creative ou docs-led demandent des structures differentes.

4. **Le rapport marque / orientation / conversion doit etre choisi.**
   Il faut trancher explicitement ce qui domine visuellement.

5. **Le logo ne doit pas etre traite comme un placeholder.**
   Le bloc marque doit avoir un vrai poids ou une vraie retenue choisie.

6. **Le naming de la nav doit etre concret.**
   Eviter les labels generiques poses par reflexe si le produit permet plus specifique.

7. **Le scroll state doit avoir une raison.**
   Pas de blur ou de sticky transforme en automatisme cosmetique.

8. **Le mobile doit conserver la logique desktop.**
   Pas necessairement la meme mise en page, mais la meme hierarchie strategique.

9. **Landing nav et app shell ne doivent jamais fusionner.**
   Une barre de vente et une barre d'usage ne servent pas la meme cognition.

---

## 9.5 Les 8 archetypes de navbar

### Type A — Navbar minimale de marque
#### Usage
- campagne
- marque forte
- hero image-led ou manifeste
- offre simple

#### Structure
- logo ou lockup fort
- peu de liens
- un seul CTA principal
- respiration visible

#### Effet recherche
- premium
- retenu
- non-template

#### Risque
Devenir poseur si l'offre a besoin d'orientation reelle.

---

### Type B — Navbar produit-guidee
#### Usage
- SaaS clair
- landing produit classique mais exigeante
- funnel B2B propre

#### Structure
- logo
- 3 a 5 liens d'intention reelle
- login discret
- CTA principal net

#### Effet recherche
- clarte
- credibilite
- conversion sans look de starter kit

#### Regle
Les liens doivent etre nommes par intention utilisateur, pas par automatisme marketing.

---

### Type C — Navbar audiences / use cases
#### Usage
- plusieurs audiences
- segmentation forte
- plusieurs scenarios d'achat

#### Structure
- logo
- entrees par role, audience ou usage
- CTA principal
- sous-navigation possible

#### Effet recherche
- reconnaissance rapide
- moins de friction cognitive

---

### Type D — Navbar suite-produit
#### Usage
- constellation de produits
- plateforme multi-modules
- ecosysteme plus large qu'une simple feature list

#### Structure
- logo
- index produit ou mega-menu produit
- liens de haut niveau peu nombreux
- conversion souvent secondaire a l'orientation

#### Effet recherche
- profondeur
- sensation de systeme

---

### Type E — Navbar devtool / engineering
#### Usage
- infra
- API
- coding tools
- workflow engineering

#### Structure
- logo sobre
- Docs / API / Pricing / Changelog / Community / GitHub / Login / Download ou CTA
- ton utilitaire

#### Effet recherche
- competence
- utilite
- credibilite technique

#### Regle
Une navbar un peu seche mais precise vaut mieux qu'une navbar marketing deluxe sans signaux techniques.

---

### Type F — Navbar editorial / creative
#### Usage
- produits d'ecriture
- outils creatifs
- marques avec voix editoriale

#### Structure
- logo plus expressif
- peu de liens
- plus de tension typographique
- CTA moins agressif

#### Effet recherche
- ton
- voix
- distinction

---

### Type G — Navbar conversion-first
#### Usage
- landing paid traffic
- pages d'activation
- LP a objectif unique

#### Structure
- navigation reduite
- distractions retirees
- CTA dominant
- preuve secondaire discrete

#### Effet recherche
- direct
- net
- funnelise

---

### Type H — Navbar docs/search
#### Usage
- documentation
- developer hub
- knowledge base
- ressources structurantes

#### Structure
- logo ou lien home
- recherche visible
- categories stables
- profondeur laterale ou secondaire

#### Effet recherche
- reperage
- vitesse
- memoire spatiale

---

## 9.6 Arbre de decision obligatoire

Avant de generer une navbar, repondre explicitement :

1. Le site vend-il une marque, un produit, une suite, une doc ou une conversion directe ?
2. Le visiteur doit-il surtout explorer, se reconnaitre, comparer ou agir ?
3. Le hero est-il suffisamment fort pour que la navbar recule ?
4. L'offre a-t-elle plusieurs produits, plusieurs audiences ou plusieurs cas d'usage ?
5. Le login est-il une action majeure ou simplement un acces secondaire ?
6. Faut-il exposer des ressources techniques tres tot ?
7. Quel archetype de navbar est choisi parmi A, B, C, D, E, F, G, H ?
8. Quel rapport faut-il entre marque, orientation et conversion ?
9. Quel etat au scroll sert reellement la page ?
10. Quelle est la strategie mobile : exploration, conversion ou usage ?

Tant que ces points ne sont pas tranches, la sortie retombe vers une navbar moyenne.

---

## 9.7 Bloc interne de la navbar

### 1. Bloc marque
Peut prendre plusieurs formes :
- mot-symbole soigne
- lockup signe + nom
- nom + sous-label discret
- symbole seul si la marque le supporte

### 2. Bloc orientation
Ce n'est pas juste une liste de liens.
C'est le systeme principal d'entree.

Formats legitimes :
- liens directs
- categories
- switch produit
- entrees par audience
- un point d'entree plus riche type Explore / Platform si la profondeur le justifie

### 3. Bloc action
Peut contenir :
- login
- CTA principal
- action secondaire
- recherche
- download
- contact sales

### Regle
Le rapport visuel entre les 3 blocs doit etre choisi.
Pas forcement equilibre.

---

## 9.8 Distributions visuelles recommandeees

### Pattern 1 — Conversion droite forte
- gauche = marque
- centre = orientation legere
- droite = login + CTA
Bon pour : SaaS B2B simple

### Pattern 2 — Centre dominant
- gauche = marque modeste
- centre = structure principale
- droite = action minimale
Bon pour : produits matures / docs / nav riche

### Pattern 3 — Marque dominante
- gauche = bloc identitaire fort
- centre = presque vide ou tres retenu
- droite = CTA principal
Bon pour : campagne, marque premium, AI brand-led

### Pattern 4 — Audiences visibles
- gauche = marque
- centre = role / audience / use case
- droite = action
Bon pour : segmentation forte

### Pattern 5 — Technical utility
- gauche = marque
- centre = docs / api / changelog / community
- droite = sign in / download / pricing
Bon pour : devtools

---

## 9.9 Etats de scroll

### Etat 1 — Static calm
Navbar quasi fusionnee au hero.
Bon pour hero fort et page courte.

### Etat 2 — Stabilized
Au scroll :
- fond devient plus lisible
- bordure ou shadow subtile apparait
- la barre gagne en stabilite
Bon pour la majorite des landing produit.

### Etat 3 — Docked / panel
La navbar devient un vrai objet pose.
Bon pour pages longues, comparatives, ou navigation qui doit rester lisible longtemps.

### Interdits
- blur systematique juste parce que "ca fait moderne"
- shrink trop fort
- accumulation de blur + border + shadow + tint sans gain reel

---

## 9.10 Mega-menu

Mega-menu autorise seulement si au moins 2 conditions sont vraies :
- plusieurs familles produit
- plusieurs audiences distinctes
- profondeur informationnelle reelle
- besoin de montrer des categories avec preuve ou preview

### Le mega-menu ne doit jamais etre :
- un menu vide mais large
- une grille de liens sans hierarchie
- un panneau marketing de plus
- un cache-misere pour un naming flou

### Un bon mega-menu contient :
- groupes nommes proprement
- entrees principales visibles vite
- sous-niveaux comprehensibles
- parfois un visuel ou une preuve, mais avec retenue

---

## 9.11 Mobile

### Regles dures
- le menu mobile ne doit pas effacer la priorite strategique
- le CTA principal doit rester identifiable
- la structure doit garder son archetype
- pas de liste verticale de liens sans hierarchie

### Formats acceptables
- sheet simple
- full-screen menu editorial
- accordion structure
- split exploration / action

### Regle
Le mobile n'est pas une version compressee du desktop.
C'est une recomposition.

---

## 9.12 Anti-patterns navbar hyper-specifiques

- logo texte sans caractere + CTA bleu arrondi de starter kit
- nav centree sans raison
- labels du type Features / Solutions / Resources / Pricing poses par reflexe
- login et CTA de meme poids alors que le funnel demande une asymetrie
- mega-menu sur site mono-produit simple
- sticky blur sur page qui n'en a pas besoin
- menu mobile qui enterre l'action principale
- navbar marketing recopies dans l'app shell
- meme structure pour la landing, la docs et le dashboard

---

## 9.13 Prompt contract obligatoire

Quand le skill doit creer une navbar, il doit TOUJOURS produire ce bloc :

```md
## Navbar decision
- Archetype choisi:
- Pourquoi cet archetype:
- Bloc marque:
- Bloc orientation:
- Bloc action:
- Distribution visuelle:
- Etat initial:
- Etat au scroll:
- Strategie mobile:
- Ce qu'on evite absolument:
```

Si ce bloc n'est pas produit, la navbar n'est pas consideree comme decidee.

---

## 9.14 Definition of done navbar

La navbar est consideree comme bonne si :
- elle pourrait appartenir specifiquement a ce produit
- elle ne pourrait pas etre deplacee telle quelle sur 20 autres SaaS sans paraitre identique
- ses liens correspondent a de vraies intentions utilisateur
- son rapport marque / orientation / conversion est choisi
- son etat au scroll est justifie
- sa version mobile garde une hierarchie nette
- elle ne ressemble pas a un composant de starter kit

---

# PARTIE 10 — DASHBOARD, SIDEBAR, TOPBAR

La V2 etait deja solide ici. La Hyper V3 resserre encore.

## 10.1 Principe directeur

Une landing vend.
Un dashboard opere.

Le dashboard doit privilegier :
- vitesse de lecture
- predictibilite
- densite maitrisee
- affordance
- memoire spatiale

## 10.2 Sidebar

### Regles dures
- largeur stable en mode plein
- items compacts
- active state subtil, pas accent plein
- footer user distinct
- mode collapsed vraiment pense
- tooltips instantanes en collapsed

### Zones utiles
1. contexte workspace
2. recherche / command palette
3. nav principale
4. nav contextuelle
5. utilitaires
6. plan / upgrade si necessaire
7. profil utilisateur

### Interdits
- bordure grise Tailwind brute
- items trop hauts type mobile
- accent bleu plein sur l'item actif
- icones incoherentes
- labels de groupe trop forts

## 10.3 Topbar dashboard

### Rôle
- contextualiser la vue courante
- exposer la recherche
- exposer les actions globales
- rester legere

### Bon contenu
- breadcrumb ou titre contextuel
- search trigger
- actions secondaires
- notifications
- user avatar

### A eviter
- refaire une navbar marketing dans l'app
- ajouter trop de texte
- faire du topbar la zone de branding principale

---

# PARTIE 11 — PRICING ET CARDS PRODUIT

## 11.1 Le vrai probleme des cards IA

Ce n'est pas seulement qu'elles se ressemblent.
C'est qu'elles sont **interchangeables**.

Si on retire le texte, on ne sait plus quel produit est quel produit.

## 11.2 Regles pour des cards produit credibles

1. chaque card importante a une atmosphere propre
2. l'accent ne colore pas tout
3. la base du fond doit etre perceptible, pas du quasi-noir invisible
4. les bordures teintees sont subtiles
5. le texte garde une neutralite forte
6. le CTA concentre l'accent principal

## 11.3 Recette fiable

```css
.product-card {
  background:
    radial-gradient(ellipse 90% 70% at 20% 20%, rgba(92,124,250,0.18) 0%, transparent 50%),
    radial-gradient(ellipse 70% 60% at 85% 15%, rgba(25,195,156,0.12) 0%, transparent 45%),
    linear-gradient(160deg, #131a28 0%, #0f1520 45%, #0b1018 100%);
  border: 1px solid rgba(92,124,250,0.18);
}
.product-card:hover {
  border-color: rgba(92,124,250,0.34);
}
```

## 11.4 Quand ne pas utiliser de card

- section metrics
- citation heroique simple
- timeline sobre
- comparatif avant/apres trop fort visuellement

---

# PARTIE 12 — METRICS, PROOF, TRUST

## 12.1 Les metrics n'ont pas besoin de cartes

Un chiffre peut etre plus fort sans contenant.

### Utiliser des cards seulement si :
- il faut comparer plusieurs dimensions complexes
- il faut ajouter contexte et action
- la lecture tabulaire est utile

Sinon :
- chiffre grand
- label bref
- rythme net

## 12.2 Le social proof ne doit pas etre brouillon

Formats efficaces :
- logos clients
- 1 chiffre important
- 1 citation marquee
- 1 badge de confiance / note / resultat

Format faible :
- 12 petits badges insignifiants
- 8 citations sans nom memoire
- logo wall enorme sans contexte

## 12.3 Regle

La preuve doit apparaitre tot, mais pas saturer le hero.

---

# PARTIE 13 — MOTION, SCROLL, INTERACTION

## 13.1 Principe directeur

Motion doit :
- clarifier
- orienter
- donner du rythme
- soutenir la profondeur

Pas seulement decorer.

## 13.2 Regles dures

- respecter `prefers-reduced-motion`
- pas de meme fade-in sur tous les elements
- pas d'animation longue sur les controles frequents
- pas de scroll-driven si le contenu devient illisible sans lui

## 13.3 Durees de base

```css
--duration-fast: 100ms;
--duration-ui: 160ms;
--duration-panel: 240ms;
--duration-section: 360ms;
--ease-out: cubic-bezier(0.33, 1, 0.68, 1);
--ease-in-out: cubic-bezier(0.65, 0.05, 0.36, 1);
```

## 13.4 Patterns utiles

### Hover
- couleur
- border
- elevation legere
- micro-scale sur CTA si pertinent

### Entrance
- fade + translate subtil
- stagger si groupe reel d'elements

### Scroll-driven
Seulement si la section en depend reellement.
Exemples legitimes :
- stacking cards
- timeline narrative
- reveal progressif d'un systeme
- comparaison avant/apres

## 13.5 Stacking cards

Bon pattern si :
- les cartes racontent une progression
- chacune porte une etape importante
- l'empilement aide la comprehension

Mauvais pattern si :
- il sert juste a rendre une grille plus fancy
- il degrade la lisibilite mobile

---

# PARTIE 14 — ACCESSIBILITE, PERFORMANCE, CREDIBILITE

## 14.1 Accessibilite minimale non negociable

- focus visible
- contraste suffisant
- touch targets correctes
- navigation clavier utile
- ordre semantique coherent
- textes de boutons explicites
- reduction motion respectee

## 14.2 Performance

### Regles dures
- pas d'iframe YouTube au load du hero
- images compressees et formats modernes
- defer/lazy quand utile
- pas de librairie lourde pour un simple effet
- pas de background generatif sur les pages denses de travail

## 14.3 Credibilite

Une interface devient credible quand :
- le produit a l'air reel
- les donnees ont l'air d'avoir un contexte
- les screenshots ont des details plausibles
- la nav est logique
- les actions sont nommees correctement
- les etats existent vraiment

Un site n'est pas premium parce qu'il brille.
Il l'est parce qu'il parait vrai.

---

# PARTIE 15 — MAPPINGS PAR TYPE DE PRODUIT

## 15.1 Devtools / infrastructure

### Favoriser
- fond neutre + foyer visuel
- artefacts techniques
- snippets
- terminal
- README
- densite plus rationnelle

### Eviter
- storytelling trop abstrait
- images hero premium sans preuve technique

## 15.2 CRM / ops / productivity B2B

### Favoriser
- UI produit reelle
- modules et vues de travail
- categories d'usage
- surfaces propres
- preuve workflow / automation / reporting

### Eviter
- hero science-fiction
- 3D deco qui ne parle pas du produit

## 15.3 AI premium / category creation

### Favoriser
- hero fort
- image-led si la marque le supporte
- sections de preuve bien ancrees ensuite
- avant/apres, workers, metrics, use cases

### Eviter
- n'etre qu'une atmosphere
- oublier le produit reel

## 15.4 Writing / docs / creative tools

### Favoriser
- texture calme
- editorial layout
- profondeur de documents et modules
- ton plus humain et moins "enterprise"

### Eviter
- dashboardisation agressive
- chrome technique inutile

## 15.5 Fintech / banking / serious tools

### Favoriser
- clarte
- surfaces propres
- preuve produit / formulaire / simulation / chiffres
- atmosphere premium mais retenue

### Eviter
- motion theatrale excessive
- couleurs trop playground

---

# PARTIE 16 — PROCEDURE OPERATIONNELLE

## 16.1 Mode CREATE

### Etape 1 — Identifier le type de produit
- devtools
- B2B ops
- AI premium
- editorial
- fintech
- autre

### Etape 2 — Choisir la matiere visuelle principale
- UI
- code
- document
- image de marque
- module systeme

### Etape 3 — Choisir le systeme de fond par section
Pas un fond global unique.

### Etape 4 — Definir le rythme de page
- densite hero
- section de transition
- preuves
- features
- demo
- conversion

### Etape 5 — Construire tokens + typo + spacing

### Etape 6 — Construire nav et shell selon le contexte

### Etape 7 — Ajouter motion seulement la ou elle sert

## 16.2 Mode AUDIT

Classer les problemes par gravite.

### P0 — probleme de direction
- tout parait genere
- pas de hierarchie de sections
- pas de matiere visuelle credible
- fond unique partout
- palette non differenciee

### P1 — probleme de systeme UI
- typo monotone
- cards repetitives
- mauvais active states
- navbar/dashboard confondus
- spacing trop uniforme

### P2 — probleme de finition
- motion fade-in generique
- mauvais hover
- radius monotone
- bordures faibles
- badges parasites

## 16.3 Mode FIX

Corriger dans cet ordre :
1. architecture des sections
2. systeme de fond
3. matiere visuelle
4. typo
5. couleur/surfaces
6. composants
7. motion
8. polish

Ne jamais commencer par le polish si la structure est faible.

---

# PARTIE 17 — CHECKLIST HYPER V3

## Direction generale
- [ ] La page a une these visuelle claire
- [ ] Le type de produit est identifiable en 5 secondes
- [ ] La matiere visuelle principale est credible
- [ ] Le site ne repose pas sur des defaults visibles

## Hero
- [ ] Le hero a une promesse claire
- [ ] Il n'essaie pas de tout dire
- [ ] Il a une matiere visuelle dominante unique
- [ ] Les CTA sont nets

## Sections
- [ ] Chaque section a un role clair
- [ ] Il existe une vraie section de transition apres le hero
- [ ] Les sections features ont des identites distinctes
- [ ] Le CTA final boucle la narration

## Fonds
- [ ] Au moins 3 a 5 atmospheres de fond sur une landing complete
- [ ] Le type de fond correspond au role de la section
- [ ] Le produit n'est pas noye par le fond
- [ ] Les sections de travail dense restent calmes

## Typographie
- [ ] Pas de mono hors contexte
- [ ] Le display a une vraie tension
- [ ] Le body est calme et lisible
- [ ] Il existe une vraie echelle de tailles et de poids

## Couleur
- [ ] Palette custom ou au moins recadree
- [ ] Accent principal limite a de vrais points d'attention
- [ ] Surfaces et bordures forment une famille coherente
- [ ] Etats focus et danger sont definis

## Layout
- [ ] Widths variees
- [ ] Padding vertical varie
- [ ] Alignements varies
- [ ] Densite variee

## Produit / preuve
- [ ] Le produit apparait vraiment
- [ ] Les captures ont l'air plausibles
- [ ] Les preuves sont concretes
- [ ] Les metrics ou citations sont memorables

## Navbar / app shell
- [ ] La navbar a un archetype explicite
- [ ] Le rapport marque / orientation / conversion est choisi
- [ ] Les liens ne sont pas des labels SaaS poses par reflexe
- [ ] Le scroll state est justifie
- [ ] Le mobile conserve une vraie hierarchie
- [ ] Landing nav et app shell ne sont pas confondus
- [ ] Sidebar compacte et utile
- [ ] Topbar contextuelle
- [ ] Search / command palette traites correctement

## Motion
- [ ] Motion utile, pas cosmetique
- [ ] Reduced motion gere
- [ ] Pas de fade-in universel
- [ ] Scroll-driven seulement si necessaire

## Performance / a11y
- [ ] Focus visible
- [ ] Contraste correct
- [ ] Hero leger
- [ ] Images/video/iframes charges intelligemment

---

# PARTIE 18 — VERSION COURTE : CLAUDE FAIT / HYPER V3 FAIT

| Sortie IA generique | Hyper V3 fait a la place |
|---|---|
| meme fond partout | choisit un systeme de fond par section |
| hero texte + boutons + screenshot standard | choisit un type de hero adapte au produit |
| gradients partout | fait porter le visuel principal par une vraie matiere |
| cards identiques | differencie structure, atmosphere et role |
| tout centre | varie les alignements selon l'objectif |
| proof confuse | place une section de transition compacte |
| dashboard trop marketing | privilegie densite, affordance, memoire spatiale |
| motion uniforme | assigne la motion a une fonction |
| accent sur tout | reserve l'accent a la decision et au focus |
| produit invisible | montre le produit, le code, le document ou le contexte reel |

---

# PARTIE 19 — REGLE FINALE

Quand tu hesites, ne demande pas :

> "Comment rendre ca plus premium ?"

Demande plutot :

1. **Quel est le role exact de cette section ?**
2. **Quelle est sa matiere visuelle la plus credible ?**
3. **Quel systeme de fond l'aide sans la parasiter ?**
4. **Quelle densite lui convient ?**
5. **Qu'est-ce qui est reellement choisi ici, et qu'est-ce qui vient juste d'un default ?**

C'est cette suite de decisions qui separe une interface concue d'une interface generee.

---

# PARTIE 20 — MODE SKILL OPERATOIRE

Cette partie transforme la Hyper V3 en outil d'execution.
Le but n'est plus seulement de juger un design.
Le but est de produire une sortie stable, reutilisable et actionnable pendant le travail.

## 20.1 Les 3 modes du skill

### Mode `create`
A utiliser quand il faut concevoir une page, une section, un shell d'app ou un systeme UI depuis zero.

### Mode `audit`
A utiliser quand il faut analyser une page existante, un repo frontend, un Figma, un screenshot ou une URL.

### Mode `fix`
A utiliser quand le site existe deja et qu'il faut corriger ce qui le rend generique, faible ou incoherent.

## 20.2 Contrat de sortie par mode

### Sortie attendue en mode `create`
Toujours produire, dans cet ordre :

1. **Direction de page**
   - type de produit
   - type de page
   - audience prioritaire
   - ton visuel

2. **Systeme de sections**
   - liste des sections dans l'ordre
   - role de chaque section
   - type de fond choisi
   - matiere visuelle principale

3. **Systeme UI**
   - tokens
   - typographie
   - largeur des sections
   - rythme vertical
   - boutons / cards / nav

4. **Points de vigilance**
   - ce qu'il faut absolument eviter
   - les defaults qui feraient basculer vers un rendu IA

5. **Plan d'implementation**
   - ordre de construction des blocs
   - ce qui doit etre fait en premier
   - ce qui peut rester en finition

### Sortie attendue en mode `audit`
Toujours produire, dans cet ordre :

1. **Diagnostic global**
   - impression generale en une phrase
   - niveau de gravite global

2. **Problemes par gravite**
   - P0 = direction / structure / fond / matiere visuelle
   - P1 = systeme UI / typographie / composants / shell
   - P2 = motion / hover / finesse / details

3. **Liste des problemes concrets**
   Pour chaque probleme :
   - ou il apparait
   - pourquoi c'est faible
   - quel effet perceptif ca cree
   - comment le corriger

4. **Top 5 corrections prioritaires**

5. **Verdict final**
   - ce qu'il faut refaire
   - ce qu'il faut garder

### Sortie attendue en mode `fix`
Toujours produire, dans cet ordre :

1. **Ce qu'on garde**
2. **Ce qu'on change**
3. **Ce qu'on supprime**
4. **Ordre des corrections**
5. **Definition of done**

## 20.3 Schema minimal de decision avant toute execution

Avant de dessiner ou corriger quoi que ce soit, repondre explicitement a ces 10 questions :

1. Quel est le type exact de produit ?
2. Quel est le type exact de page ?
3. Quelle est la matiere visuelle la plus credible ?
4. Quel type de hero convient ?
5. Quel systeme de fond convient a chaque section ?
6. Quel est le niveau de densite adequat ?
7. Quel archetype de navbar convient ?
8. Quel rapport faut-il entre marque, orientation et conversion ?
9. Quelle logique de scroll et quelle logique mobile conviennent ?
10. Quels sont les 3 defaults a eviter absolument ici ?

Si ces 10 points ne sont pas tranches, le travail partira presque toujours vers une sortie moyenne.

## 20.4 Templates d'execution

### Template `create`

```md
## Direction
- Produit:
- Page:
- Audience:
- Ton:

## Structure de page
1. Section:
   - Role:
   - Fond:
   - Matiere visuelle:
   - Layout:
2. Section:
   - Role:
   - Fond:
   - Matiere visuelle:
   - Layout:

## Systeme visuel
- Palette:
- Typographie:
- Surfaces:
- Boutons:
- Navigation:

## A eviter
- 
- 
- 

## Build order
1.
2.
3.
```

### Template `audit`

```md
## Diagnostic global

## P0
- Probleme:
  - Impact:
  - Correction:

## P1
- Probleme:
  - Impact:
  - Correction:

## P2
- Probleme:
  - Impact:
  - Correction:

## Top 5 priorites
1.
2.
3.
4.
5.

## Verdict
- A garder:
- A refaire:
```

### Template `fix`

```md
## Keep
- 

## Change
- 

## Remove
- 

## Sequence
1.
2.
3.

## Done when
- 
- 
- 
```

## 20.5 Ordre de priorite absolu

Quand il faut corriger un site, appliquer toujours cet ordre :

1. **Role des sections**
2. **Systeme de fond**
3. **Matiere visuelle**
4. **Hero et nav**
5. **Typographie**
6. **Composants**
7. **Motion**
8. **Polish**

Ne jamais commencer par les animations, les ombres, les gradients, ou les radius si la structure de section est encore faible.

## 20.6 Ce qu'il faut inspecter selon le type d'entree

### Si l'entree est une URL
Inspecter en priorite :
- hero
- nav
- premiere section apres hero
- systeme de fond sur 5 a 8 sections
- type de preuve montre
- rapport entre produit reel et decoration

### Si l'entree est un screenshot
Inspecter en priorite :
- densite
- alignement
- typo
- surface / contrastes
- cards repetitives
- signaux de faux produit

### Si l'entree est un repo/frontend
Inspecter en priorite :
- tokens
- tailwind config / CSS variables
- systeme de spacing
- composant nav
- composant button/card
- patterns repetes dans les sections

### Si l'entree est un dashboard
Inspecter en priorite :
- sidebar
- topbar
- densite des vues
- etats actifs
- hierarchy des donnees
- repetabilite des patterns

## 20.7 Heuristiques de scoring rapide

Attribuer une note sur 5 a chacun :

- Specificite
- Coherence
- Matiere visuelle
- Rythme
- Credibilite produit
- Navigation
- Typographie
- Conversion

### Interpretation
- **0-1** = faible / generique / non dirige
- **2** = fonctionnel mais interchangeable
- **3** = bon socle, manque de caractere ou de rigueur
- **4** = fort, bien pense, credible
- **5** = tres fort, memorisable, maitrise

## 20.8 Lexique d'action

Quand tu travailles avec ce skill, evite les consignes vagues du type :
- fais plus premium
- rends ca plus moderne
- fais plus SaaS
- rends ca plus wow

Remplace-les par :
- reduis la monotonie des sections
- choisis une matiere visuelle plus credible
- clarifie le role de la premiere section apres hero
- remplace les cartes interchangeables par 3 modules differencies
- reduis l'usage de l'accent principal
- rends la sidebar plus compacte et plus operatoire
- change le systeme de fond du hero et du CTA final pour creer une boucle

## 20.9 Definition of done globale

Le travail est considere comme termine quand :

- les sections ont des roles nets
- la page n'a plus l'air construite par defaults successifs
- le produit ou son artefact principal est visible
- le hero et le CTA final se repondent
- la typographie cree une vraie hierarchie
- le systeme de fond soutient les sections au lieu de les uniformiser
- la navigation correspond au contexte de page
- les details n'essaient plus de compenser une structure faible

## 20.10 Regle finale du skill

Ne jamais compenser un manque de direction par du style.

Si une page parait generique, la cause est presque toujours dans cet ordre :
- mauvais role de section
- mauvaise matiere visuelle
- mauvais systeme de fond
- mauvaise hierarchie
- seulement ensuite mauvais polish

Le skill doit donc toujours corriger le sens avant de corriger l'apparence.

