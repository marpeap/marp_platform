---
name: seo
description: Guide SEO durci pour sites web modernes. Priorise les sources officielles Google Search, web.dev, Next.js et OpenAI. Distingue regles officielles, bonnes pratiques cross-engine, patterns framework, observations de teardown et points experimentaux.
user-invocable: true
version: 2.0
last-verified: 2026-04-09
stability: maintained
---

# /seo — Guide SEO durci pour sites web modernes

## 0. But de cette version

Cette version n'essaie pas d'etre "complete" au sens absolu. Elle vise a etre :

- fiable
- maintenable
- explicite sur le niveau de certitude de chaque recommandation
- orientee execution

Le SEO change trop vite pour qu'un skill reste robuste s'il melange sans distinction :

- documentation officielle
- habitudes d'implementation
- observations faites sur des sites de reference
- statistiques tierces
- speculation autour des experiences IA

Cette edition corrige ce probleme.

---

## 1. Comment lire ce skill

### 1.1 Niveaux de fiabilite

Chaque recommandation importante doit etre comprise dans une de ces classes.

| Label | Signification | Usage |
|---|---|---|
| `OFFICIAL` | Documente par un moteur ou un framework officiel | Base de reference |
| `SUPPORTED` | Supporte en pratique, sans etre toujours necessaire | Bon choix par defaut |
| `FRAMEWORK` | Convention ou pattern d'un framework comme Next.js | Implementation |
| `OBSERVED` | Observe sur des sites de reference, utile mais non normatif | Inspiration |
| `EXPERIMENTAL` | Instable, dependant du navigateur ou de surfaces recentes | Tester avant generalisation |
| `THIRD_PARTY` | Statistique ou benchmark externe | Utiliser comme signal faible |

### 1.2 Regle de priorite

En cas de conflit :

1. documentation officielle Google Search / web.dev / Bing / Next.js / OpenAI
2. comportement reel observe sur le site et dans Search Console / logs / tests
3. bonnes pratiques cross-engine
4. patterns observes chez des SaaS de reference
5. chiffres de fournisseurs tiers

### 1.3 Politique de maintenance

A chaque revue trimestrielle :

- verifier les pages Google Search Central sur structured data, AI features, snippets, robots, pagination, image SEO, JavaScript SEO
- verifier les docs Next.js metadata, robots, sitemap, OG images
- verifier la doc OpenAI des bots
- mettre a jour `last-verified`
- lister les changements cassants dans une section `breaking changes`

---

## 2. Corrections structurantes par rapport a la version precedente

### 2.1 Meta description

- `OFFICIAL` Il n'existe pas de limite fixe officielle de longueur.
- `OFFICIAL` Google peut utiliser la meta description, mais peut aussi generer un snippet depuis le contenu.
- `SUPPORTED` Viser une description concise et utile reste pertinent, mais la logique n'est pas "120-160 caracteres sinon mauvais".

### 2.2 Hreflang

- `OFFICIAL` `hreflang` sert a declarer des variantes localisees d'un meme contenu.
- `OFFICIAL` Ce n'est pas une obligation pour un site mono-langue sans variantes localisees.
- `OFFICIAL` Google n'utilise ni `hreflang` ni `lang` pour detecter la langue ; ces signaux servent a l'orientation, pas a l'identification linguistique.

### 2.3 AI Overviews et AI Mode

- `OFFICIAL` Il n'existe pas de discipline SEO separee imposee par Google pour les AI features.
- `OFFICIAL` Les fondamentaux Search restent la base.
- `SUPPORTED` Reponses directes, structure claire, tableaux, listes et contenu bien cite sont de bonnes heuristiques editoriales, mais pas une spec officielle distincte.

### 2.4 Indexing API

- `OFFICIAL` L'Indexing API Google est reservee aux pages `JobPosting` et `BroadcastEvent` dans `VideoObject`.
- `OFFICIAL` Elle ne doit pas etre recommandee comme mecanisme generique pour accelerer l'indexation d'un site classique.

### 2.5 Accessibilite

- `OFFICIAL` L'accessibilite n'est pas documentee par Google comme facteur de ranking direct autonome.
- `SUPPORTED` Elle reste critique pour l'UX, la comprehension structurelle, la qualite du HTML, la compatibilite mobile et les signaux indirectement lies a la satisfaction utilisateur.

### 2.6 Structured data retiree ou simplifiee

- `OFFICIAL` Le Sitelinks Search Box a ete retire de Search a partir du 21 novembre 2024.
- `OFFICIAL` Google a annonce en 2025 la suppression progressive de plusieurs surfaces structured data dans Search.
- `OFFICIAL` Il faut verifier la galerie Search officielle avant d'ajouter un type de schema pour un objectif de rich result.

### 2.7 Bots IA

- `OFFICIAL` Pour OpenAI, `OAI-SearchBot` gere la presence dans les reponses de recherche, `GPTBot` concerne l'entrainement, et `ChatGPT-User` est lie a des actions utilisateur et n'est pas un crawl automatique classique.
- `OFFICIAL` Pour Google, les controles d'apparition dans Search et AI features passent par Googlebot, les robots meta tags et les preview controls. `Google-Extended` n'est pas un substitut a `noindex` ou `nosnippet` pour Search.

---

## 3. Modele de priorisation

Ne pas implementer tout d'un coup. Prioriser par couches.

### Couche A — Indexabilite et controle

A faire en premier :

- `OFFICIAL` `title` descriptif et distinct
- `OFFICIAL` `meta name="description"` utile
- `OFFICIAL` canonical correct en `<head>`
- `OFFICIAL` `noindex` sur les pages non publiques
- `OFFICIAL` sitemap propre
- `OFFICIAL` robots.txt coherent
- `OFFICIAL` statut HTTP correct : 200, 301, 404, 410, 5xx
- `OFFICIAL` HTML indexable disponible sans dependre d'un rendu client fragile

### Couche B — Comprenabilite du contenu

- `OFFICIAL` HTML semantique
- `OFFICIAL` headings coherents
- `OFFICIAL` liens internes logiques
- `SUPPORTED` structured data pertinente
- `SUPPORTED` images bien balisees
- `SUPPORTED` content design oriente reponse utile

### Couche C — Performance et experience

- `OFFICIAL` Core Web Vitals
- `SUPPORTED` prevention du CLS
- `SUPPORTED` reduction du JS inutile
- `SUPPORTED` optimisation LCP / INP

### Couche D — Visibilite et distribution

- `SUPPORTED` Open Graph / Twitter cards
- `SUPPORTED` off-page / links / citations
- `SUPPORTED` entity SEO
- `SUPPORTED` local SEO si applicable

---

## 4. Regles dures

### 4.1 Ce qui est obligatoire

- `OFFICIAL` Une page non destinee a l'indexation doit utiliser `noindex` et non un simple `disallow` dans robots.txt.
- `OFFICIAL` Une page canonique doit pointer vers une URL cohérente, accessible, indexable, et non contradictoire avec les autres signaux.
- `OFFICIAL` Les pages paginees doivent avoir une URL unique et leur propre canonical.
- `OFFICIAL` Le contenu principal d'une page SEO critique ne doit pas dependre d'un composant `ssr: false` ou d'un rendu purement client si cela rend le HTML source vide ou incomplet.
- `OFFICIAL` Les pages 404 doivent retourner un vrai 404.
- `OFFICIAL` Les structured data ne doivent jamais decrire du contenu absent, cache de maniere trompeuse, faux, ou non visible selon les politiques Google.

### 4.2 Ce qui est interdit

- canonicaliser toute une pagination vers la page 1
- `noindex` des pages paginees qui servent a la decouverte de contenu
- bloquer par middleware les fichiers `robots`, `sitemap`, `opengraph-image`, `favicon`, `manifest`, `.well-known`
- ajouter des notes ou avis inventes dans le schema
- utiliser l'Indexing API comme accelerateur SEO generique
- presenter un signal non officiel comme "facteur de ranking direct" sans base officielle

---

## 5. Checklist minimale de production

## 5.1 HTML et metadata

| Item | Niveau | Note |
|---|---|---|
| `<html lang="...">` | `SUPPORTED` | utile pour navigateurs, accessibilite et outillage |
| `<meta charset="utf-8">` | `SUPPORTED` | standard de base |
| `<meta name="viewport">` | `SUPPORTED` | standard mobile |
| `<title>` distinct et descriptif | `OFFICIAL` | pas de longueur fixe obligatoire |
| `<meta name="description">` utile | `OFFICIAL` | Google peut aussi generer son propre snippet |
| `<link rel="canonical">` | `OFFICIAL` | URL absolue recommandee |
| meta robots si necessaire | `OFFICIAL` | `index/follow`, `noindex`, preview controls |
| OG / Twitter | `SUPPORTED` | social, pas signal Google direct |

### 5.2 Indexation et crawl

| Item | Niveau | Note |
|---|---|---|
| `robots.txt` accessible | `OFFICIAL` | ne remplace pas `noindex` |
| `sitemap.xml` accessible | `OFFICIAL` | inclure pages publiques indexables |
| `lastmod` honnete | `OFFICIAL` | ne pas tricher |
| pas de soft 404 | `OFFICIAL` | status HTTP correct |
| pas de chaines de redirects | `SUPPORTED` | viser 1 hop max |
| pages orphelines corrigees | `SUPPORTED` | maillage interne |

### 5.3 Performance

| Item | Niveau | Cible |
|---|---|---|
| LCP | `OFFICIAL` | <= 2.5 s au p75 |
| INP | `OFFICIAL` | <= 200 ms au p75 |
| CLS | `OFFICIAL` | <= 0.1 au p75 |
| image LCP non lazy-load | `SUPPORTED` | priorite haute |
| dimensions image reservees | `SUPPORTED` | anti-CLS |

---

## 6. Implementation correcte par domaine

## 6.1 Titles et meta descriptions

### A faire

- `OFFICIAL` ecrire un titre qui aide un humain a choisir le resultat
- `OFFICIAL` ecrire une meta description qui resument clairement la page
- `SUPPORTED` garder les titres concis et distincts
- `SUPPORTED` faire correspondre le sujet du `title`, du `h1` et du contenu principal

### A eviter

- duplication massive des titres
- descriptions identiques sur des centaines de pages
- titres sur-optimises ou listes de mots-cles
- contraintes rigides du type "160 caracteres sinon faux"

## 6.2 Canonical

### Regles

- `OFFICIAL` utiliser la canonical pour les doublons ou quasi-doublons
- `OFFICIAL` sur pagination, self-canonical par page
- `OFFICIAL` une page `noindex` ne doit pas servir de canonical cible strategique
- `SUPPORTED` harmoniser trailing slash, casse, params, protocoles et sous-domaines

### Exemples

```html
<link rel="canonical" href="https://example.com/blog/seo-guide" />
```

Pagination :

```html
<link rel="canonical" href="https://example.com/blog?page=2" />
```

## 6.3 Robots, noindex, preview controls

### Regles

- `OFFICIAL` `robots.txt` controle le crawl, pas l'indexation a lui seul
- `OFFICIAL` `noindex` controle l'indexation des pages HTML
- `OFFICIAL` `nosnippet`, `max-snippet`, `max-image-preview`, `max-video-preview`, `data-nosnippet` controlent la facon dont Google peut afficher des extraits
- `OFFICIAL` ces controles s'appliquent aussi aux AI features de Google Search

Exemple :

```html
<meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1" />
```

Pour bloquer certaines parties :

```html
<span data-nosnippet>Texte a exclure des extraits</span>
```

### Pages a noindex par defaut

- dashboards et zones authentifiees
- pages login/register
- pages admin
- espaces de recherche interne sans valeur SEO
- environnements de preview ou staging

## 6.4 Sitemaps

### Regles

- `OFFICIAL` n'inclure que des URLs publiques, indexables, canoniques
- `OFFICIAL` renseigner `lastmod` si l'information est fiable
- `SUPPORTED` `priority` et `changefreq` peuvent aider d'autres moteurs, mais Google les ignore
- `SUPPORTED` pour tres gros sites, utiliser un sitemap index

Exemple Next.js :

```ts
export default async function sitemap() {
  return [
    {
      url: 'https://example.com/',
      lastModified: '2026-04-01',
    },
  ]
}
```

## 6.5 Rendering et JavaScript SEO

### Regles

- `OFFICIAL` verifier le HTML source avant JS
- `OFFICIAL` un rendu JS peut etre traite, mais il ajoute du risque, du delai et du budget de rendu
- `SUPPORTED` reserver SSR, SSG ou ISR aux pages SEO critiques
- `FRAMEWORK` en Next.js, eviter `next/dynamic(..., { ssr: false })` pour le contenu SEO principal

Test simple :

```bash
curl -s https://example.com | grep -i "mot cle critique"
```

Si le contenu n'apparait pas dans le HTML brut, la page demande un examen SEO technique.

## 6.6 Structured data

### Strategie robuste

- `OFFICIAL` n'ajouter que les types supportes dans la Search Gallery si l'objectif est une surface Google Search
- `SUPPORTED` utiliser un `@graph` lie par `@id` pour les pages riches
- `SUPPORTED` garder les donnees synchronisees avec le contenu visible
- `OFFICIAL` valider avec Schema.org Validator et Rich Results Test

### Types a forte utilite

| Type | Niveau | Cas |
|---|---|---|
| `Organization` | `OFFICIAL` | identite de l'organisation |
| `WebSite` | `SUPPORTED` | contexte global |
| `BreadcrumbList` | `OFFICIAL` | navigation |
| `Article` | `OFFICIAL` | contenus editoriaux |
| `Product` | `OFFICIAL` | ecommerce |
| `SoftwareApplication` | `OFFICIAL` | logiciel/app |
| `VideoObject` | `OFFICIAL` | contenus video |
| `LocalBusiness` | `OFFICIAL` | local SEO |

### Points corriges

- `OFFICIAL` `SoftwareApplication` est bien un type supporte dans Search.
- `OFFICIAL` `Review/AggregateRating` peut s'appliquer a des types supportes, y compris les software apps, sous reserve de respecter les politiques.
- `OFFICIAL` FAQ rich results ont ete fortement reduits en 2023.
- `OFFICIAL` HowTo rich results sont depreciees.
- `OFFICIAL` Sitelinks Search Box est retire.

## 6.7 Open Graph et Twitter Cards

- `SUPPORTED` utiles pour les previews sociales et certains outils, pas comme signal de ranking Google direct
- `SUPPORTED` fournir titre, description, image, dimensions et alt
- `FRAMEWORK` en Next.js, utiliser `generateMetadata` ou les fichiers metadata adaptes
- `OBSERVED` les meilleures implos OG viennent souvent d'implementations tres soignées, mais cela ne signifie pas facteur SEO direct

## 6.8 Images

### Regles

- `OFFICIAL` fournir un texte alternatif approprie
- `SUPPORTED` pour les images decoratives, utiliser `alt=""`
- `OFFICIAL` Google n'indexe pas les images CSS comme des images de contenu
- `SUPPORTED` utiliser formats modernes, dimensions explicites et chargement adapte a la criticite
- `SUPPORTED` l'image LCP ne doit pas etre lazy-load

## 6.9 Hreflang et internationalisation

### Quand utiliser `hreflang`

- `OFFICIAL` uniquement s'il existe plusieurs versions linguistiques ou regionales du meme contenu
- `OFFICIAL` les annotations doivent etre reciproques
- `OFFICIAL` canonicals et hreflang ne doivent pas se contredire
- `SUPPORTED` utiliser des URLs distinctes par langue/region

### Quand ne pas utiliser `hreflang`

- site mono-langue sans variantes localisees
- pages uniques sans equivalent dans d'autres langues

## 6.10 Core Web Vitals

### Seuils

- `OFFICIAL` LCP <= 2.5 s
- `OFFICIAL` INP <= 200 ms
- `OFFICIAL` CLS <= 0.1

### Priorites d'optimisation

1. baisser TTFB et poids de la page
2. proteger l'element LCP
3. eliminer les deplacements de layout
4. casser les longues taches JS
5. reduire scripts tiers et travail principal sur le main thread

### Heuristiques utiles

- `SUPPORTED` `fetchpriority="high"` sur l'image hero
- `SUPPORTED` `priority` dans `<Image>` Next.js pour l'element LCP
- `SUPPORTED` `requestIdleCallback` ou traitement differe pour le non-critique
- `EXPERIMENTAL` certaines APIs recentes de scheduling peuvent aider mais ne doivent pas etre la seule strategie

## 6.11 AI features et bots

### Google Search AI features

- `OFFICIAL` AI Overviews et AI Mode restent sous le cadre Search classique
- `OFFICIAL` les preview controls de Google s'appliquent a ces experiences
- `SUPPORTED` contenu clair, utile, original, bien structure reste la meilleure strategie

### OpenAI bots

| Bot | Usage | Controle |
|---|---|---|
| `OAI-SearchBot` | apparition dans les reponses de recherche ChatGPT | robots.txt |
| `GPTBot` | entrainement des modeles | robots.txt |
| `ChatGPT-User` | actions utilisateur, navigation declenchee par demande | robots.txt pas toujours pertinent |

### Politique recommandee

- autoriser ce qui sert la decouverte voulue
- bloquer explicitement ce que l'on ne veut pas pour l'entrainement
- documenter cette politique dans le repo au lieu de la cacher dans un robots.txt non explique

Exemple minimal :

```txt
User-agent: OAI-SearchBot
Allow: /

User-agent: GPTBot
Disallow: /
```

## 6.12 Accessibilite

### Position robuste

- `OFFICIAL` ne pas la vendre comme facteur de ranking direct documente
- `SUPPORTED` la traiter comme un multiplicateur de qualite : structure, lisibilite, compatibilite mobile, clarté semantique, performance percue

### Checklist utile

- HTML semantique
- alt appropries
- headings ordonnes
- labels de formulaires
- focus visible
- contraste suffisant
- textes de liens descriptifs
- navigation clavier

## 6.13 Pagination

### Regles

- `OFFICIAL` donner une URL distincte a chaque page
- `OFFICIAL` chaque page a sa propre canonical
- `OFFICIAL` ne pas utiliser des fragments `#page=2` comme pagination indexable
- `SUPPORTED` preferer pagination classique ou load more qui garde des URLs crawlables

Exemple :

- `/blog`
- `/blog?page=2`
- `/blog?page=3`

## 6.14 Local SEO

- `OFFICIAL` utile seulement si le business a une dimension locale reelle
- `SUPPORTED` maintenir GBP, NAP coherent, pages locales propres, schema `LocalBusiness`
- `SUPPORTED` repondre aux avis et maintenir les horaires

---

## 7. Patterns Next.js fiables

## 7.1 Metadata API

- `FRAMEWORK` utiliser `metadata` ou `generateMetadata`
- `FRAMEWORK` les champs imbriques comme `openGraph` et `robots` sont ecrases par la definition la plus profonde si on ne fusionne pas soi-meme
- `FRAMEWORK` utiliser les metadata files pour `robots`, `sitemap`, `opengraph-image`, favicons, manifest

## 7.2 Fichiers a proteger de toute auth middleware

- `robots.txt`
- `sitemap.xml`
- `opengraph-image`
- `favicon*`
- `manifest.webmanifest`
- `.well-known/*`

## 7.3 Patterns a eviter

- metadata partielles ecrasant accidentellement un `openGraph` ou `robots` herite
- middleware qui renvoie une page login HTML sur `sitemap.xml`
- `ssr: false` sur hero copy, pricing, FAQ publique ou contenu article

---

## 8. Ce qui doit rester dans le skill, mais avec etiquette claire

### 8.1 Observations de teardown

Tu peux conserver les references du type :

- Stripe excelle sur l'i18n et les clusters linguistiques
- Linear est souvent propre sur la perf et la discipline metadata
- Crisp pousse loin certains details OG/JSON-LD

Mais elles doivent etre marquees `OBSERVED` et non converties en regles dures.

### 8.2 Statistiques tierces

Les chiffres sur :

- poids relatifs des facteurs SEO
- pourcentage de requetes avec AI Overviews
- gains moyens associes a la fraicheur ou a l'accessibilite

peuvent rester uniquement s'ils sont etiquetes `THIRD_PARTY` et separes des recommandations officielles.

### 8.3 Features experimentales

Tu peux garder :

- speculative loading
- certaines optimisations browser-recentes
- techniques avancées de prerender/prefetch

mais avec etiquette `EXPERIMENTAL` et une instruction de test avant generalisation.

---

## 9. Ce que la prochaine version devrait ajouter

### 9.1 Par profil de site

Scinder le skill en modules :

- SaaS marketing
- docs / developer portal
- ecommerce
- media / blog editorial
- local business

### 9.2 Par type de preuve

Pour chaque regle importante, ajouter :

- comment verifier en HTML source
- comment verifier en Search Console
- comment verifier en logs serveur
- comment verifier en CI

### 9.3 Gouvernance des suppressions Google

Ajouter une section :

```text
Deprecated / Removed by Google
- Sitelinks Search Box: removed in Search
- FAQ rich results: heavily reduced
- HowTo rich results: deprecated
- Other structured data removals: verify against official Search Gallery and blog changelog
```

### 9.4 Matrice de support

Ajouter un tableau :

| Surface | Google | Bing | Social | Next.js |
|---|---|---|---|---|
| canonical | oui | oui | non | oui |
| OG image | non direct | non direct | oui | oui |
| sitemap lastmod | oui | oui | non | oui |
| Indexing API | cas tres limites | n/a | non | n/a |

---

## 10. Checklists d'audit rapides

## 10.1 Audit 15 minutes

- page publique principale retourne 200
- `title` present, distinct, utile
- `description` presente
- canonical presente
- `robots` correct
- HTML source contient le contenu principal
- 1 seul `h1`
- OG image presente
- JSON-LD valide si utilise
- `sitemap.xml` et `robots.txt` accessibles

## 10.2 Audit 60 minutes

- verifier canonicals sur templates clefs
- verifier pagination
- verifier pages noindex
- verifier structured data par type de page
- verifier CWV sur pages top traffic
- verifier middleware / auth / SEO files
- verifier logs Googlebot sur URLs importantes
- verifier pages orphelines, 404, redirections

## 10.3 Audit avant mise en production

- pas de staging indexable
- pas de preview indexable
- pas de canonical vers domaine de test
- pas de `noindex` accidentel en prod
- pas de meta OG cassees par inheritance metadata
- pas de JSON-LD mensongere ou obsolete

---

## 11. Tests automatises recommandés

### 11.1 CI minimale

- Playwright ou equivalent pour :
  - `title`
  - meta description
  - canonical
  - presence d'un `h1`
  - presence d'un script JSON-LD parseable
  - attribut `lang`
- Lighthouse CI sur 2 a 5 templates critiques
- test simple `curl` pour `robots.txt` et `sitemap.xml`

### 11.2 Tests manuels obligatoires

- Rich Results Test si schema
- Search Console apres mise en prod
- validation preview sociale
- verification HTML source sans JS
- verification de l'URL canonique finale apres redirect

---

## 12. Version de base conseillée pour un site Next.js public

Si le temps est limite, faire au minimum ceci :

1. metadata propres par template
2. canonical partout
3. `noindex` sur zones privees
4. `robots.txt` et `sitemap.xml` natifs Next.js
5. OG image par template majeur
6. 1 bloc JSON-LD utile et correct par type de page
7. HTML source complet pour pages SEO
8. LCP / INP / CLS dans le vert sur homepage et 3 pages top traffic
9. tests CI de base
10. politique robots IA documentee

---

## 13. Resume executif

Ce skill doit servir a prendre de bonnes decisions, pas a accumuler des tactiques.

La version robuste du systeme repose sur 6 principes :

1. separer clairement l'officiel du probable
2. prioriser indexabilite et rendu avant les "tricks"
3. n'utiliser structured data que pour des types encore supportes et des donnees veridiques
4. traiter les AI features comme une extension du Search classique, pas comme une discipline magique
5. documenter explicitement la politique bots IA
6. maintenir le skill comme un document vivant avec revue reguliere

Un site SEO solide ne gagne pas parce qu'il a 100 recommandations de plus. Il gagne parce qu'il a peu de regles, mais des regles vraies, maintenues, et verifiees.
