---
name: seo
description: Complete SEO implementation guide — 28 parts covering meta tags, JSON-LD, Core Web Vitals (INP), AI Overviews/SGE, E-E-A-T, content SEO, image SEO, rendering strategy, AI crawler management, off-page/link building, entity SEO, accessibility, local SEO, log analysis, CI/CD testing, pagination, and more. Based on analysis of Stripe, Linear, Notion, Lemlist, Crisp + 2025-2026 research from 30+ authoritative sources.
user_invocable: true
---

# /seo — Guide SEO complet pour sites web modernes (2025-2026)

Ce skill contient TOUTES les connaissances SEO nécessaires pour optimiser un site web, basées sur :
- L'analyse directe du code source de 5 SaaS de référence (Stripe, Linear, Notion, Lemlist, Crisp)
- Les meilleures pratiques Google 2025-2026
- Les dernières recherches sur AI Overviews, INP, E-E-A-T, et les crawlers IA

**28 parties** — 1560 lignes — couvre tout du fondamental à l'avancé.

---

## PARTIE 1 — CHECKLIST SEO EXHAUSTIVE

Avant toute intervention SEO, vérifier chaque point de cette checklist. Cocher mentalement chaque item, implémenter ce qui manque.

### 1.1 Fondamentaux HTML

| Item | Obligatoire | Exemple |
|------|:-----------:|---------|
| `<html lang="xx">` | OUI | `lang="fr"`, `lang="en-us"` |
| `<html dir="ltr">` | Non (sauf RTL) | Crisp l'utilise même en LTR |
| `<meta charset="utf-8">` | OUI | Toujours en premier dans `<head>` |
| `<meta name="viewport">` | OUI | `width=device-width, initial-scale=1` |
| `<title>` unique par page | OUI | 50-60 caractères max |
| `<meta name="description">` unique | OUI | 120-160 caractères, avec mots-clés |
| `<link rel="canonical">` | OUI | URL absolue, même sur la homepage |
| `<meta name="robots">` | Recommandé | Voir section directives avancées |

### 1.2 Directives robots avancées (technique Crisp)

```html
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
```

En Next.js metadata API :
```js
robots: {
  index: true,
  follow: true,
  googleBot: {
    index: true,
    follow: true,
    'max-image-preview': 'large',   // Images affichées en grand dans les SERP
    'max-snippet': -1,              // Pas de limite sur la longueur du snippet
    'max-video-preview': -1,        // Pas de limite sur la preview vidéo
  },
},
```

**Impact** : Google affiche des résultats plus riches (images larges, snippets longs, previews vidéo complètes). Sans ces directives, Google peut limiter l'affichage.

### 1.3 Format Detection (technique Linear/Stripe)

Empêcher les navigateurs mobiles de transformer automatiquement du texte en liens cliquables :

```js
formatDetection: {
  email: false,
  address: false,
  telephone: false,
},
```

**Stripe** bloque `telephone` et `email`. **Linear** bloque tout (`telephone, date, address, email`). Recommandé pour tout site pro.

### 1.4 Pages à ne PAS indexer

| Route | Directive |
|-------|-----------|
| Dashboard / app authentifiée | `noindex, nofollow` |
| Pages d'auth (login, register) | `noindex, nofollow` |
| Pages API | `disallow` dans robots.txt |
| Pages admin | `noindex, nofollow` + `disallow` |

En Next.js, déclarer dans le layout du groupe de routes :
```js
export const metadata = {
  robots: { index: false, follow: false },
}
```

---

## PARTIE 2 — OPEN GRAPH & TWITTER CARDS

### 2.1 Open Graph complet (modèle Crisp — le plus complet observé)

```js
openGraph: {
  type: 'website',
  locale: 'fr_FR',
  url: 'https://example.com/',           // Explicite, pas implicite
  siteName: 'Mon SaaS',
  title: 'Mon SaaS — Tagline courte',    // <= 70 chars
  description: 'Description complète...', // <= 200 chars
  images: [{
    url: '/og-image.png',
    width: 1200,                          // Toujours déclarer les dimensions
    height: 630,                          // Facebook/LinkedIn utilisent ce ratio
    alt: 'Description de l\'image',
    type: 'image/png',                    // Crisp le déclare
  }],
  // Si multi-langue :
  // locale: { alternate: ['en', 'de', 'es'] },
},
```

### 2.2 Twitter Card

```js
twitter: {
  card: 'summary_large_image',           // Toujours summary_large_image
  site: '@moncompte',                    // Handle Twitter de la marque
  creator: '@fondateur',                 // Handle du créateur (Linear fait ça)
  title: 'Titre Twitter',
  description: 'Description Twitter',
  images: ['/og-image.png'],
},
```

**Note** : Sans `site` et `creator`, Twitter/X ne lie pas la card à un compte. Chaque site de référence sauf Lemlist a au moins `site`.

### 2.3 Spécifications image OG

| Plateforme | Taille recommandée | Ratio |
|------------|-------------------|-------|
| Facebook / LinkedIn | 1200 x 630 | 1.91:1 |
| Twitter/X | 1200 x 628 | ~1.91:1 |
| WhatsApp | 1200 x 630 | 1.91:1 |

**Format** : PNG ou JPG. Stripe utilise JPG avec `?q=80` (qualité réduite pour la vitesse). Crisp utilise PNG.

**Per-locale OG images** (technique Crisp avancée) : générer une image OG différente par langue. Crisp utilise `/__og-image__/static/fr/og.png`.

**Dynamic OG images en Next.js** (technique avancée) :
```tsx
// app/blog/[slug]/opengraph-image.tsx
import { ImageResponse } from 'next/og'

export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

export default async function Image({ params }) {
  const post = await getPost(params.slug)
  return new ImageResponse(
    <div style={{ fontSize: 64, background: '#04252F', color: '#ECF5F5',
      width: '100%', height: '100%', display: 'flex', alignItems: 'center',
      justifyContent: 'center', padding: 40 }}>
      {post.title}
    </div>
  )
}
```

### 2.4 Validation des previews sociales

| Outil | Usage |
|-------|-------|
| opengraph.xyz | Prévisualiser OG pour Facebook/LinkedIn/Twitter |
| Twitter/X | Tweeter un lien et vérifier la preview (le Card Validator est deprecié) |
| LinkedIn Post Inspector | linkedin.com/post-inspector/ |
| Facebook Sharing Debugger | developers.facebook.com/tools/debug/ |

**Note** : Le Twitter Card Validator (`cards-dev.twitter.com/validator`) est **mort** depuis 2023. Utiliser opengraph.xyz ou tweeter un lien.

---

## PARTIE 3 — JSON-LD STRUCTURED DATA

### 3.1 Architecture @graph recommandée

Utiliser un `@graph` unique contenant tous les schémas liés par `@id`. C'est le pattern de Stripe.

```js
const jsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    // 1. WebSite (obligatoire)
    {
      '@type': 'WebSite',
      '@id': 'https://example.com/#website',
      url: 'https://example.com',
      name: 'Mon SaaS',
      description: 'Description courte',
      inLanguage: 'fr-FR',
      publisher: { '@id': 'https://example.com/#organization' },
    },
    // 2. Organization (obligatoire pour Knowledge Panel)
    {
      '@type': 'Organization',
      '@id': 'https://example.com/#organization',
      name: 'Ma Société',
      url: 'https://example.com',
      logo: {
        '@type': 'ImageObject',
        url: 'https://example.com/logo.png',
      },
      sameAs: [
        'https://twitter.com/moncompte',
        'https://www.linkedin.com/company/moncompte',
        'https://www.youtube.com/@moncompte',
        'https://github.com/moncompte',
      ],
      contactPoint: {
        '@type': 'ContactPoint',
        email: 'contact@example.com',
        contactType: 'customer service',
        availableLanguage: 'French',
      },
      // Stripe ajoute 24 adresses physiques pour le local SEO :
      // location: [{ '@type': 'PostalAddress', ... }]
    },
    // 3. SoftwareApplication (pour les SaaS)
    {
      '@type': 'SoftwareApplication',
      name: 'Mon SaaS',
      url: 'https://example.com',
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Web',
      description: '...',
      offers: {
        '@type': 'AggregateOffer',
        priceCurrency: 'EUR',
        lowPrice: '0',
        highPrice: '149',
        offerCount: 3,
      },
      creator: { '@id': 'https://example.com/#organization' },
    },
    // 4. FAQPage (structure pour les moteurs, mais ne génère plus de rich results)
    {
      '@type': 'FAQPage',
      mainEntity: [
        {
          '@type': 'Question',
          name: 'Question ?',
          acceptedAnswer: {
            '@type': 'Answer',
            text: 'Réponse complète.',
          },
        },
      ],
    },
    // 5. VideoObject (si vidéo présente — éligible aux rich results vidéo)
    {
      '@type': 'VideoObject',
      name: 'Titre de la vidéo',
      description: 'Description complète de la vidéo.',
      thumbnailUrl: 'https://img.youtube.com/vi/VIDEO_ID/maxresdefault.jpg',
      uploadDate: '2026-01-15',
      contentUrl: 'https://www.youtube.com/watch?v=VIDEO_ID',
      embedUrl: 'https://www.youtube-nocookie.com/embed/VIDEO_ID',
      inLanguage: 'fr',
      // duration: 'PT5M30S',  // ISO 8601 si connu
    },
    // 6. BreadcrumbList (navigation hiérarchique)
    {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Accueil', item: 'https://example.com/' },
        { '@type': 'ListItem', position: 2, name: 'Blog', item: 'https://example.com/blog' },
        { '@type': 'ListItem', position: 3, name: 'Titre article' },
      ],
    },
  ],
}
```

### 3.2 Schémas par type de page

| Page | Schémas recommandés |
|------|-------------------|
| Homepage / Landing | WebSite, Organization, SoftwareApplication, FAQPage, VideoObject |
| Blog post | WebSite, Organization, Article, BreadcrumbList, Person (author) |
| Page produit | WebSite, Organization, Product, BreadcrumbList |
| Page contact | WebSite, Organization, ContactPage |
| Page pricing | WebSite, Organization, SoftwareApplication (avec Offers détaillées) |
| Tutoriel / Guide | WebSite, Organization, HowTo, BreadcrumbList |
| Page auteur | WebSite, Organization, ProfilePage, Person |
| Service local | WebSite, Organization, LocalBusiness, Service |

### 3.3 aggregateRating — ATTENTION aux règles Google

Crisp utilise `aggregateRating` sur `WebApplication` et affiche des étoiles dans les SERP.

**MAIS** : Google documente que `aggregateRating` n'est éligible aux rich results que sur certains types spécifiques : `Product`, `Recipe`, `Book`, `Course`, `Event`, `LocalBusiness`. L'utiliser sur `SoftwareApplication` peut :
- Fonctionner dans la pratique (Crisp le prouve)
- Être considéré comme une violation des guidelines
- Cesser de fonctionner sans préavis

**Recommandation** : n'utiliser que si les avis sont réels (Trustpilot, G2, Google Reviews) et être prêt à le retirer si Google change sa politique.

### 3.4 FAQPage — Rich results dépréciés (août 2023)

Google a **significativement réduit** les rich results FAQ en août 2023. Ils n'apparaissent plus que pour les sites gouvernementaux et de santé bien établis. Pour les autres sites :
- Le schéma FAQPage reste utile pour la **compréhension structurelle** par les moteurs
- Il aide les **AI Overviews** à extraire des réponses
- Mais il ne **génèrera plus d'affichage spécial** dans les SERP classiques

### 3.5 Schémas émergents (2025-2026)

**Speakable** (beta) — identifie les sections adaptées aux assistants vocaux :
```json
{
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".article-headline", ".article-summary"]
  }
}
```
Limité à 20-30 secondes de texte (~2-3 phrases). U.S. English seulement pour l'instant.

**Schémas dépréciés par Google (janvier 2026)** : Practice Problem, Dataset, Sitelinks Search Box, SpecialAnnouncement, Q&A.

### 3.6 Injection en Next.js

```jsx
<script
  type="application/ld+json"
  dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
/>
```

Placer en premier enfant du composant page, avant le contenu visible.

Pour les pages dynamiques, utiliser `generateMetadata` + `cache()` pour partager les données :
```js
import { cache } from 'react'
export const getPost = cache(async (slug) => {
  return await db.query.posts.findFirst({ where: eq(posts.slug, slug) })
})
```

---

## PARTIE 4 — SITEMAP & ROBOTS

### 4.1 Sitemap (convention Next.js)

```js
// src/app/sitemap.js
export default function sitemap() {
  return [
    {
      url: 'https://example.com',
      lastModified: '2026-03-30',     // TOUJOURS inclure lastmod
      changeFrequency: 'weekly',      // Ignoré par Google, utile pour Bing
      priority: 1.0,                  // Ignoré par Google, utile pour Bing
    },
    {
      url: 'https://example.com/pricing',
      lastModified: '2026-03-15',
      changeFrequency: 'monthly',
      priority: 0.8,
    },
  ]
}
```

**Règles** :
- Toujours inclure `lastModified` (Google priorise le crawl des pages récentes)
- `changeFrequency` et `priority` sont **ignorés par Google** (confirmé officiellement). Bing les utilise encore. Les inclure ne fait pas de mal.
- Ne PAS inclure les pages `noindex`
- Ne PAS inclure les routes API
- Inclure uniquement les pages publiques indexables
- Mettre à jour `lastModified` à chaque modification substantielle du contenu
- Pour les sites avec 50,000+ URLs : utiliser un sitemap index

**Sitemap dynamique** (pour blogs, produits) :
```js
export default async function sitemap() {
  const posts = await getAllPosts()
  return [
    { url: 'https://example.com', lastModified: '2026-03-30', priority: 1.0 },
    ...posts.map(p => ({
      url: `https://example.com/blog/${p.slug}`,
      lastModified: p.updatedAt ?? p.date,
      changeFrequency: 'weekly',
      priority: 0.7,
    })),
  ]
}
```

### 4.2 Robots.txt (convention Next.js)

```js
// src/app/robots.js
export default function robots() {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/dashboard', '/api/', '/admin', '/login', '/register'],
      },
      // Bloquer les crawlers d'entraînement IA (voir Partie 15)
      { userAgent: 'GPTBot', disallow: '/' },
      { userAgent: 'Google-Extended', disallow: '/' },
      { userAgent: 'anthropic-ai', disallow: '/' },
      { userAgent: 'CCBot', disallow: '/' },
    ],
    sitemap: 'https://example.com/sitemap.xml',
  }
}
```

### 4.3 Middleware — Ne pas bloquer les fichiers SEO

Si un middleware auth protège les routes (comme next-auth), **exclure** :
- `sitemap` (sinon Google reçoit une page HTML de login au lieu du XML)
- `robots`
- `og-image`
- `favicon`
- `manifest`
- `.well-known`

```js
export const config = {
  matcher: ['/((?!login|register|api/auth|_next|favicon|manifest|sitemap|robots|og-image|\\.well-known).+)'],
}
```

---

## PARTIE 5 — HREFLANG & INTERNATIONALISATION

### 5.1 Site mono-langue

Même pour un site en une seule langue, déclarer `hreflang` + `x-default` :

```js
alternates: {
  canonical: '/',
  languages: {
    'fr': '/',
    'x-default': '/',
  },
},
```

**Pourquoi** : ça signale explicitement l'intention linguistique à Google. Sans ça, Google doit deviner.

### 5.2 Site multi-langue (modèle Stripe — 92+ hreflang)

Stripe est la référence absolue avec des entrées par pays+langue :

```html
<link rel="alternate" hreflang="x-default" href="https://stripe.com" />
<link rel="alternate" hreflang="en-US" href="https://stripe.com" />
<link rel="alternate" hreflang="fr-FR" href="https://stripe.com/fr" />
<link rel="alternate" hreflang="fr-CA" href="https://stripe.com/fr-ca" />
```

En Next.js :
```js
alternates: {
  canonical: 'https://example.com/',
  languages: {
    'x-default': 'https://example.com/',
    'fr': 'https://example.com/fr',
    'en': 'https://example.com/en',
    'fr-CA': 'https://example.com/fr-ca',
  },
},
```

### 5.3 og:locale:alternate (technique Crisp)

```js
openGraph: {
  locale: 'fr_FR',
  // alternateLocale: ['en_US', 'de_DE', 'es_ES'],  // Quand multi-langue
},
```

---

## PARTIE 6 — CORE WEB VITALS (LCP, CLS, INP)

**Les 3 métriques essentielles** que Google utilise comme facteur de ranking.

### 6.1 LCP — Largest Contentful Paint (cible : <= 2.5s)

L'élément le plus gros visible dans le viewport (souvent l'image hero ou le h1).

**Optimisations** :
- `priority` sur l'image hero en Next.js (`<Image priority />`)
- `fetchpriority="high"` sur les images HTML natives
- **Ne JAMAIS lazy-load l'image LCP** (35% de LCP plus lent si lazy-load sur LCP — Chrome UX Report 2024)
- Réduire le TTFB (Time to First Byte) : cible < 200ms
- Précharger les fonts critiques
- Éliminer le render-blocking CSS/JS
- Utiliser un CDN (Vercel, Cloudflare)
- Compression Brotli > gzip

### 6.2 CLS — Cumulative Layout Shift (cible : <= 0.1)

Mesure les décalages visuels inattendus pendant le chargement.

**Causes fréquentes et solutions** :
- Images sans dimensions → toujours `width` et `height` ou `aspect-ratio` CSS
- Fonts qui provoquent un reflow → `font-display: swap` + `size-adjust`
- Contenu injecté dynamiquement au-dessus du fold → réserver l'espace avec des placeholders
- Publicités / iframes sans dimensions → définir un conteneur fixe
- Animations CSS qui changent `top`/`left`/`width`/`height` → utiliser `transform` à la place

### 6.3 INP — Interaction to Next Paint (cible : <= 200ms)

**INP a remplacé FID en mars 2024.** FID est complètement déprécié.

Différence clé : FID ne mesurait que le délai avant la première interaction. INP mesure **toutes les interactions** (clicks, taps, clavier) et rapporte la pire.

**Optimisations** :

```js
// 1. Découper les longues tâches avec scheduler.yield() (Chrome 129+)
async function handleClick() {
  updateUI()                    // Visuel d'abord
  await scheduler.yield()       // Laisser le navigateur respirer
  logAnalytics()                // Non-critique après
}

// 2. Fallback pour navigateurs plus anciens
async function processLargeArray(items, chunkSize = 100) {
  for (let i = 0; i < items.length; i += chunkSize) {
    items.slice(i, i + chunkSize).forEach(processItem)
    await new Promise(resolve => setTimeout(resolve, 0))
  }
}

// 3. requestIdleCallback pour le travail non-critique
button.addEventListener('click', () => {
  updateButtonState()  // Critique : immédiat
  if ('requestIdleCallback' in window) {
    requestIdleCallback(() => logAnalytics('button_click'))
  }
})
```

**Autres techniques** :
- Réduire le JavaScript total (bundle analysis, tree shaking)
- Déplacer le travail lourd dans des Web Workers
- `defer` ou `async` sur les scripts non-critiques
- Minimiser les scripts tiers (analytics, chat, etc.)

### 6.4 Mesurer les Core Web Vitals

| Outil | Données | Usage |
|-------|---------|-------|
| PageSpeed Insights | Terrain + Lab | pagespeed.web.dev |
| Google Search Console | Terrain (CrUX) | Rapport Core Web Vitals |
| Chrome DevTools | Lab | Onglet Performance |
| Lighthouse | Lab | Audit complet |
| web-vitals.js | Terrain | Librairie JS pour mesure en prod |

---

## PARTIE 7 — PERFORMANCE & RESOURCE HINTS

### 7.1 Preconnect + DNS-Prefetch (pattern Stripe)

Pour chaque domaine tiers critique, toujours le **duo** preconnect + dns-prefetch (compatibilité maximale) :

```html
<link rel="preconnect" href="https://js.stripe.com" />
<link rel="dns-prefetch" href="https://js.stripe.com" />
```

**Domaines typiques à préconnecter** :
- Paiement : `https://js.stripe.com`
- Vidéo : `https://img.youtube.com` (thumbnails)
- Analytics : `https://www.google-analytics.com`
- CDN images : Contentful, Cloudinary, etc.

**Ne PAS préconnecter** les fonts Google si vous utilisez `next/font/google` (déjà self-hosted).

### 7.2 Preload (modèle Linear/Notion)

```html
<link rel="preload" href="/fonts/Inter.woff2" as="font" type="font/woff2" crossorigin="anonymous" />
<link rel="preload" href="/hero.webp" as="image" />
```

En Next.js : utiliser `priority` prop sur `<Image>` pour le preload automatique de l'image hero.

### 7.3 Cache-Control pour assets statiques

```js
// next.config.js
async headers() {
  return [
    {
      source: '/_next/static/(.*)',
      headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
    },
    {
      source: '/(.+\\.(?:png|jpg|jpeg|webp|avif|ico|svg|woff2?))',
      headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
    },
  ]
}
```

Pour les pages HTML dynamiques, utiliser `stale-while-revalidate` :
```
Cache-Control: public, s-maxage=3600, stale-while-revalidate=86400
```

### 7.4 YouTube Embed — Facade Pattern

Ne JAMAIS charger un iframe YouTube au chargement. Facade : thumbnail + bouton play, iframe au clic.

```jsx
'use client'
import { useState } from 'react'
export default function YouTubeEmbed({ videoId, title }) {
  const [loaded, setLoaded] = useState(false)
  if (loaded) return (
    <iframe src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1`}
      title={title} allow="autoplay; encrypted-media" allowFullScreen
      className="w-full aspect-video" />
  )
  return (
    <button onClick={() => setLoaded(true)} className="relative w-full aspect-video">
      <img src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
        alt={title} className="w-full h-full object-cover" loading="lazy" />
    </button>
  )
}
```

**Impact** : -500KB JS, meilleur LCP/TBT. **CSP** : ajouter `https://www.youtube-nocookie.com` dans `frame-src`.

### 7.5 Speculative Loading (Chrome 2024+)

```html
<script type="speculationrules">
{
  "prefetch": [{ "where": { "href_matches": "/blog/*" }, "eagerness": "moderate" }],
  "prerender": [{ "where": { "selector_matches": "a[data-prerender]" }, "eagerness": "moderate" }]
}
</script>
```

Pré-rend les pages avant que l'utilisateur ne clique. Navigation quasi-instantanée.

---

## PARTIE 8 — IMAGE SEO

### 8.1 Règles fondamentales

| Règle | Pourquoi |
|-------|----------|
| `alt` descriptif sur toutes les images | Accessibilité + SEO (Google Image Search) |
| Noms de fichiers descriptifs | `serrurier-urgence.webp` pas `IMG_4532.webp` |
| Toujours `width` + `height` | Prévient le CLS |
| `loading="lazy"` sauf image LCP | Réduit le payload initial |
| `fetchpriority="high"` sur image LCP | Accélère le LCP |
| Format WebP ou AVIF | WebP : -25-34% vs JPEG, AVIF encore mieux |

### 8.2 Images responsives

```html
<!-- Image hero (LCP) : PAS de lazy loading, priorité haute -->
<picture>
  <source type="image/avif" srcset="hero.avif" />
  <source type="image/webp" srcset="hero.webp" />
  <img src="hero.jpg" alt="Description" width="1600" height="600" fetchpriority="high" />
</picture>

<!-- Image below-fold : lazy loading -->
<picture>
  <source type="image/webp"
    srcset="photo-400.webp 400w, photo-800.webp 800w, photo-1200.webp 1200w"
    sizes="(max-width: 700px) 100vw, 800px" />
  <img src="photo-800.jpg" alt="Description" width="800" height="600" loading="lazy" />
</picture>
```

En Next.js, `<Image>` gère automatiquement srcset, lazy loading, et formats modernes.

### 8.3 Ce que Google indexe / n'indexe PAS

- Google indexe : `<img>`, `<picture>`, `<source>`, `<svg>`, `<video poster>`
- Google n'indexe **PAS** : images CSS (`background-image`)
- Formats supportés : PNG, JPG, WebP, AVIF, GIF, SVG, BMP
- Soumettre un sitemap image si les images sont sur un CDN externe

---

## PARTIE 9 — CONTENT SEO

### 9.1 Hiérarchie des headings

```
h1 — Un seul par page, contient le mot-clé principal
  h2 — Sections principales
    h3 — Sous-sections
      h4 — Détails (rarement nécessaire)
```

**Règles** :
- Ne jamais sauter un niveau (pas de h1 → h3)
- Le `h1` doit correspondre au `<title>` (pas identique, mais même sujet)
- Les `h2` structurent le contenu pour les featured snippets

### 9.2 HTML sémantique

```html
<main>           <!-- Contenu principal, un seul par page -->
<article>        <!-- Contenu autonome (blog post, produit) -->
<section>        <!-- Groupe thématique avec un heading -->
<nav>            <!-- Navigation -->
<aside>          <!-- Contenu secondaire (sidebar, related) -->
<header>         <!-- En-tête de page ou de section -->
<footer>         <!-- Pied de page -->
```

**Impact** : le HTML sémantique aide Google (et les AI Overviews) à comprendre la structure du contenu.

### 9.3 Keyword placement

1. Dans le `<title>` (en premier si possible)
2. Dans le `<h1>`
3. Dans le premier paragraphe (les 100 premiers mots)
4. Dans les `<h2>` (variations naturelles)
5. Dans les `alt` des images
6. Dans l'URL slug
7. Dans la meta description (pas un facteur de ranking, mais affiché en gras dans les SERP si match)

### 9.4 Contenu optimisé pour les Featured Snippets

**Paragraph snippet** (40-60 mots) :
```html
<h2>Qu'est-ce que [sujet] ?</h2>
<p><strong>[Sujet] est [réponse directe en 40-60 mots].</strong></p>
```

**List snippet** :
```html
<h2>Comment [faire X] ?</h2>
<ol>
  <li>Étape 1 : ...</li>
  <li>Étape 2 : ...</li>
</ol>
```

**Table snippet** :
```html
<h2>Comparaison [A] vs [B]</h2>
<table><thead>...</thead><tbody>...</tbody></table>
```

### 9.5 Fraîcheur du contenu

Le poids de la "freshness" dans l'algorithme Google est passé de <1% à **6%** en 2025 — la plus forte hausse de tous les facteurs. Les pages mises à jour au moins une fois par an gagnent en moyenne 4.6 positions.

- Afficher `dateModified` visuellement sur la page
- Inclure `datePublished` et `dateModified` dans le schema Article
- Mettre à jour `lastModified` dans le sitemap

---

## PARTIE 10 — E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness)

Avec l'explosion du contenu IA, E-E-A-T est le principal différenciateur de qualité pour Google.

### 10.1 Trust (le plus important)

| Signal | Implémentation |
|--------|---------------|
| HTTPS + HSTS | Headers de sécurité (voir Partie 12) |
| Mentions légales | Page CGU + politique de confidentialité |
| Contact réel | Adresse email, formulaire, téléphone |
| SIREN/SIRET visible | Footer ou mentions légales |
| Avis externes | Google Reviews, Trustpilot, G2 (pas self-hosted) |

### 10.2 Experience + Expertise

| Signal | Implémentation |
|--------|---------------|
| Auteur identifié | Byline avec nom, titre, photo |
| Page auteur dédiée | `/team/nom` avec bio, credentials, liens |
| Schema Person | `author: { '@type': 'Person', name, jobTitle, worksFor, url }` |
| Données propriétaires | Études de cas avec chiffres réels (anonymisés si besoin) |
| "Reviewed by" | Badge avec expert + date de review |

### 10.3 Authoritativeness

- Backlinks de sites autoritaires (.edu, .gov, presse, sites sectoriels)
- Mentions (même sans lien) sur des sources fiables
- Présence cohérente : site principal + profils sociaux + annuaires
- Schema `sameAs` avec tous les profils vérifiés
- Google Business Profile à jour

---

## PARTIE 11 — RENDERING & SEO (CSR vs SSR vs SSG)

### 11.1 Impact sur le SEO

| Stratégie | SEO | Pourquoi |
|-----------|-----|----------|
| **SSG** (Static Site Generation) | Excellent | HTML pré-généré, TTFB minimal, crawlable instantanément |
| **SSR** (Server-Side Rendering) | Très bon | HTML complet à chaque requête, bon pour contenu dynamique |
| **ISR** (Incremental Static Regen) | Très bon | SSG + mises à jour périodiques, idéal pour blogs/produits |
| **CSR** (Client-Side Rendering) | Risqué | Googlebot peut render JS mais avec délai, budget crawl, incohérences |

### 11.2 Vérifier que le contenu est dans le HTML source

```bash
# Le contenu SEO doit apparaître dans le HTML brut, pas seulement après JS
curl -s https://example.com | grep -i "mot-clé important"
```

Si le contenu n'apparaît qu'après exécution JS → problème SEO.

### 11.3 Next.js spécifique

- Les Server Components n'envoient **zero JS client** pour le contenu statique → parfait pour SEO
- `next/dynamic` avec `ssr: false` = contenu **invisible** pour les crawlers → ne jamais l'utiliser pour du contenu SEO
- `generateStaticParams()` → pré-génère les pages au build (SSG)
- Next.js 15+ : streaming metadata, mais **bloque pour les bots** (Googlebot, Twitterbot, etc.)

---

## PARTIE 12 — SECURITY HEADERS & SEO

### 12.1 Headers recommandés

```js
headers: [
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
]
```

### 12.2 Content Security Policy (CSP)

```js
{
  key: 'Content-Security-Policy',
  value: [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' https://js.stripe.com",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob: https:",
    "connect-src 'self' https://*.example.com https://api.stripe.com",
    "frame-src https://js.stripe.com https://www.youtube-nocookie.com",
    "worker-src 'self' blob:",
    "manifest-src 'self'",
  ].join('; '),
}
```

**Attention** : une CSP trop restrictive bloque Google Analytics, GTM, conversion tracking. Vérifier que tous les scripts tiers sont autorisés.

### 12.3 Redirect canonique (domaine unique)

```js
async redirects() {
  return [{
    source: '/:path*',
    has: [{ type: 'host', value: 'ancien-domaine.com' }],
    destination: 'https://nouveau-domaine.com/:path*',
    permanent: true,  // 301
  }]
}
```

**Critique** : sans redirect 301, Google indexe les deux domaines et dilue l'autorité.

---

## PARTIE 13 — URL STRUCTURE

### 13.1 Règles

| Règle | Bon | Mauvais |
|-------|-----|---------|
| Tirets, pas underscores | `/mon-article` | `/mon_article` |
| Lowercase uniquement | `/pricing` | `/Pricing` |
| Court et descriptif | `/blog/seo-guide` | `/blog/2026/03/30/the-ultimate-guide-to-seo` |
| Pas de paramètres pour contenu indexable | `/produit/chaise` | `/produit?id=123` |
| Hiérarchie logique | `/blog/category/slug` | `/p/x7f2k` |

### 13.2 Trailing slash

Choisir une convention (avec ou sans `/` final) et rediriger l'autre :
```js
// next.config.js
trailingSlash: false, // ou true — être cohérent
```

### 13.3 Redirections

| Code | Usage | SEO |
|------|-------|-----|
| 301 | Redirect permanent | Transfère ~95% du link equity |
| 302 | Redirect temporaire | Ne transfère PAS le link equity |
| 308 | Permanent (préserve la méthode HTTP) | Comme 301 |
| 307 | Temporaire (préserve la méthode HTTP) | Comme 302 |

**Éviter les chaînes** : A→B→C doit devenir A→C directement. Maximum 1 hop.

---

## PARTIE 14 — INTERNAL LINKING

### 14.1 Principes

- Chaque page indexable doit être accessible en **3-4 clics max** depuis la homepage
- Anchor text descriptif : `"guide SEO complet"` au lieu de `"cliquez ici"`
- Liens contextuels dans le corps du texte (plus de poids que sidebar/footer)
- Éviter les pages orphelines (dans le sitemap mais sans lien interne)

### 14.2 Architecture Hub-and-Spoke

```
Homepage
  └── /blog (hub)
        ├── /blog/seo-guide (spoke)
        ├── /blog/core-web-vitals (spoke)
        └── /blog/structured-data (spoke)
            (tous les spokes linkent vers le hub et entre eux)
```

### 14.3 Breadcrumbs

Implémenter visuellement ET en schema `BreadcrumbList` (voir Partie 3.1).

---

## PARTIE 15 — AI OVERVIEWS & CRAWLERS IA (2025-2026)

### 15.1 Google AI Overviews

Apparaissent pour ~18.57% des requêtes commerciales. CTR position 1 baisse de 40-60% quand un AI Overview est affiché.

**Comment être cité** :
- Réponse directe en 30-50 mots **juste après le heading**
- Listes, tableaux, comparaisons (l'IA extrait facilement ce format)
- Données propriétaires avec sources
- Contenu complet et long (l'IA a besoin de matière pour générer des résumés)
- FAQ structurées (même sans rich results, l'IA les exploite)

**Contrôler son apparition** :
```html
<!-- Bloquer l'apparition dans les AI features -->
<meta name="robots" content="nosnippet">

<!-- Bloquer une section spécifique -->
<span data-nosnippet>Ce contenu ne sera pas dans les AI features</span>

<!-- Limiter la longueur du snippet -->
<meta name="robots" content="max-snippet:300">
```

### 15.2 AI Mode (Google, 2026)

Interface conversationnelle séparée (google.com/aimode) :
- Pas de résultats organiques, seulement du contenu IA avec citations
- ~12.6 liens par réponse
- Seulement **53.68% de chevauchement** avec les résultats organiques classiques
- Optimisation = même que AI Overviews : contenu structuré, autoritaire, citable

### 15.3 Gestion des crawlers IA dans robots.txt

**Distinction clé** : crawlers d'**entraînement** (volent votre contenu) vs crawlers de **recherche** (citent votre contenu).

```txt
# ===== CRAWLERS D'ENTRAÎNEMENT IA — BLOQUER =====
User-agent: GPTBot
Disallow: /

User-agent: Google-Extended
Disallow: /

User-agent: anthropic-ai
Disallow: /

User-agent: CCBot
Disallow: /

User-agent: Bytespider
Disallow: /

User-agent: cohere-ai
Disallow: /

User-agent: Applebot-Extended
Disallow: /

# ===== CRAWLERS DE RECHERCHE IA — AUTORISER (pour être cité) =====
User-agent: OAI-SearchBot
Allow: /

User-agent: ChatGPT-User
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: Claude-SearchBot
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: DuckAssistBot
Allow: /
```

---

## PARTIE 16 — PWA & MANIFEST

### 16.1 Manifest.json

```json
{
  "name": "Mon SaaS",
  "short_name": "SaaS",
  "description": "Description complète",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "background_color": "#042830",
  "theme_color": "#04252F",
  "lang": "fr",
  "orientation": "any",
  "categories": ["business", "productivity"],
  "icons": [
    { "src": "/icon-192x192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512x512.png", "sizes": "512x512", "type": "image/png" },
    { "src": "/icon-maskable-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

**Cohérence critique** : `theme_color` dans manifest DOIT correspondre à `themeColor` dans le viewport metadata.

### 16.2 Favicons — Couverture recommandée

| Fichier | Usage |
|---------|-------|
| `favicon.ico` | Navigateurs legacy, onglets |
| `favicon-32x32.png` | Onglets modernes |
| `favicon-16x16.png` | Barre de favoris |
| `apple-touch-icon.png` (180x180) | iOS home screen |
| `icon-192x192.png` | Android / PWA |
| `icon-512x512.png` | PWA splash screen |

Minimum recommandé : 5 (ico + 32 + 16 + apple-touch + 512).

---

## PARTIE 17 — MOBILE-FIRST INDEXING

Google utilise la version **mobile** comme version principale pour l'indexation depuis 2023.

### 17.1 Checklist

| Item | Seuil |
|------|-------|
| Contenu identique mobile/desktop | Pas de `display:none` sur du contenu SEO |
| Font size minimum | 16px body |
| Touch targets | 48x48px minimum |
| Pas de scroll horizontal | `overflow-x: hidden` si nécessaire |
| Viewport correct | `width=device-width, initial-scale=1` |
| Images responsives | `srcset` ou Next.js `<Image>` |

### 17.2 Test

- Google Mobile-Friendly Test (deprecated en 2023, mais Lighthouse le couvre)
- Chrome DevTools → Device Mode → tester sur différentes tailles
- Google Search Console → rapport "Ergonomie mobile"

---

## PARTIE 18 — ERREURS TECHNIQUES & REDIRECTIONS

### 18.1 Pages 404

```jsx
// app/not-found.jsx (Next.js)
export default function NotFound() {
  return (
    <div>
      <h1>Page introuvable</h1>
      <p>Liens utiles :</p>
      <nav>
        <a href="/">Accueil</a>
        <a href="/blog">Blog</a>
      </nav>
    </div>
  )
}
```

**Règles** :
- Retourner un vrai **HTTP 404** (pas un 200 avec "page non trouvée" = soft 404)
- Utiliser **410 Gone** pour le contenu définitivement supprimé (signal plus fort que 404)
- Monitorer les 404 dans Google Search Console → onglet "Pages"

### 18.2 Soft 404

Google détecte les pages qui retournent 200 mais semblent vides ou en erreur. Causes :
- Page de recherche sans résultat
- Page de profil d'un utilisateur supprimé
- Redirection vers la homepage au lieu d'un 404

### 18.3 Chaînes de redirections

Auditer régulièrement : pas de A→B→C. Maximum 1 hop.

---

## PARTIE 19 — TECHNIQUES AVANCÉES

### 19.1 Google Search Console features (2025-2026)

| Feature | Date | Usage |
|---------|------|-------|
| AI-Powered Configuration | Fév 2026 | Requêtes en langage naturel |
| Weekly/Monthly Views | Déc 2025 | Lissage du bruit quotidien |
| Custom Chart Annotations | Nov 2025 | Marquer les déploiements |
| Branded Queries Filter | Nov 2025 | Séparer trafic marque vs discovery |
| Query Groups | Oct 2025 | Clustering automatique par thème |

### 19.2 Google Indexing API

Pour un indexing plus rapide (officiel pour Job Postings et Livestreams, mais fonctionne pour tout) :
- Google Cloud project + service account + vérification Search Console
- `URL_UPDATED` / `URL_DELETED` notification types
- Limite : 200 requêtes/jour/propriété
- Complémentaire au sitemap, pas un remplacement

**IndexNow** (Bing, Yandex — pas Google) : ping immédiat quand une page change.

### 19.3 iOS Smart App Banner (technique Notion)

```html
<meta name="apple-itunes-app" content="app-id=1232780281" />
```

### 19.4 Server-side Geo-adaptation (technique Stripe)

```html
<meta name="request-country" content="FR" />
```
Adapte `<html lang>`, contenu, et OG image par pays. Nécessite un edge middleware.

### 19.5 CSS Lazy Loading (technique Lemlist)

```html
<link rel="stylesheet" href="/toast.css" media="print" />
```
Non-bloquant au chargement. Basculé en `media="all"` via JS quand nécessaire.

---

## PARTIE 20 — ANTI-PATTERNS, COMPARATIF & PROCÉDURE

### 20.1 Anti-patterns SEO (Lemlist = contre-exemple)

| Anti-pattern | Problème |
|-------------|----------|
| `description` = `title` | Gaspille l'espace SERP |
| Pas de `canonical` | Google indexe des doublons |
| Pas de JSON-LD | Aucune chance de rich snippets |
| Lazy-load sur image LCP | 35% de LCP plus lent |
| Contenu SEO en CSR pur | Crawl incomplet par Googlebot |
| Soft 404 (200 + page vide) | Pages fantômes dans l'index |
| Chaînes de redirects | Perte de link equity |
| Ignorer INP | Mauvais score Core Web Vitals (FID est mort) |
| `theme_color` incohérent manifest/metadata | Chrome affiche une couleur bizarre |
| 40+ image preloads | Surcharge le navigateur |

### 20.2 Comparatif des 5 sites de référence

| Feature | Stripe | Linear | Notion | Lemlist | Crisp |
|---------|--------|--------|--------|---------|-------|
| `lang` | `fr-FR` (geo) | `en` | `en-us` | `en` | `fr` |
| description | Localisée | Courte | IA-focused | = title | Longue, riche |
| Canonical | Oui | Oui | Oui | **NON** | Oui |
| Hreflang | **92+** | 0 | 19 | 0 | 10 |
| OG complet | Bon | Bon | Excellent | Basique | **Meilleur** |
| JSON-LD | WebSite + Org | Aucun | Aucun | Aucun | **3 blocs** |
| aggregateRating | Non | Non | Non | Non | **Oui** |
| Preconnect | 4 paires | 3 | 2 | 0 | 0 |
| PWA manifest | Non | **Oui** | Non | Non | Non |
| Favicons | 2 | 3 | 2 | 1 | **12** |
| formatDetection | tel, email | **Tout** | Non | Non | Non |

**Meilleur SEO global** : Crisp
**Meilleure performance** : Linear
**Meilleure i18n** : Stripe
**Contre-exemple** : Lemlist

### 20.3 Ranking Factors Google 2025 (source : First Page Sage)

| Facteur | Poids | Tendance |
|---------|-------|----------|
| Contenu satisfaisant et régulier | 23% | Stable #1 |
| Mot-clé dans le title | 14% | -1% |
| Backlinks | 13% | -2% (en baisse, IA comprend mieux la qualité) |
| Expertise de niche | 13% | Stable |
| Engagement utilisateur | 12% | +1% |
| **Fraîcheur** | **6%** | **+5% (plus forte hausse)** |
| Mobile-first | 5% | Stable |
| Trust | 4% | Stable |
| Diversité des liens | 3% | Stable |
| Vitesse de page | 3% | Stable |
| SSL/HTTPS | 2% | Stable |
| Liens internes | 1% | -1% |

### 20.4 Ordre d'implémentation recommandé

1. **Title + Description** uniques par page
2. **Canonical URLs** sur chaque page publique
3. **robots.txt + sitemap.xml** avec lastmod
4. **Open Graph + Twitter Card** complets
5. **JSON-LD** : WebSite + Organization + type spécifique
6. **Core Web Vitals** : LCP < 2.5s, CLS < 0.1, INP < 200ms
7. **Robots directives avancées** (max-image-preview, max-snippet, max-video-preview)
8. **Preconnect + dns-prefetch** pour domaines tiers
9. **Cache-Control** pour assets statiques
10. **Hreflang** (même mono-langue)
11. **Image SEO** (alt, formats, lazy/eager, dimensions)
12. **Content SEO** (headings, semantic HTML, featured snippets)
13. **E-E-A-T signals** (auteur, trust, expertise)
14. **AI crawler management** dans robots.txt
15. **Manifest cohérent** (theme_color, background_color)
16. **Google Search Console** verification + soumettre sitemap
17. **Contenu optimisé AI Overviews** (réponses directes, listes, tableaux)

### 20.5 Validation post-implémentation

```bash
# 1. Vérifier sitemap accessible (pas bloqué par middleware)
curl -s -o /dev/null -w "%{http_code}" https://example.com/sitemap.xml
# Attendu : 200

# 2. Vérifier les meta tags
curl -s https://example.com | grep -E '<(title|meta|link rel="canonical")' | head -20

# 3. Tester l'OG image
curl -s -o /dev/null -w "%{http_code}" https://example.com/og-image.png

# 4. Vérifier le contenu dans le HTML source (pas juste JS-rendered)
curl -s https://example.com | grep -i "mot-clé principal"

# 5. Valider le JSON-LD
# -> https://validator.schema.org/ ou https://search.google.com/test/rich-results

# 6. Tester les previews sociales
# -> https://opengraph.xyz/ (Facebook/LinkedIn/Twitter)

# 7. Core Web Vitals
# -> https://pagespeed.web.dev/
```

### 20.6 Outils externes

| Outil | Usage |
|-------|-------|
| Google Search Console | Indexation, erreurs, performance, Core Web Vitals |
| Google Rich Results Test | Valider JSON-LD |
| Schema.org Validator | Valider la structure complète |
| opengraph.xyz | Prévisualiser OG / Twitter Card |
| PageSpeed Insights | Core Web Vitals (LCP, CLS, INP) |
| Lighthouse | Audit complet (performance, accessibilité, SEO, PWA) |
| Screaming Frog | Crawl technique, redirections, orphan pages, liens cassés |
| Ahrefs / SEMrush | Backlinks, mots-clés, concurrents, audits techniques |
| web-vitals (npm) | Mesurer les CWV en production |

---

## PARTIE 21 — OFF-PAGE SEO & LINK BUILDING

### 21.1 Techniques d'acquisition de backlinks

| Technique | Effort | Impact |
|-----------|--------|--------|
| **Unlinked brand mentions** | Faible | Moyen — trouver les mentions sans lien, demander l'ajout |
| **Competitor backlink gap** | Moyen | Haut — analyser les profils concurrents, cibler les mêmes sites |
| **Broken link building** | Moyen | Haut — trouver les liens morts sur des sites autoritaires, proposer son contenu |
| **Digital PR** | Haut | Très haut — communiqués de presse, études propriétaires, interviews |
| **Guest posting** | Moyen | Moyen — articles invités sur des sites de niche |
| **Resource page outreach** | Faible | Moyen — pages de ressources curatées |
| **Podcast guesting** | Faible | Moyen — les show notes incluent des liens |
| **Lost link reclamation** | Faible | Moyen — surveiller et restaurer les backlinks perdus |

### 21.2 Brand SERP optimization

S'assurer que les résultats de recherche pour votre nom de marque présentent le narratif souhaité :
- Google Business Profile à jour
- Profils sociaux cohérents (LinkedIn, Twitter, GitHub)
- Schema Organization avec `sameAs` pointant vers tous les profils
- Réponses aux avis (positifs et négatifs)

### 21.3 Attributs de lien

| Attribut | Usage |
|----------|-------|
| (aucun) | Lien éditorial normal — transmet du link equity |
| `rel="nofollow"` | Lien non approuvé — ne transmet pas de link equity |
| `rel="sponsored"` | Lien payant / sponsorisé |
| `rel="ugc"` | Contenu généré par les utilisateurs (commentaires, forums) |

---

## PARTIE 22 — ENTITY SEO & KNOWLEDGE GRAPH

### 22.1 Principes

Chaque page doit mapper vers **une entité canonique**. Google comprend de mieux en mieux les entités (personnes, entreprises, concepts) plutôt que les mots-clés.

### 22.2 Signaux d'entité

- **Schema `sameAs`** : lier vers Wikipedia, Wikidata, Crunchbase, LinkedIn, GitHub
- **`mainEntityOfPage`** dans le JSON-LD pour déclarer l'entité principale de la page
- **Cohérence inter-plateformes** : même nom, même description, mêmes attributs partout
- **Knowledge Panel** : se construit via des mentions autoritaires, des entrées Wikidata, et un schema Organization complet

### 22.3 Topical authority

Construire un réseau de contenu couvrant **toutes les facettes** d'un sujet :
- Map topicale complète avant d'écrire
- Chaque page = une entité ou sous-thème distinct
- Liens internes entre les pages connexes (hub-and-spoke)
- Couverture exhaustive > volume de contenu

---

## PARTIE 23 — ACCESSIBILITY = SEO (2025+)

Depuis la mise à jour Google de **septembre 2025**, l'accessibilité est un **facteur de ranking direct**.

### 23.1 Impact mesuré

- Sites WCAG-compliant : **+23% trafic organique**, +27% positions, +19% autorité
- Seulement 4% des sites sont WCAG-compliant → avantage compétitif massif
- Les agents IA parsent les sites comme des lecteurs d'écran → accessibilité = visibilité IA

### 23.2 Checklist SEO-Accessibility

| Item | Impact SEO |
|------|-----------|
| HTML sémantique (`main`, `nav`, `article`, `section`) | Structure compréhensible par Google et l'IA |
| `alt` descriptif sur toutes les images | Google Image Search + AI extraction |
| Hiérarchie de headings correcte | Featured snippets + compréhension |
| Labels sur tous les champs de formulaire | Accessibilité + UX signals |
| Contraste de couleur suffisant | Page experience signals |
| Navigation au clavier | Engagement signals |
| Skip navigation links | Accessibilité structurelle |
| `aria-label` sur les éléments interactifs | Compréhension assistée |
| Focus visible sur les éléments interactifs | UX engagement |
| Texte de lien descriptif ("guide SEO" pas "cliquez ici") | Anchor text + accessibilité |

---

## PARTIE 24 — LOCAL SEO

### 24.1 Google Business Profile (GBP)

Facteurs de ranking local : **Relevance, Distance, Prominence**.

| Action | Priorité |
|--------|----------|
| Catégories précises (principale + secondaires) | Critique |
| Attributs business (horaires, services, accessibilité) | Haute |
| Posts hebdomadaires (actualités, offres) | Haute |
| Photos mises à jour régulièrement | Moyenne |
| Q&A pré-populées | Moyenne |
| Réponse à CHAQUE avis (positif et négatif) | Critique |

### 24.2 NAP Consistency

**N**om, **A**dresse, **P**hone — doivent être **exactement** identiques partout :
- Footer du site
- Google Business Profile
- Bing Places
- Apple Maps
- Annuaires sectoriels
- Pages Jaunes

Même "Rue" vs "R." peut causer des problèmes.

### 24.3 Schema LocalBusiness

```json
{
  "@type": "LocalBusiness",
  "name": "Mon Entreprise",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "12 Rue Example",
    "addressLocality": "Paris",
    "postalCode": "75001",
    "addressCountry": "FR"
  },
  "telephone": "+33 1 23 45 67 89",
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "09:00",
      "closes": "18:00"
    }
  ],
  "geo": { "@type": "GeoCoordinates", "latitude": 48.8566, "longitude": 2.3522 }
}
```

---

## PARTIE 25 — LOG FILE ANALYSIS & CRAWL BUDGET

### 25.1 Pourquoi analyser les logs

Les logs serveur montrent **exactement** ce que Googlebot fait sur votre site — quelles pages il crawle, à quelle fréquence, et les status codes retournés.

### 25.2 Métriques clés

| Métrique | Ce qu'elle révèle |
|----------|-------------------|
| Fréquence de crawl par URL | Pages priorisées vs ignorées |
| Status codes (200, 301, 404, 500) | Erreurs techniques |
| Crawl budget waste | Pages low-value qui consomment du budget |
| Pages crawled but not indexed | Problèmes de qualité |
| Ratio mobile vs desktop crawl | Problèmes d'indexation mobile |

### 25.3 Optimisation du crawl budget

- **Bloquer** les faceted URLs (filtres produits) avec `noindex` ou `canonical`
- **Réduire** les chaînes de redirections (max 1 hop)
- **Corriger** les 404/500 rapidement
- **Sitemap à jour** avec `lastmod` pour guider le crawl
- **Réponse serveur < 200ms** pour Googlebot

### 25.4 Outils

| Outil | Type |
|-------|------|
| Screaming Frog Log Analyzer | Desktop, gratuit pour petits volumes |
| Botify | SaaS enterprise |
| Logs Nginx/Apache | Auto-hébergé (`/var/log/nginx/access.log`) |
| Cloudflare Logpush | CDN-level |

---

## PARTIE 26 — SEO TESTING & CI/CD

### 26.1 Tests automatisés avec Playwright + Lighthouse

```js
// tests/seo.spec.js
const { test, expect } = require('@playwright/test')

test('Homepage SEO basics', async ({ page }) => {
  await page.goto('/')

  // Title
  const title = await page.title()
  expect(title.length).toBeGreaterThan(10)
  expect(title.length).toBeLessThan(65)

  // Meta description
  const desc = await page.$eval('meta[name="description"]', el => el.content)
  expect(desc.length).toBeGreaterThan(50)
  expect(desc.length).toBeLessThan(165)

  // Canonical
  const canonical = await page.$eval('link[rel="canonical"]', el => el.href)
  expect(canonical).toBeTruthy()

  // H1 unique
  const h1s = await page.$$('h1')
  expect(h1s).toHaveLength(1)

  // OG image
  const ogImage = await page.$eval('meta[property="og:image"]', el => el.content)
  expect(ogImage).toBeTruthy()

  // JSON-LD
  const jsonLd = await page.$eval('script[type="application/ld+json"]', el => el.textContent)
  expect(() => JSON.parse(jsonLd)).not.toThrow()

  // Lang attribute
  const lang = await page.$eval('html', el => el.lang)
  expect(lang).toBeTruthy()
})
```

### 26.2 Lighthouse en CI

```yaml
# .github/workflows/seo-audit.yml
- name: Lighthouse SEO audit
  uses: treosh/lighthouse-ci-action@v12
  with:
    urls: |
      https://example.com/
      https://example.com/pricing
    budgetPath: ./lighthouse-budget.json
```

---

## PARTIE 27 — PAGINATION SEO

### 27.1 Règles actuelles (2025-2026)

- `rel="prev/next"` est **déprécié** — Google l'ignore depuis 2019 (Bing l'utilise encore)
- **Ne JAMAIS** canonicaliser toutes les pages vers page 1 → orphanise le contenu profond
- **Ne JAMAIS** noindex les pages paginées → bloque la découverte de contenu
- Pagination classique (URLs distinctes `?page=2`) = plus crawler-friendly
- Infinite scroll / "Load more" = problématique (les crawlers ne scrollent pas, ne cliquent pas)
- Inclure les URLs paginées dans le sitemap

### 27.2 Pattern recommandé

```
/blog          → page 1 (canonical: /blog)
/blog?page=2   → page 2 (canonical: /blog?page=2)  ← self-canonical !
/blog?page=3   → page 3 (canonical: /blog?page=3)
```

---

## PARTIE 28 — COMMON SCHEMA MISTAKES

| Erreur | Conséquence |
|--------|------------|
| Schema sur du contenu invisible | Violation des guidelines Google → pénalité |
| Prix en texte ("49€") au lieu de nombre (49) | Rich results refusés |
| Schema généré par plugin sans vérification | Bloated, types incorrects, nesting cassé |
| `aggregateRating` avec des avis inventés | Pénalité spam |
| `lastmod` dans le sitemap sans changement réel | Google ignore les futurs lastmod |
| Données périmées (prix, stock) dans le schema | Violation → rich results retirés |
| Canonical et hreflang contradictoires | Google ignore tout le hreflang |
| hreflang sans lien bidirectionnel | Ignoré complètement |

**Validation double obligatoire** :
1. Schema.org Validator → conformité structurelle
2. Google Rich Results Test → éligibilité aux features
