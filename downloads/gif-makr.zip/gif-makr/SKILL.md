---
name: gif-makr
description: Create animated GIFs (PIL) and cinematic product videos (Puppeteer + ffmpeg) for Slack, landing pages, and marketing. Covers both simple emoji GIFs and complex multi-scene HTML-to-MP4 pipelines.
license: Complete terms in LICENSE.txt
---

# GIF & Video Creator

A toolkit for creating animated GIFs (PIL-based) and cinematic product videos (HTML scene capture via Puppeteer + ffmpeg).

---

## PART 1 — Slack GIF (PIL Pipeline)

### Slack Requirements

**Dimensions:**
- Emoji GIFs: 128x128 (recommended)
- Message GIFs: 480x480

**Parameters:**
- FPS: 10-30 (lower is smaller file size)
- Colors: 48-128 (fewer = smaller file size)
- Duration: Keep under 3 seconds for emoji GIFs

### Core Workflow

```python
from core.gif_builder import GIFBuilder
from PIL import Image, ImageDraw

# 1. Create builder
builder = GIFBuilder(width=128, height=128, fps=10)

# 2. Generate frames
for i in range(12):
    frame = Image.new('RGB', (128, 128), (240, 248, 255))
    draw = ImageDraw.Draw(frame)
    # Draw your animation using PIL primitives
    builder.add_frame(frame)

# 3. Save with optimization
builder.save('output.gif', num_colors=48, optimize_for_emoji=True)
```

### Drawing Graphics

#### Working with User-Uploaded Images
If a user uploads an image, consider whether they want to:
- **Use it directly** (e.g., "animate this", "split this into frames")
- **Use it as inspiration** (e.g., "make something like this")

```python
from PIL import Image
uploaded = Image.open('file.png')
```

#### Drawing from Scratch
```python
from PIL import ImageDraw
draw = ImageDraw.Draw(frame)
draw.ellipse([x1, y1, x2, y2], fill=(r, g, b), outline=(r, g, b), width=3)
draw.polygon(points, fill=(r, g, b), outline=(r, g, b), width=3)
draw.line([(x1, y1), (x2, y2)], fill=(r, g, b), width=5)
draw.rectangle([x1, y1, x2, y2], fill=(r, g, b), outline=(r, g, b), width=3)
```

**Don't use:** Emoji fonts (unreliable across platforms) or assume pre-packaged graphics exist.

#### Making Graphics Look Good

- **Use thicker lines** - Always set `width=2` or higher. Thin lines (width=1) look choppy.
- **Add visual depth**: gradients for backgrounds (`create_gradient_background`), layered shapes
- **Make shapes interesting**: highlights, rings, patterns, glows
- **Vibrant colors**: complementary, contrasted, well-composed
- **Complex shapes** (hearts, snowflakes): combinations of polygons + ellipses, calculated symmetry

### Available Utilities

#### GIFBuilder (`core.gif_builder`)
```python
builder = GIFBuilder(width=128, height=128, fps=10)
builder.add_frame(frame)     # Add PIL Image
builder.add_frames(frames)   # Add list of frames
builder.save('out.gif', num_colors=48, optimize_for_emoji=True, remove_duplicates=True)
```

#### Validators (`core.validators`)
```python
from core.validators import validate_gif, is_slack_ready
passes, info = validate_gif('my.gif', is_emoji=True, verbose=True)
if is_slack_ready('my.gif'): print("Ready!")
```

#### Easing Functions (`core.easing`)
```python
from core.easing import interpolate
t = i / (num_frames - 1)
y = interpolate(start=0, end=400, t=t, easing='ease_out')
# Available: linear, ease_in, ease_out, ease_in_out, bounce_out, elastic_out, back_out
```

#### Frame Helpers (`core.frame_composer`)
```python
from core.frame_composer import (
    create_blank_frame, create_gradient_background,
    draw_circle, draw_text, draw_star
)
```

### Animation Concepts (PIL)

| Concept | Technique |
|---------|-----------|
| Shake/Vibrate | `math.sin()` offset on position + small random variations |
| Pulse/Heartbeat | `math.sin(t * freq * 2 * pi)` on scale, between 0.8-1.2 |
| Bounce | `interpolate()` with `easing='bounce_out'` for landing |
| Spin/Rotate | `image.rotate(angle, resample=Image.BICUBIC)` |
| Fade In/Out | RGBA alpha channel or `Image.blend(img1, img2, alpha)` |
| Slide | Off-screen start → target with `easing='ease_out'` |
| Zoom | Scale from 0.1→2.0, crop center |
| Explode/Particles | Random angles + velocities, gravity on vy, fade alpha |

### Optimization (GIF)

1. **Fewer frames** - Lower FPS (10 instead of 20) or shorter duration
2. **Fewer colors** - `num_colors=48` instead of 128
3. **Smaller dimensions** - 128x128 instead of 480x480
4. **Remove duplicates** - `remove_duplicates=True` in save()
5. **Emoji mode** - `optimize_for_emoji=True` auto-optimizes

### Dependencies (PIL pipeline)
```bash
pip install pillow imageio numpy
```

---

## PART 2 — Cinematic Product Video (HTML + Puppeteer + ffmpeg)

For complex, multi-scene videos with realistic UI mockups (dashboards, Gmail, CRM, notifications, etc.), the PIL pipeline is insufficient. Use the **HTML scene capture** pipeline instead.

### When to Use This Pipeline

- Product demo videos for landing pages
- War room / agent coordination scenarios
- App UI walkthrough animations
- Any video requiring realistic text, layouts, icons, and UI chrome
- Videos longer than 5 seconds with multiple scenes
- Content that needs to match a specific design system (colors, fonts, gradients)

### Architecture Overview

```
scenes.html (all scenes + CSS + frame logic)
    ↓  Puppeteer captures each frame as PNG (800x500 @2x)
frames/frame_0000.png ... frame_NNNN.png
    ↓  ffmpeg assembles into H.264 MP4
output.mp4
```

### File Structure

```
scripts/hero-video/
  scenes.html       # All scenes, styles, frame-based animation logic
  generate.mjs      # Puppeteer + ffmpeg orchestrator
  logo.png          # Any assets referenced by scenes.html (file:// protocol)
public/
  hero.mp4          # Output video
```

### Step 1 — Design the Scenario

Before writing any code, plan the storyboard:

1. **Define scenes** (3-5 is ideal for a 30s video)
2. **Define what each scene shows** — realistic app UI, not abstract illustrations
3. **Define transitions** — fade between scenes (7-frame crossfade works well)
4. **Define the timeline** — frame ranges for each scene

Example timeline for 180 frames at 6fps (30 seconds):

| Frames | Duration | Scene |
|--------|----------|-------|
| 0-55 | ~9s | Chat interface — user sends request, agents respond |
| 56-62 | ~1s | Crossfade transition |
| 63-125 | ~10s | Agent coordination — inter-agent communication feed |
| 126-132 | ~1s | Crossfade transition |
| 133-172 | ~7s | Desktop — real app windows (Gmail, CRM) + notifications |
| 173-180 | ~1s | Fade out |

**Key principle:** Slower is better. 6fps with 180 frames = 30s. Users need time to READ the text on screen.

### Step 2 — Create scenes.html

The HTML file is a self-contained document with ALL scenes, CSS, and frame-based animation logic. It reads the current frame from the URL query parameter `?frame=N`.

#### HTML Structure

```html
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&family=Fira+Code:wght@400;500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    /* Define your color palette as CSS variables */
    --gold: #D4A44C;
    --cream: #EDE8DF;
    --c60: rgba(237,232,223,0.6);
    --c35: rgba(237,232,223,0.35);
    --c08: rgba(237,232,223,0.08);
    --c05: rgba(237,232,223,0.05);
  }

  body {
    width: 800px; height: 500px; overflow: hidden;
    font-family: 'Inter', sans-serif;
    color: var(--cream);
    background: /* your gradient */;
  }

  /* Scene visibility */
  .scene { position: absolute; inset: 0; opacity: 0; }
  .scene.active { opacity: 1; }

  /* Font shortcuts */
  .fd { font-family: 'Space Grotesk', sans-serif; }
  .fm { font-family: 'Fira Code', monospace; }

  /* Animation classes — applied by JS based on frame number */
  .vis  { opacity: 0; transform: translateY(8px); }
  .vis.v  { opacity: 1; transform: translateY(0); transition: opacity 0.45s ease-out, transform 0.45s ease-out; }
  .visx { opacity: 0; transform: translateX(-6px); }
  .visx.v { opacity: 1; transform: translateX(0); transition: opacity 0.35s ease-out, transform 0.35s ease-out; }
  .visxr { opacity: 0; transform: translateX(20px); }
  .visxr.v { opacity: 1; transform: translateX(0); transition: opacity 0.4s ease-out, transform 0.4s ease-out; }

  /* ... scene-specific CSS ... */
</style>
</head>
<body>

<!-- SCENE 1 -->
<div class="scene" id="s1">
  <!-- Full app-like layout with sidebar, topbar, content -->
</div>

<!-- SCENE 2 -->
<div class="scene" id="s2">
  <!-- Different layout — coordination feed, dashboard, etc. -->
</div>

<!-- SCENE 3 -->
<div class="scene" id="s3">
  <!-- Desktop mockups — real app windows, notifications -->
</div>

<script>
const frame = parseInt(new URLSearchParams(location.search).get('frame') || '0');

// Timeline — which scene is active and what crossfade opacity
const scenes = [
  { id: 's1', start: 0,   end: 55,  fadeOut: [50, 55] },
  { id: 's2', start: 56,  end: 125, fadeIn: [56, 62], fadeOut: [120, 125] },
  { id: 's3', start: 126, end: 180, fadeIn: [126, 132], fadeOut: [173, 180] },
];

// Activate scenes + crossfade
scenes.forEach(s => {
  const el = document.getElementById(s.id);
  if (frame >= s.start && frame <= s.end) {
    el.classList.add('active');
    // Crossfade in
    if (s.fadeIn && frame <= s.fadeIn[1]) {
      el.style.opacity = (frame - s.fadeIn[0]) / (s.fadeIn[1] - s.fadeIn[0]);
    }
    // Crossfade out
    if (s.fadeOut && frame >= s.fadeOut[0]) {
      el.style.opacity = 1 - (frame - s.fadeOut[0]) / (s.fadeOut[1] - s.fadeOut[0]);
    }
  }
});

// Progressive element reveals — show elements one by one over time
function showAt(id, triggerFrame) {
  if (frame >= triggerFrame) document.getElementById(id)?.classList.add('v');
}

// Scene 1 reveals
showAt('msg1', 3);
showAt('msg2', 10);
showAt('msg3', 18);
// ... etc
</script>
</body>
</html>
```

#### Animation System — The `vis` / `visx` / `visxr` Classes

Elements start hidden and are revealed by adding class `v` at specific frames:

| Class | Hidden state | Revealed state | Use for |
|-------|-------------|----------------|---------|
| `vis` | `opacity:0; translateY(8px)` | `opacity:1; translateY(0)` | Chat messages, list items (fade up) |
| `visx` | `opacity:0; translateX(-6px)` | `opacity:1; translateX(0)` | Sidebar items, left-side elements (slide right) |
| `visxr` | `opacity:0; translateX(20px)` | `opacity:1; translateX(0)` | Notifications, right-side panels (slide left) |

The `showAt(id, frame)` function triggers reveals at specific frames. Space them 3-8 frames apart for readable pacing.

#### Realistic UI Mockup Patterns

**macOS Window Chrome:**
```html
<div class="window">
  <div class="window-titlebar">
    <div class="dots">
      <span style="background:#FF5F57"></span>
      <span style="background:#FEBC2E"></span>
      <span style="background:#28C840"></span>
    </div>
    <div class="url-bar">mail.google.com/mail/u/0/#sent</div>
  </div>
  <div class="window-body">
    <!-- Realistic app content -->
  </div>
</div>
```

**Gmail mockup:** Sidebar with icons (Inbox, Starred, Sent, Drafts), email list with sender/subject/preview, compose button.

**CRM mockup (HubSpot-style):** Nav tabs (Contacts, Deals, Tasks), pipeline columns (Nouveau, Contacte, Qualifie, Gagne), deal cards with name + amount.

**Notifications (Telegram-style):** Real SVG logo (not Unicode airplane), app name, sender, message preview, timestamp. Use `position: absolute` + `visxr` class for slide-in from right.

**Chat interface:** Sidebar with real nav items matching the actual app. Chat area with topbar (agent name + status), messages with agent avatars (colored circles with initials), typing indicator, input field.

#### Including Assets (Logos, Images)

Since Puppeteer opens the HTML via `file://` protocol, all assets must be **relative to scenes.html** or use absolute `file://` paths:

```html
<!-- Logo next to app name in sidebar -->
<img src="logo.png" alt="Logo" />
```

Copy any needed assets to the same directory as scenes.html before generating.

### Step 3 — Create generate.mjs

The Node.js script that drives Puppeteer and ffmpeg:

```javascript
import puppeteer from 'puppeteer';
import { execSync } from 'child_process';
import { mkdirSync, existsSync, rmSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FRAMES_DIR = resolve(__dirname, 'frames');
const HTML_FILE = resolve(__dirname, 'scenes.html');
const OUTPUT = resolve(__dirname, '..', '..', 'public', 'hero.mp4');

const TOTAL_FRAMES = 180;
const FPS = 6; // 6fps, 180 frames = 30s

async function main() {
  if (existsSync(FRAMES_DIR)) rmSync(FRAMES_DIR, { recursive: true });
  mkdirSync(FRAMES_DIR, { recursive: true });

  console.log('Launching browser...');
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 800, height: 500, deviceScaleFactor: 2 });

  console.log(`Capturing ${TOTAL_FRAMES} frames...`);
  for (let i = 0; i < TOTAL_FRAMES; i++) {
    const url = `file://${HTML_FILE}?frame=${i}`;
    await page.goto(url, { waitUntil: 'networkidle0' });
    await page.evaluate(() => document.fonts.ready);
    await new Promise(r => setTimeout(r, 80)); // CSS transitions settle

    const padded = String(i).padStart(4, '0');
    await page.screenshot({
      path: resolve(FRAMES_DIR, `frame_${padded}.png`),
      type: 'png',
    });
    if (i % 10 === 0) console.log(`  frame ${i}/${TOTAL_FRAMES}`);
  }

  await browser.close();
  console.log('All frames captured.');

  // Assemble with ffmpeg
  console.log('Assembling MP4...');
  const cmd = [
    'ffmpeg -y',
    `-framerate ${FPS}`,
    `-i "${FRAMES_DIR}/frame_%04d.png"`,
    '-c:v libx264',
    '-preset slow',
    '-crf 22',
    '-pix_fmt yuv420p',
    '-vf "tpad=stop_mode=clone:stop_duration=2"',
    `"${OUTPUT}"`,
  ].join(' ');

  console.log(`> ${cmd}`);
  execSync(cmd, { stdio: 'inherit' });

  console.log(`\n Done: ${OUTPUT}`);
  const { statSync } = await import('fs');
  console.log(`  Size: ${(statSync(OUTPUT).size / 1024).toFixed(0)} KB`);

  rmSync(FRAMES_DIR, { recursive: true });
  console.log('  Frames cleaned up.');
}

main().catch(e => { console.error(e); process.exit(1); });
```

### Step 4 — Run and Iterate

```bash
# Install dependencies (one-time)
npm install --save-dev puppeteer
# System: ffmpeg must be installed (apt install ffmpeg / brew install ffmpeg)

# Generate
node scripts/hero-video/generate.mjs
```

**Typical output:** ~180 frames, 30s video, 800-1200 KB MP4.

### Key Parameters

| Parameter | Recommended | Effect |
|-----------|-------------|--------|
| `TOTAL_FRAMES` | 150-240 | More = longer video |
| `FPS` | 4-8 | Lower = more time to read text. 6 is sweet spot. |
| `deviceScaleFactor` | 2 | Retina-quality captures (1600x1000 actual pixels) |
| `width x height` | 800x500 | 16:10 aspect ratio, good for landing page heroes |
| `-crf` | 18-26 | Lower = better quality, larger file. 22 is balanced. |
| `-preset` | slow | Better compression. Use `ultrafast` for quick previews. |
| `tpad stop_duration` | 2 | Seconds to hold last frame before loop |

### Design Rules for Video Scenes

1. **Match the real app's design system** — use the same gradient, colors, fonts, sidebar items
2. **Use the app's actual logo** — copy to the script directory for `file://` access
3. **Realistic UI chrome** — macOS window dots, URL bars, proper nav tabs
4. **Readable pacing** — 6fps, elements appearing every 3-8 frames apart
5. **Smooth transitions** — 7-frame crossfade between scenes (opacity interpolation)
6. **Progressive reveals** — don't show everything at once, build up element by element
7. **Agent-specific colors** — each agent/role gets a unique color from the palette
8. **Real content** — actual feature names, realistic data, plausible metrics
9. **No Unicode hacks** — use real SVG logos (Telegram, Gmail, etc.), not emoji substitutes
10. **Inter-agent coordination** — if showing multi-agent systems, show them explicitly communicating with each other (arrows, data flow tags), not working in silos

### Output Format Options

**MP4 (recommended for web):**
```bash
ffmpeg -y -framerate 6 -i "frames/frame_%04d.png" \
  -c:v libx264 -preset slow -crf 22 -pix_fmt yuv420p \
  -vf "tpad=stop_mode=clone:stop_duration=2" output.mp4
```

**WebM (smaller, good browser support):**
```bash
ffmpeg -y -framerate 6 -i "frames/frame_%04d.png" \
  -c:v libvpx-vp9 -crf 30 -b:v 0 -pix_fmt yuv420p output.webm
```

**GIF (large file, use only if MP4 not supported):**
```bash
ffmpeg -y -framerate 6 -i "frames/frame_%04d.png" \
  -vf "fps=6,scale=800:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse" \
  output.gif
```

### Embedding in Next.js / React

```jsx
<video
  autoPlay muted loop playsInline
  className="w-full rounded-xl border border-white/5"
  poster="/hero-poster.jpg"  // Optional: first frame as JPEG
>
  <source src="/hero.mp4" type="video/mp4" />
</video>
```

Key attributes: `autoPlay muted loop playsInline` — all four are required for auto-playing video on mobile.

### Troubleshooting

| Problem | Solution |
|---------|----------|
| Video too fast, can't read text | Lower FPS (6 or 4), increase TOTAL_FRAMES |
| Fonts not rendering | Add `await page.evaluate(() => document.fonts.ready)` + 80ms delay |
| Assets not loading (broken images) | Copy assets next to scenes.html, use relative paths |
| Unicode characters mangled | Use real UTF-8 in the HTML, NOT `\uXXXX` escapes |
| Puppeteer crashes on Linux | Add `--no-sandbox --disable-setuid-sandbox` args |
| File too large (>2MB) | Increase `-crf` (24-28), reduce `deviceScaleFactor` to 1, use WebM |
| Choppy transitions | Increase crossfade frames (7-10), use CSS transition on opacity |
| Elements appear too fast | Space `showAt()` calls further apart (5-8 frames between reveals) |

### Dependencies (Video pipeline)

```bash
# Node.js
npm install --save-dev puppeteer

# System
# Ubuntu/Debian: sudo apt install ffmpeg
# macOS: brew install ffmpeg
```

---

## Philosophy

This skill provides two complementary pipelines:

| | PIL GIF Pipeline | HTML Video Pipeline |
|---|---|---|
| **Best for** | Emoji, simple animations, Slack | Product demos, landing heroes, complex UI |
| **Complexity** | Low — Python script | Medium — HTML + CSS + JS + Node + ffmpeg |
| **Visual fidelity** | Geometric shapes, basic graphics | Pixel-perfect UI mockups, real fonts |
| **Output** | .gif (animated) | .mp4 / .webm / .gif |
| **File size** | 50-500 KB | 500 KB - 2 MB |
| **Duration** | 1-5 seconds | 10-60 seconds |

Choose the right pipeline for the job. For anything involving realistic app interfaces, text-heavy content, or multi-scene narratives, always use the HTML Video Pipeline.
