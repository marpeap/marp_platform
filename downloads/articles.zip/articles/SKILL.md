---
name: articles
description: Machine de guerre pour ecrire des articles qui captent, retiennent et convertissent. Base sur NNGroup (eye-tracking), BuzzSumo (912M articles), Cialdini, Kahneman, Copyblogger, Buffer, Backlinko + psychologie cognitive. Couvre headlines, structure, hooks, biais cognitifs, engagement, conversion.
user_invocable: true
---

# /articles — Redaction d'articles : captation, retention, conversion

Ce skill est construit sur des **donnees reelles**, pas sur des opinions :
- NNGroup : 1.5M fixations oculaires, 120+ participants eye-tracking
- BuzzSumo : etude de 912 millions d'articles de blog
- Kahneman & Tversky : Prospect Theory, anchoring, framing
- Cialdini : 7 principes d'influence (edition 2016 avec Unity)
- Copyblogger, Buffer, Backlinko, CoSchedule : donnees A/B et formules testees
- Loewenstein (Carnegie Mellon) : theorie du curiosity gap
- Zeigarnik : effet des boucles ouvertes sur la memoire

**18 parties** — couvre tout de la psychologie du lecteur a la structure finale de l'article.

---

## PARTIE 1 — LA REALITE DU LECTEUR (donnees eye-tracking)

Avant d'ecrire un seul mot, comprendre comment les gens lisent reellement.

### 1.1 Les chiffres brutaux

| Metrique | Valeur | Source |
|----------|--------|--------|
| Lecteurs qui s'arretent au titre | 80% | Ogilvy / Copyblogger |
| Mots reellement lus sur une page | 28% max | NNGroup (1.5M fixations) |
| Lecteurs qui voient le 1er paragraphe | 81% | NNGroup |
| Lecteurs qui voient le 4eme paragraphe | 32% | NNGroup |
| Temps pour decider de rester ou partir | 10-20 secondes | NNGroup |
| Temps moyen sur une page | 52-54 secondes | Benchmarks 2025 |

### 1.2 Distribution de l'attention

| Zone de la page | % du temps de visionnage |
|-----------------|--------------------------|
| Au-dessus du fold (1er ecran) | 57% |
| 2 premiers ecrans | 74% |
| 3 premiers ecrans | 81% |
| Au-dela | 19% (long-tail) |

**Consequence** : 74% de l'attention se concentre dans les 2 premiers ecrans (~2160px). Chaque section en dessous doit MERITER sa place.

### 1.3 Le pattern F

NNGroup (47+ participants) confirme : les utilisateurs lisent en F.
- Les premieres lignes recoivent plus de regards
- Les premiers mots de chaque ligne recoivent plus de fixations
- Le reste est scanne verticalement sur la gauche

**Comment casser le F** : sous-titres, texte en gras, listes a puces, ancres visuelles. Sans ca, le lecteur scanne et part.

### 1.4 La formule NNGroup (+124% d'usabilite)

Etude a 5 versions du meme contenu :

| Version | Amelioration |
|---------|-------------|
| Texte promotionnel (controle) | 0% |
| Texte concis (moitie des mots) | +58% |
| Structure scannable (puces, sous-titres) | +47% |
| Langage objectif (pas de marketese) | +27% |
| **Les trois combines** | **+124%** |

Mesure sur 4 axes : temps sur tache, erreurs, rappel memoire, comprehension.

**Regle d'or : Concis + Scannable + Objectif = base de tout article.**

---

## PARTIE 2 — PSYCHOLOGIE DU LECTEUR : LES 10 BIAIS QUI COMPTENT

### Tier 1 : Essentiels (utiliser dans CHAQUE article)

#### 2.1 Curiosity Gap (Loewenstein, 1994)

**Mecanisme** : le cerveau detecte un ecart entre ce qu'il sait et ce qu'il veut savoir. Le cortex cingulaire anterieur detecte le gap, le noyau caude (circuit de recompense) s'active en anticipation. Le lecteur DOIT combler le gap — c'est une pulsion, pas un choix.

**Conditions** : le lecteur doit savoir ASSEZ pour realiser qu'il manque quelque chose, mais pas ASSEZ pour combler seul.

**Application** :
- Titre : poser une question ou impliquer une information cachee
- Introduction : presenter un resultat surprenant, puis dire "Mais pour comprendre pourquoi, il faut remonter a..."
- Sous-titres : teaser la section suivante sans tout reveler
- Structure gap-pont-resolution : etablir ce que le lecteur croit savoir → reveler un trou → combler

**Exemples** :
- "La strategie qui a transforme la croissance d'Airbnb (et pourquoi la plupart des entreprises l'ignorent)"
- The New Yorker : ouvre avec une scene vivante qui pose des questions, puis prend 2000 mots avant de repondre
- The Hustle : subject lines qui ouvrent des gaps → 40%+ taux d'ouverture

**Limite ethique** : le gap est du clickbait si (a) l'article ne le comble jamais, (b) le gap deforme le contenu, (c) il cree une urgence artificielle sur du trivial.

#### 2.2 Loss Aversion (Kahneman & Tversky, 1979)

**Mecanisme** : les pertes sont ressenties 1.5x a 2.5x plus intensement que les gains equivalents. L'amygdale reagit plus fortement aux pertes potentielles. C'est evolutionnaire : eviter les menaces = survie.

**Application** :
- Cadrer les problemes AVANT les solutions : "Vous perdez 3h par jour a cause de ces 5 habitudes" > "Gagnez 3h avec ces 5 habitudes"
- Quantifier le cout de l'ignorance : "Ne pas comprendre ce principe coute X€/an en moyenne"
- Le cadrage "ce que vous faites mal" surpasse "ce que vous pourriez faire mieux" de 2-3x en engagement (CXL Institute)

**Exemples** :
- HBR : "The Hidden Costs of..." / "What Leaders Get Wrong About..."
- NYT sante : cadre en risques de NE PAS agir

**Limite ethique** : manipulation si la menace est inventee ou exageree. Legitime si la perte est reelle et l'article apporte des solutions.

#### 2.3 Zeigarnik Effect (1927)

**Mecanisme** : les taches incompletes occupent la memoire de travail plus que les taches terminees. Le cerveau maintient un "systeme de tension" pour les boucles ouvertes. C'est pourquoi les cliffhangers fonctionnent.

**Application** :
- Commencer une histoire, l'interrompre, y revenir plus tard. Le cerveau garde l'histoire en memoire active.
- Finir les sections avec des questions prospectives, pas des conclusions
- Open loops en introduction : "Il y a une raison pour laquelle les meilleurs negociateurs ne font jamais la premiere offre. On y reviendra. Mais d'abord..."
- NE PAS tout resoudre dans l'introduction. Donner assez pour accrocher, puis creer de l'incompletude deliberee.

**Exemples** :
- Serial (podcast) : entierement construit sur Zeigarnik
- NYT long-form : structure "recit interrompu par l'explication"
- Substack : "Dans le prochain numero, je revelerai..."

### Tier 2 : Haut impact (utiliser dans la plupart des articles)

#### 2.4 Social Proof (Cialdini, 1984)

5 types : expert, celebrite, utilisateur, foule, pairs.

**Application** :
- Chiffres specifiques : "Plus de 2 millions de developpeurs ont adopte..." > "Beaucoup de developpeurs preferent..."
- Experts nommes avec credentials : "Dr. Sarah Chen, neuroscientifique a Stanford" > "des chercheurs"
- Entreprises reconnaissables comme exemples
- "La plupart des gens ignorent ca, mais les top performers font X" (social proof aspirationnelle)

#### 2.5 Authority Bias (Milgram, 1963)

**Mecanisme** : quand un expert presente une information, le cerveau REDUIT le traitement critique et AUGMENTE l'acceptation. L'IRMf montre que l'opinion experte reduit l'activite dans les circuits d'evaluation independante.

**Application** :
- Citer par nom + institution : "Recherche du MIT" > "la recherche montre"
- Etablir l'autorite de l'auteur tot dans l'article
- Autorite empruntee : citer des experts reconnus qui soutiennent votre point
- Les donnees d'institutions reconnues (Harvard, McKinsey, WHO) ont plus de poids persuasif que des donnees equivalentes de sources inconnues

#### 2.6 Anchoring (Tversky & Kahneman, 1974)

**Mecanisme** : le cerveau s'accroche a la premiere information rencontree et ajuste insuffisamment. Persiste meme quand on previent les gens (Wilson et al., 1996).

**Application** :
- Ouvrir avec une statistique frappante qui pose le cadre. "Les entreprises perdent 75 milliards par an..." — tout ce qui suit est evalue relativement
- Le premier chiffre de l'article est l'ancre. Choisir deliberement
- The Economist ouvre systematiquement ses features avec un seul chiffre dramatique en premiere phrase
- Bloomberg cite toujours le prix au plus haut avant de discuter les niveaux actuels

### Tier 3 : Strategiques (utiliser quand pertinent)

#### 2.7 Framing Effect (Tversky & Kahneman, 1981)

"Taux de survie de 95%" et "taux de mortalite de 5%" = meme information, reactions completement differentes. Choisir son cadrage deliberement des le premier paragraphe.

#### 2.8 FOMO (McGinnis, 2004 / Przybylski, 2013)

Hybride de loss aversion + comparaison sociale + besoin d'appartenance. "Ce que les top entreprises savent deja (et pas vous)" implique un desavantage competitif.

#### 2.9 Mere Exposure Effect (Zajonc, 1968)

La repetition augmente l'adhesion. Repeter la these centrale sous des formes variees dans l'article. Le lecteur est de plus en plus d'accord sans realiser le mecanisme.

#### 2.10 Illusory Truth Effect (Hasher et al., 1977)

Les enonces repetes sont percus comme plus vrais. Enoncer l'argument central clairement et tot, puis le reformuler dans differents contextes. A la conclusion, il SEMBLERA plus vrai. Attention : c'est le biais le plus dangereux ethiquement — ne l'utiliser que sur des faits verifies.

---

## PARTIE 3 — LES 7 PRINCIPES DE CIALDINI (appliques aux articles)

| Principe | Application article |
|----------|-------------------|
| **Reciprocite** | Donner de la valeur en premier. Un article utile cree un sentiment d'obligation. "On vient de vous donner un guide complet gratuitement. Si vous voulez plus..." |
| **Engagement & Coherence** | Si le lecteur accepte un petit point, il acceptera les suivants. Commencer par des premisses que le lecteur approuve deja, puis construire |
| **Social Proof** | Citations, compteurs de partages, quotes d'experts, "des milliers de lecteurs" |
| **Autorite** | Credentials, citations institutionnelles, donnees de sources reconnues |
| **Sympathie** | Ton conversationnel, identite partagee ("entre entrepreneurs, on sait que..."), humour, vulnerabilite, storytelling revelant l'auteur comme humain |
| **Rarete** | Information limitee ou exclusive : "Cette approche ne fonctionne que dans [condition specifique]" ou "Ces donnees n'ont pas ete publiees ailleurs" |
| **Unite** (2016) | Identite partagee. Langage "nous". Ecrire pour une communaute specifique avec le vocabulaire du groupe |

---

## PARTIE 4 — HEADLINES : FORMULES ET DONNEES

### 4.1 Les chiffres

- 80% lisent le titre, 20% le reste (Ogilvy / Copyblogger)
- Les lecteurs absorbent les **3 premiers** et les **3 derniers** mots d'un titre (KISSmetrics) → 6 mots = ideal
- Titres question : +23.3% de partages sociaux (BuzzSumo)
- Titres longs (14-17 mots) : +76.7% de partages (BuzzSumo)
- Titres SEO : 50-60 caracteres visibles dans les SERP

### 4.2 Hierarchie d'efficacite d'un titre

1. **Verite** : le titre represente-t-il fidelement le contenu ?
2. **Alignement objectif** : parle-t-il de ce que le lecteur veut accomplir ?
3. **Specificite** : chiffres concrets, resultats nommes, details exacts ?
4. **Clarte** : compris en moins de 2 secondes ?
5. **Intrigue** : un hook (benefice, douleur, preuve, objection) ?
6. **Craft** : adjectifs interessants, power words, longueur optimisee ?

**La plupart des gens commencent par 5-6 et sautent 1-4. Les niveaux 1-4 font le gros du travail.**

### 4.3 La methode Copyblogger en 3 etapes

1. Qu'est-ce que le contenu delivre REELLEMENT ?
2. Quel est l'OBJECTIF du lecteur ?
3. Quel est l'element d'INTRIGUE ? (ajouter apres 1+2 seulement)

Les etapes 1+2 font 85% du travail. L'intrigue est de la finition.

### 4.4 Formules de titres testees

**Formule universelle** :
```
Nombre + Adjectif interessant + Mot-cle cible + Justification + Promesse
```
Ex : "10 erreurs meconnues qui plombent vos Google Ads (et comment les corriger aujourd'hui)"

**Formules fill-in-the-blank** :

| Formule | Exemple |
|---------|---------|
| Qui d'autre veut ____ ? | Qui d'autre veut des appels a 5€ sur Google Ads ? |
| Le secret de ____ | Le secret des serruriers qui payent 3x moins par clic |
| Methodes peu connues pour ____ | Methodes peu connues pour reduire son CPC de 40% |
| Voici un moyen rapide de ____ | Voici un moyen rapide de detecter les clics inutiles |
| Ce que tout le monde devrait savoir sur ____ | Ce que tout le monde devrait savoir sur les encheres automatiques |
| [Nombre] lecons que j'ai apprises de ____ | 7 lecons apprises en gerant 1400€ de Google Ads pour un serrurier |
| Comment ____ comme ____ sans ____ | Comment optimiser vos campagnes comme une agence sans payer une agence |

**Variantes How-To** :
- Comment ____
- Comment ____ — le guide essentiel
- Comment ____ meme si / sans ____
- Comment utiliser ____ pour ____
- Comment ____ en [X] etapes

**Formules avancees (Buffer)** :
- **Le Double Whammy** : Titre + Titre ("7 erreurs Google Ads : 7 solutions testees sur un vrai compte")
- **L'Amuse-Bouche** : sortir 1-2 items d'une liste et les mettre en avant ("Le piege du ciblage geo et 6 autres erreurs qui vident votre budget")
- **____, donnees a l'appui** : signal de recherche ("Pourquoi votre CPC explose, donnees reelles a l'appui")

### 4.5 Les 8 leviers psychologiques d'un titre (Buffer)

1. **Surprise** : subvertir les attentes
2. **Question** : activer le drive de completion du cerveau
3. **Curiosity gap** : ouvrir une boucle
4. **Negatifs** : "Ne faites jamais" surpasse les equivalents positifs
5. **How-to** : promesse claire et actionnable
6. **Chiffres** : specificite = scannabilite + credibilite
7. **Reference au lecteur** : il se voit dans le titre
8. **Specificite** : chiffres exacts = authenticite

### 4.6 Titres journalisme prestige vs clickbait

| Prestige (NYT, Economist, Bloomberg) | Clickbait |
|---------------------------------------|-----------|
| Ouvre un gap que l'article COMBLE | Ouvre un gap jamais comble |
| Specificite = credibilite ("22 ans", "2.3%") | Vagueness = faux mystere ("Cette chose...") |
| L'info la plus importante EST dans le titre | L'info est retenue du titre |
| Mots emotionnels proportionnes au contenu | Mots emotionnels gonfles |
| Lecteur se sent INFORME apres lecture | Lecteur se sent PIEGE |
| Le titre fonctionne seul comme resume | Le titre est vide sans clic |
| La confiance se cumule | La confiance s'erode |

**Patterns par publication** :
- **The Economist** : jeu de mots + sous-titre explicatif. Le titre divertit, le sous-titre informe
- **NYT** : precision + gravite. Le fait le plus consequent en premier. Voix active. Pas d'adjectif — la specificite suffit
- **Bloomberg** : donnees d'abord. Le chiffre EST le hook
- **The Guardian** : cadrage moral + specificite humaine. Nommer un individu ou un lieu pour ancrer l'abstrait

### 4.7 Anti-patterns titres (causes de bounce immediat)

1. **Decalage titre-contenu** : anti-pattern #1. Un titre accrocheur sur un contenu desaligne est PIRE qu'un titre ennuyeux sur du contenu aligne
2. **Clickbait qui ne tient pas sa promesse** : "Vous n'allez pas croire..." suivi de quelque chose de totalement croyable
3. **Titre qui exige des prerequis** : jargon ou noms de produits inconnus du non-expert
4. **Ouvertures vagues** : "Dans le monde d'aujourd'hui..." / "Le marketing de contenu est important..."
5. **Valeur enterree** : si le lecteur ne peut pas identifier ce qu'il va gagner en 3 phrases, il part
6. **Loi de Betteridge** : tout titre terminant par un point d'interrogation peut etre repondu "non" par le lecteur, qui n'a alors aucune raison de cliquer
7. **"11 choses..."** generique : "11 choses" vs "11 erreurs couteuses" — le generique signale du contenu low-effort

### 4.8 Processus de creation

- **Processus Upworthy** : 25 titres par article, puis A/B test des meilleurs. Buffer confirme : "La moitie seront ridicules, certains n'auront aucun sens, mais quand vous trouvez le bon, c'est de la musique"
- **Minimum pratique** : 10-15 variations (Copyblogger). Chaque variation doit communiquer un SENS different, pas juste des synonymes
- **Ecrire le titre AVANT le contenu** : empeche le decalage titre-contenu
- **Swipe file** : collecter les titres performants de votre niche specifique, reverse-engineer les formules

---

## PARTIE 5 — STRUCTURE D'ARTICLE : LA PYRAMIDE INVERSEE

### 5.1 Le principe (NNGroup)

1. Commencer par la conclusion / le resultat le plus important
2. Suivre avec les informations de soutien les plus importantes
3. Finir avec le contexte / l'arriere-plan

C'est l'inverse de l'ecriture academique (qui construit vers une conclusion).

**Pourquoi ca marche en ligne** :
- Les gens ne scrollent pas — ils lisent souvent seulement le haut
- Seuls les lecteurs tres interesses scrollent plus bas
- Le web est un medium de liens : on peut linker vers le contexte au lieu de le repeter

### 5.2 Structure optimale d'un article (synthese de toutes les sources)

```
1. TITRE         → Curiosity gap + loss aversion + anchoring
2. INTRO          → Open loop (Zeigarnik) + exemple vivant specifique + autorite
   (3 phrases max avant le hook)
3. PROBLEME       → Loss framing + social proof ("73% des entreprises subissent ca")
4. AGITATION      → FOMO + defi du statu quo ("Pendant que vous faites X, les concurrents font Y")
5. CONTENU COEUR  → Autorite + specificite + these repetee (illusory truth)
   Chaque section :
   - Commence par un mini curiosity gap
   - Delivre de la valeur (reciprocite)
   - Finit avec un hook prospectif (Zeigarnik)
6. CONCLUSION     → Resolution du loop d'ouverture + restatement these + social proof
7. CTA            → Un seul next step clair (engagement/coherence)
```

### 5.3 Sous-titres tous les 200-400 mots

Les sous-titres cassent le pattern F, creent des points d'entree pour les scanners, et transforment paradoxalement les scanners en lecteurs profonds.

### 5.4 Le premier paragraphe (techniques d'ouverture)

**Les 3 premieres phrases doivent** :

1. **Valider le probleme du lecteur immediatement** — nommer sa douleur exacte, pas votre sujet

Mauvais : "Les titres sont un element important du marketing de contenu."
Bon : "Vous avez depense 500€ en Google Ads le mois dernier. Combien de ces clics ont genere un appel ?"

2. **Creer une tension qui exige resolution** — contradiction, gap, "et pourtant"

3. **Promettre un cadre, pas juste des astuces** — "Au lieu de conseils generiques, cet article presente un framework en 3 etapes..." reduit la charge cognitive

4. **Pattern Ogilvy (utilise par Buffer)** : metaphore vivante → pivot vers les donnees

"Un titre peut etre soit la tarte sur le rebord de la fenetre, soit le videur de votre contenu. Tout est dans la formulation." → Puis immediatement : "En moyenne, 5 fois plus de personnes lisent le titre que le corps de l'article."

---

## PARTIE 6 — CE QUI RETIENT LE LECTEUR (donnees de scroll et engagement)

### 6.1 Le window de decision : 10-20 secondes

Le lecteur decide de rester ou partir en 10-20 secondes (40-80 mots). Tout ce qui suit est inutile si ce window est rate.

**Checklist des 80 premiers mots** :
- [ ] Le probleme du lecteur est nomme
- [ ] Un chiffre specifique ou un fait surprenant est present
- [ ] La promesse de valeur est claire
- [ ] Il y a une boucle ouverte qui tire vers la suite

### 6.2 Techniques classees par force de preuve

| Technique | Impact | Source |
|-----------|--------|--------|
| Video integree pertinente | +88% temps sur page | HubSpot |
| Hook dans les 10-20 premieres secondes | Determinant stay/leave | NNGroup |
| Correspondance exacte titre-contenu | Eliminatoire si rate | Copyblogger |
| Sous-titres tous les 200-400 mots | Augmente lecture profonde | NNGroup |
| Images et donnees visuelles | Casse le texte, ancre le scroll | NNGroup |
| Listes a puces pour les points cles | Valeur rapide = confiance pour continuer | NNGroup |
| Liens internes descriptifs | Maintient la navigation intra-site | Backlinko |
| Disclosure progressive | Chaque section revele une nouvelle valeur | Structure narrative |
| Vitesse de page < 2.4s | Seuil critique ; chaque seconde au-dessus de 3s perd 40% | Google |

### 6.3 La distribution du pouvoir du contenu

BuzzSumo (912 millions d'articles) :
- **1.3% des articles** captent **75% de tous les partages sociaux**
- **94% du contenu** n'obtient **zero backlink externe**
- Seulement 6% obtient au moins un lien

**Consequence** : la difference entre "moyen" et "exceptionnel" est un gouffre. Il vaut mieux ecrire 3 articles exceptionnels que 30 moyens.

---

## PARTIE 7 — FORMATS ET LONGUEUR OPTIMALE

### 7.1 Formats par performance de partage (BuzzSumo)

| Format | Performance partage |
|--------|-------------------|
| Video | +1200% vs texte seul |
| Infographies | +300% vs texte seul |
| Articles listes | +170% vs autres types |
| Guides long-form (3000-10000 mots) | Plus hauts partages moyens parmi le texte |

### 7.2 Longueur optimale par objectif

| Objectif | Longueur recommandee | Evidence |
|----------|---------------------|----------|
| Maximum backlinks | 3000+ mots | +77.2% de liens vs <1000 mots |
| Maximum partages sociaux | 3000-10000 mots | +56% vs <1000 mots |
| Rankings SEO | 1800-3200 mots | Moyenne des top-performers |
| Engagement blog general | 1000-2500 mots | Equilibre profondeur/engagement |
| Landing pages lead gen | Long-form | +220% plus de leads vs court |
| Quick-answer / news | 600-1000 mots | Intent etroit |

**Nuance critique** : la longueur doit etre justifiee par la profondeur, pas par du remplissage. Les rendements decroissent apres ~2000 mots pour les partages.

---

## PARTIE 8 — CONVERSION DEPUIS LE CONTENU

### 8.1 Donnees dures

| Metrique | Valeur |
|----------|--------|
| Taux de conversion avec content marketing vs sans | 6x plus eleve |
| Lecteurs qui trouvent le contenu data-backed plus fiable | 75% |
| Conversion avec engagement above-average | 2.3x plus eleve |
| ROI positif du long-form (marketeurs) | 85% |

### 8.2 Principes de conversion copywriting

**PAS (Problem-Agitate-Solve)** : identifier le probleme → intensifier le poids emotionnel → presenter la solution. C'est loss aversion + structure de resolution.

**AIDA (Attention-Interest-Desire-Action)** :
- Attention : titre + ouverture
- Interet : curiosity gap + donnees pertinentes
- Desir : social proof + endowment effect
- Action : next step clair

**Le test "Et alors ?"** : chaque affirmation doit etre suivie de son implication pour le lecteur. "L'entreprise X a grandi de 300% [et alors ?] — voici pourquoi ca change la donne pour votre activite."

**Principe de specificite** : "Augmentation du CA de 37.4%" est plus credible que "augmentation significative du CA". La specificite signale l'authenticite.

**Regle du lecteur unique** : ecrire a UNE personne, pas a un public. "Vous" est le mot le plus puissant en ecriture persuasive. Le cerveau traite les enonces en "vous" comme personnellement pertinents.

---

## PARTIE 9 — ECONOMIE COMPORTEMENTALE APPLIQUEE AUX ARTICLES

| Concept | Application article |
|---------|-------------------|
| **Nudge** (Thaler & Sunstein) | La structure de l'article oriente les conclusions : ordre des arguments, exemples choisis, ensembles de comparaison = architecture de choix |
| **Endowment Effect** | "Imaginez que vous avez deja ce systeme en place..." — une fois que le lecteur possede mentalement le resultat, loss aversion s'active |
| **Hyperbolic Discounting** | Les gens preferent les recompenses immediates. Promettre ET delivrer des quick wins tot dans l'article : "Voici quelque chose que vous pouvez implementer en 5 minutes" avant les conseils strategiques longs |
| **Mental Accounting** (Thaler) | Recadrer les couts : "Ca revient a moins que votre cafe quotidien" deplace la depense dans le compte mental "depenses quotidiennes triviales" |
| **Sunk Cost Fallacy** | Les articles longs qui engagent le lecteur tot exploitent ceci : "Vous avez deja lu jusqu'ici — voici le payoff" |
| **Status Quo Bias** | Les articles les plus puissants rendent l'inaction PLUS risquee que l'action : "Le cout de ne rien faire est..." |

---

## PARTIE 10 — ETHIQUE : PERSUASION LEGITIME vs MANIPULATION

### 10.1 Les 3 criteres

1. **Intention** : le but est-il d'aider le lecteur a prendre une meilleure decision, ou de l'exploiter ?
2. **Transparence** : si le lecteur comprenait la technique, l'accepterait-il comme juste ? La persuasion legitime survit a la transparence. La manipulation s'effondre.
3. **Veracite** : les affirmations sont-elles exactes ? Les stats reelles ? La social proof authentique ? L'autorite pertinente ?

### 10.2 Matrice ethique par technique

| Technique | Usage ethique | Usage non ethique |
|-----------|--------------|-------------------|
| Anchoring | Stats de contexte precises | Chiffres gonfles pour distordre la perception |
| Loss aversion | Risques reels d'inaction | Menaces fabriquees pour induire la panique |
| Social proof | Temoignages reels, chiffres exacts | Faux avis, metriques gonflees |
| Curiosity gap | Promesse exacte de contenu de valeur | Clickbait qui ne delivre pas |
| Rarete | Opportunites reellement limitees | Compteurs artificiels, fausse rarete |
| Autorite | Credentials verifiees et pertinentes | Expertise fabriquee ou non pertinente |
| FOMO | Information reellement sensible au temps | Urgence manufacturee pour l'engagement |

### 10.3 La regle de M-Campaign

Nos articles informent ET vendent. La ligne est claire : **delivrer sur chaque promesse que notre psychologie fait**. L'article doit etre utile MEME SI le lecteur n'achete jamais. La vente est une consequence de la valeur, pas un objectif qui contamine le contenu.

---

## PARTIE 11 — SCANNABLE WRITING (techniques NNGroup)

### 11.1 Les 6 techniques qui font +124%

1. **Mots-cles en gras** : liens, bold, variations de couleur. Le lecteur scanne les mots en gras pour evaluer la page
2. **Sous-titres significatifs** : descriptifs, pas malins/mignons. "7 erreurs de ciblage geo" > "Le probleme dont personne ne parle"
3. **Listes a puces** : extraction de valeur ultra-rapide
4. **Une idee par paragraphe** : les lecteurs sautent si les premiers mots ne les accrochent pas
5. **Pyramide inversee** : conclusion d'abord
6. **Moitie du nombre de mots** : vs ecriture conventionnelle

### 11.2 Anti-pattern : le "marketese"

NNGroup a mesure que le langage promotionnel/subjectif impose une **charge cognitive** : le lecteur depense des ressources mentales a filtrer l'hyperbole pour atteindre les faits.

Exemple : "La Bretagne est remplie d'attractions internationalement reconnues" declenche une reaction interne "non, c'est faux" qui ralentit le lecteur et le distrait.

**Mesurable sur les 4 axes de performance** — pas juste une preference, une degradation reelle.

---

## PARTIE 12 — VOICE OF CUSTOMER (VoC)

### 12.1 Principe (CopyHackers)

Utiliser les MOTS EXACTS que les lecteurs utilisent pour decrire leurs problemes. Quand un lecteur rencontre ses propres mots dans un article, la reconnaissance declenche la confiance et l'engagement.

Mecanisme : mere exposure effect + signalement in-group.

### 12.2 Comment collecter le VoC

- Commentaires sur les articles concurrents
- Forums / Reddit / Quora sur le sujet
- Avis clients (Google Reviews, Trustpilot)
- Conversations de vente / support
- Rapports de termes de recherche Google Ads (les vrais mots que les gens tapent)

### 12.3 Application dans les articles M-Campaign

Pour nos articles Google Ads artisans :
- Les artisans ne disent pas "CPC" — ils disent "le cout du clic"
- Ils ne disent pas "conversion" — ils disent "un appel" ou "un contact"
- Ils ne disent pas "ROI" — ils disent "est-ce que ca vaut le coup"
- Ils ne disent pas "budget quotidien" — ils disent "mon budget" ou "ce que je mets par jour"

**Utiliser LEUR vocabulaire dans les titres et les premieres phrases.**

---

## PARTIE 13 — MAILLAGE INTERNE ET CTA

### 13.1 Liens internes dans les articles

- Chaque article pointe vers 2-3 autres articles publies (maillage hub-and-spoke)
- Chaque article pointe vers la landing (/) avec un ancre descriptive, pas "cliquez ici"
- L'ancre du lien reprend l'intention de la page cible : "clics inutiles qui vident le budget" pour l'article sur les clics inutiles

### 13.2 CTA standard M-Campaign

Le CTA est dans le template [slug]/page.js — pas dans le contenu de l'article. Il apparait automatiquement apres le contenu. L'article lui-meme doit etre utile sans CTA.

Mentions naturelles de M-Campaign dans le contenu : maximum 1-2, toujours dans un contexte de solution ("M-Campaign fait exactement ce travail"), jamais en intro, jamais dans le titre.

---

## PARTIE 14 — DONNEES REELLES OBLIGATOIRES

### 14.1 La regle absolue

**JAMAIS de donnees inventees.** Sources autorisees :
- Donnees du compte client serrurier (Bretagne, oct-dec 2025)
- Donnees Google Keyword Planner (avec mention de la source)
- Etudes citees avec auteur + annee + institution
- Benchmarks d'industrie cites avec source

### 14.2 Quand on n'a pas de donnees

- Le dire : "On n'a pas de donnees propres sur ce metier, mais voici les benchmarks Google"
- Utiliser des fourchettes, pas des chiffres precis inventes
- Citer la source : "Selon le Keyword Planner pour la zone X..."
- NE JAMAIS ecrire "en general", "en moyenne" sans source

### 14.3 Donnees du compte serrurier (source de verite)

Budget total : ~1400€ sur 3 mois (oct-dec 2025). Zone : Ille-et-Vilaine + Mayenne.

| Mot-cle | CPC moyen | Fourchette |
|---------|-----------|-----------|
| Serrurier + ville | 3.50-4.50€ | 2.50-6€ |
| Serrurier generique | 6-8€ | Plus cher, moins qualifie |
| Urgence / nuit | 6-12€ | Premium |
| Long tail local | 4-5€ | Bon rapport qualite/prix |

| Mot-cle | Depense | Conversions | Cout/appel |
|---------|---------|------------|-----------|
| serrurier laval | 43€ | 6.5 | 6.68€ |
| serrurier dinard | 14€ | 3 | 4.82€ |
| serrurier rennes | 52€ | 1 | 52€ |
| serrurier saint-malo | 50€ | 1 | 50€ |
| serrurier (generique) | 57€ | 0 | infini |

Gaspillage estime : 250-300€ (20-25% du budget) sur clics hors zone, requetes DIY, mots-cles generiques.

---

## PARTIE 14B — RIGUEUR TECHNIQUE (retour audit article #3)

Lecons apprises sur l'article `budget-google-ads-epuise` — a appliquer a TOUS les articles.

### 14B.1 Eviter les affirmations trop absolues

Un lecteur expert peut sentir l'approximation. Notre positionnement doit etre : **tranchant, concret, mais defendable.**

**Pattern interdit → Pattern correct** :

| Interdit | Pourquoi | Correct |
|----------|----------|---------|
| "[Terme technique] n'a aucune intention X" | Trop absolu, techniquement faux | "[Terme] peut avoir une intention X, mais c'est souvent trop large/ambigu pour un petit budget" |
| "Le probleme n'est pas X. C'est Y." | Copy forte mais trop binaire | "Le probleme n'est pas toujours X. Tres souvent, c'est surtout Y." |
| "Fixez un CPC de X€" | Chiffre specifique sans contexte = conseil dangereux | "Testez un plafond coherent avec votre marche local" |
| "Google utilise [nom de feature inventé]" | Formulation qui sonne officielle mais n'existe pas | Decrire le MECANISME sans nommer une feature fictive |

**Regle** : chaque affirmation technique doit resister a la lecture d'un specialiste Google Ads. Si un pro peut lever un sourcil, nuancer.

### 14B.2 Titres SEO : completude semantique

Un titre "douleur" seul ("Budget epuise avant midi : pourquoi") est faible en SEO.

**Formule forte** : `[Probleme] : [nombre] causes et comment [solution]`

Exemples :
- "Budget Google Ads epuise avant midi : 6 causes et comment l'eviter"
- "CPC Google Ads qui explose : 7 causes et quoi faire"
- "Clics inutiles Google Ads : pourquoi vous payez pour rien"

Le titre doit contenir a la fois le **probleme** (capture de requete) et la **promesse de solution** (CTR).

### 14B.3 Sections obligatoires pour les articles "douleur"

Tout article qui diagnostique un probleme Google Ads doit inclure :

1. **Section "Signes que ce n'est PAS [faux diagnostic]"** — differencie l'article d'un conseil generique. Positionne l'auteur comme quelqu'un qui comprend la nuance, pas un vendeur de solution unique. Pattern : liste de 4-6 criteres checklist.

2. **Section "Comment verifier en 2 minutes"** — micro-tutorial actionnable juste avant le CTA. Augmente : utilite percue, temps sur page, credibilite, qualification du lecteur. Pattern : liste ordonnee de 4-6 etapes dans Google Ads.

**Placement** :
- "Signes que..." → apres le diagnostic, avant les actions correctives
- "Comment verifier..." → apres les actions, juste avant la mention M-Campaign

### 14B.4 Conseils contextuels, pas universels

Ne jamais donner un conseil absolu qui depend du contexte (zone, concurrence, volume, type de campagne).

**Pattern** : "Selon votre marche / zone / volume..." ou "Testez... le temps de comprendre ce qui fonctionne pour vous."

Un serrurier en zone tendue a besoin de CPC > 5€. Un serrurier en zone rurale peut s'en sortir a 2€. Le conseil doit fonctionner pour les deux.

---

## PARTIE 15 — TON ET STYLE M-CAMPAIGN

### 15.1 Ce qu'on est

- Direct, concret, sans detour
- On parle comme un collegue qui a vu les chiffres, pas comme un commercial
- On montre les erreurs qu'ON a faites, pas seulement celles des autres
- On dit "on" plus souvent que "nous" (plus naturel en francais oral)
- On utilise le vocabulaire du lecteur (VoC), pas le jargon marketing

### 15.2 Ce qu'on n'est pas

- Pas de bullshit marketing : interdits "unlock", "unleash", "enhance", "supercharge", "empower", "revolutionize", "leverage", "seamlessly", "cutting-edge", "next-gen"
- Pas de fausse expertise : si on ne sait pas, on le dit
- Pas de promesses vagues : pas de "ameliorez vos resultats", mais "reduisez votre cout par appel de 40%"
- Pas de condescendance : le lecteur est un artisan/independant intelligent qui n'a pas le temps d'analyser Google Ads, pas quelqu'un qui ne comprend pas

### 15.3 Longueur cible

- Articles metier (serrurier, plombier, etc.) : 1500-2500 mots
- Articles douleur (CPC explose, clics inutiles) : 1200-2000 mots
- Articles decision (freelance vs agence) : 1500-2500 mots
- Articles transparence (comment marche l'agent IA) : 1000-1800 mots

---

## PARTIE 16 — CHECKLIST PRE-PUBLICATION

### Titre
- [ ] 10+ variations generees, la meilleure selectionnee
- [ ] Passe le test de verite (represente fidelement le contenu)
- [ ] Passe le test de clarte (compris en <2 sec)
- [ ] Contient un element d'intrigue (benefice, douleur, preuve)
- [ ] 50-60 caracteres pour le SEO
- [ ] Ne tombe pas sous la loi de Betteridge

### Introduction (80 premiers mots)
- [ ] Le probleme du lecteur est nomme en premiere phrase
- [ ] Un chiffre specifique ou fait surprenant dans les 3 premieres phrases
- [ ] Une boucle ouverte (Zeigarnik) qui tire vers la suite
- [ ] Zero marketese

### Structure
- [ ] Pyramide inversee (conclusion d'abord)
- [ ] Sous-titres tous les 200-400 mots
- [ ] Sous-titres descriptifs (pas malins/mignons)
- [ ] Une idee par paragraphe
- [ ] Mots-cles en gras pour les scanners
- [ ] Listes a puces pour les points cles

### Contenu
- [ ] Aucune donnee inventee — tout est source ou explicitement fourchette/estimation
- [ ] VoC : vocabulaire du lecteur, pas jargon marketing
- [ ] Au moins 1 tableau avec des donnees concretes
- [ ] Chaque section delivre de la valeur (reciprocite)
- [ ] L'article est utile MEME SI le lecteur n'achete jamais

### Rigueur technique
- [ ] Aucune affirmation trop absolue — chaque claim technique resiste a un expert
- [ ] Pas de feature Google inventee ou mal nommee — decrire le mecanisme, pas nommer
- [ ] Conseils contextuels, pas universels — "testez selon votre marche" pas "fixez 5€"
- [ ] Nuances presentes : "souvent", "tres souvent", "peut", "selon" — pas "toujours", "jamais", "aucune"

### Sections obligatoires (articles douleur)
- [ ] Section "Signes que ce n'est PAS [faux diagnostic]" — presente, placee apres le diagnostic
- [ ] Section "Comment verifier en 2 minutes" — presente, placee avant le CTA

### SEO titre
- [ ] Titre contient le probleme ET la promesse de solution
- [ ] Format ideal : "[Probleme] : [nombre] causes et comment [solution]"
- [ ] Meta description differente du titre, 120-160 chars

### Maillage
- [ ] 2-3 liens vers d'autres articles publies
- [ ] 1 lien vers la landing (/) avec ancre descriptive
- [ ] Mentions M-Campaign : max 1-2, en contexte de solution, jamais en intro

### Technique
- [ ] Fichier cree dans `src/content/blog/{slug}.js`
- [ ] `published: true` dans `src/data/articles.js`
- [ ] Build check passe (`npx next build`)
- [ ] Commit + push

---

## PARTIE 17 — STRUCTURE TYPE D'UN ARTICLE M-CAMPAIGN

```jsx
import Link from 'next/link'

export default function Article() {
  return (
    <>
      {/* HOOK : douleur du lecteur + chiffre ancre + boucle ouverte */}
      <p>
        [Premiere phrase : le probleme du lecteur, dans SES mots.]
        [Deuxieme phrase : un chiffre specifique qui ancre.]
        [Troisieme phrase : boucle ouverte — "Voici ce qu'on a observe."]
      </p>

      {/* SECTION 1 : Les faits (donnees reelles) */}
      <h2>[Sous-titre descriptif avec mot-cle]</h2>
      <p>[Contexte + source des donnees]</p>
      <table>
        {/* Tableau de donnees reelles */}
      </table>
      <p>[Interpretation des donnees — qu'est-ce que ca signifie pour le lecteur]</p>

      {/* SECTION 2 : Ce qui marche (preuves) */}
      <h2>[Sous-titre orienté résultat]</h2>
      <p>[Exemple concret avec chiffres]</p>
      <p>[Pourquoi ca marche — explication simple]</p>

      {/* SECTION 3 : Ce qui ne marche pas (loss aversion) */}
      <h2>[Sous-titre orienté perte]</h2>
      <p>[Chiffrer le gaspillage / la perte]</p>
      <p>[Exemples specifiques]</p>

      {/* SECTION 4 : Actions concretes (reciprocite) */}
      <h2>[X actions concretes si vous etes [metier]]</h2>
      <ol>
        <li><strong>[Action 1]</strong> [Explication courte]</li>
        {/* ... */}
      </ol>

      {/* SECTION 5 : Resolution + mention naturelle M-Campaign */}
      <h2>[Sous-titre de synthese]</h2>
      <p>[Resolution de la boucle ouverte de l'intro]</p>
      <p>
        <Link href="/">M-Campaign</Link> [fait exactement ce travail :
        description factuelle de ce que l'agent fait en rapport avec l'article].
      </p>
    </>
  )
}
```

---

## PARTIE 18 — RESUME OPERATIONNEL

### La formule complete

```
Article qui convertit =
  Titre (curiosity gap + loss aversion + specificite)
  + Intro (hook 80 mots, boucle ouverte, zero marketese)
  + Structure (pyramide inversee, scannable, sous-titres descriptifs)
  + Contenu (donnees reelles, VoC, reciprocite, autorite)
  + Psychologie (Zeigarnik entre sections, anchoring sur les chiffres,
    social proof, loss framing sur les problemes)
  + Ethique (chaque promesse tenue, article utile sans achat)
  + CTA naturel (1-2 mentions, en contexte, jamais force)
```

### Les 3 regles qui surpassent tout le reste (NNGroup, quantifie)

1. **Concis** : moitie des mots → +58%
2. **Scannable** : puces, bold, sous-titres → +47%
3. **Objectif** : zero marketese → +27%
4. **Les trois combines** → **+124%**

Tout ce skill repose sur ces 3 piliers. La psychologie et les formules sont de l'optimisation par-dessus.
