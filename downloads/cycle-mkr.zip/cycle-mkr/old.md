---
name: cycle-mkr
description: Protocole d'implementation R&D par patches atomiques. Gere le cycle complet — init bloc, resume session, execute patch (LIRE/PLAN/CODER/CHECK/SMOKE/COMMIT), error loop, handoff session. Invoquer pour tout travail sur la roadmap M-CORP ou tout projet necessitant un pilotage rigoureux par patches.
user-invocable: true
argument-hint: "init <bloc-id> | resume | patch <P-id> | check | smoke | error | handoff | status | audit"
---

# /cycle-mkr — Protocole d'implementation par patches atomiques

## Principe fondamental

> On ne valide jamais un patch parce qu'il compile ; on le valide parce qu'il cree une propriete observable sans violer les invariants connus.

- Un **bloc** n'est pas une liste de taches ; c'est une propriete systeme a creer.
- Un **patch** n'est pas une modification de code ; c'est le plus petit changement reversible qui fait avancer vers cette propriete avec une preuve verifiable.
- Une **session** n'est pas "du temps de dev" ; c'est une suite finie de patches valides, documentes et repris sans ambiguite.

---

## Commandes

### `/cycle-mkr init <bloc-id>`

Initialise un nouveau bloc. Execute dans l'ordre :

1. **Lire la roadmap** — charger `corp-rd-roadmap.md` depuis la memoire, identifier le bloc concerne
2. **Lire l'analyse produit** — charger `corp-rd-product-analysis.md` pour les findings code verifies pertinents au bloc
3. **Lire la matrice d'invariants** — charger `_rd/INVARIANTS.md` s'il existe
4. **Explorer le code** — lire TOUS les fichiers qui seront touches par ce bloc. Pas de raccourci. Grep les dependances.
5. **Creer le dossier de bloc** avec 3 fichiers :

```
_rd/bloc-{id}/
  DOSSIER.md
  MANIFEST.md
  DECISIONS.md
```

#### DOSSIER.md — 5 sections obligatoires

```markdown
# Bloc {id} — {nom}

## Propriete creee
{Une seule phrase. Pas "ajouter X", mais "apres ce bloc, le systeme garantit Y".}

## Invariants a preserver
{Liste explicite de ce qui ne doit SURTOUT PAS changer. Copier les invariants globaux + ajouter les invariants sous-systeme pertinents.}

## Surface touchee
{Sous-systemes, modeles, workers, routes, jobs, etats metier — avec chemins de fichiers exacts.}

## Actifs reutilises
{Code, tables, services qui existent deja et qu'on reutilise. Avec references fichier:ligne.}

## Angles morts connus
{Ce qu'on sait ne PAS couvrir dans ce bloc. Limites explicites.}
```

#### MANIFEST.md — liste des patches

```markdown
# Manifest — Bloc {id}

Etat : not_started

## Patches

P1 — {description} — {fichiers max 4} — {preuve primaire} — {preuve non-cassure} — [ ] done
P2 — ...

## Regressions a verifier apres bloc
- [ ] Login owner fonctionne
- [ ] Login member fonctionne
- [ ] Chat agent repond
- [ ] SSE events arrivent au dashboard
- [ ] War Room demarre et conclut
- [ ] Pause instance conserve son sens
- [ ] Workers ne crevent pas au demarrage
- [ ] Admin panel accessible
{+ invariants sous-systeme specifiques au bloc}

## Decouvertes de session
{Vide au depart. Rempli au fil des patches.}
```

**Regles de decoupe des patches** :
- 1 propriete locale par patch
- 1 type de risque dominant
- 1 smoke test principal
- 4 fichiers maximum
- JAMAIS melanger migration DB + logique worker + UI dans un meme patch
- Des qu'un patch touche donnees + execution + policy + UI → le scinder

#### DECISIONS.md

```markdown
# Decisions — Bloc {id}

{Vide au depart. Une entree par decision prise pendant l'implementation.}
```

6. **Mettre a jour `_rd/INVARIANTS.md`** si de nouveaux invariants de sous-systeme sont identifies
7. **Presenter le manifest au user** — afficher les patches proposes, demander validation avant de coder

---

### `/cycle-mkr resume`

Reprend une session interrompue. Ordre FIXE, NON NEGOCIABLE :

1. **Identifier le bloc en cours** — trouver le `_rd/bloc-*/MANIFEST.md` avec `Etat : in_progress`
2. **Lire le DOSSIER.md** du bloc — retrouver la propriete, les invariants, la surface
3. **Lire le MANIFEST.md** — identifier le dernier patch `[x] done` et le prochain `[ ] done`
4. **Lire le DECISIONS.md** — retrouver les arbitrages et raisons
5. **Lire le dernier commit** — `git log -1 --format="%H %s"` pour confirmer l'etat
6. **Verifier les fichiers modifies non commites** — `git status` pour detecter du travail en cours non handoff
7. **Seulement ensuite** relire le code concerne par le prochain patch
8. **Afficher au user** : bloc en cours, dernier patch termine, prochain patch, decouvertes notees

Si `git status` montre des modifications non commitees → **ALERTE** : session precedente n'a pas respecte le handoff. Demander au user quoi faire avant de continuer.

---

### `/cycle-mkr patch <P-id>`

Execute un patch specifique. 6 phases strictement sequentielles :

#### Phase 1 — LIRE

- Lire EN ENTIER chaque fichier liste dans le patch (pas juste la zone a modifier)
- Grep chaque symbole qui sera modifie/ajoute dans tout le projet
- Identifier toutes les dependances : qui importe ce fichier ? qui utilise ce type ? qui appelle cette fonction ?
- **BLOCKER** : ne PAS passer a la phase 2 si un fichier n'a pas ete lu ou si une dependance n'a pas ete greppee

#### Phase 2 — PLAN

- Decrire le DIFF ATTENDU — pas le concept, le changement exact ligne par ligne
- Nommer la preuve primaire (comment on verifie que ca marche)
- Nommer la preuve de non-cassure (comment on verifie que rien n'est casse)
- **Afficher le plan au user** et attendre validation avant de coder

#### Phase 3 — CODER

- Implementer exactement le diff planifie
- Si un cas imprevu apparait en codant :
  - STOP
  - Evaluer si ca change le plan
  - Si oui : noter dans DECISIONS.md, ajuster le plan, informer le user
  - Si non : continuer
- Ne PAS improviser de changements non planifies

#### Phase 4 — CHECK

Verification structurelle. CHECK ≠ SMOKE. CHECK = "ca ne s'effondre pas".

**Python/FastAPI** :
```bash
cd corp-api && python -m py_compile {fichier_modifie}
cd corp-api && python -c "from main import app; print('OK')"
```

**TypeScript/Next.js** :
```bash
cd dashboard && ./node_modules/.bin/tsc --noEmit
```

**Grep de coherence** :
- Grep chaque symbole ajoute/renomme/supprime dans TOUT le projet
- Verifier que tous les imports sont presents
- Verifier qu'aucun fichier dependant n'est casse

**Patterns auto-detectables (grep apres chaque patch)** :
- `AdminSessionLocal` + `publish_event` dans le meme fichier sans `admin_tx` → P16
- Nouveau `instance_id = Column(UUID` sans `ForeignKey` → P22
- `updated_at = Column(DateTime` sans `onupdate` → P23
- `Column(JSONB, default=` sans `server_default` → P24
- `.scalars().all()` sans `.limit()` → P25
- `.slice(0, -1)` dans un setMessages → P19
- `select(...)` + `.where(status ==` + modification status SANS `.with_for_update()` → P18

**Si CHECK echoue** → passer a `/cycle-mkr error`

#### Phase 5 — SMOKE

Verification comportementale. SMOKE = "la propriete demandee existe vraiment".

- Executer le scenario defini dans la preuve primaire du manifest
- Executer le scenario de la preuve de non-cassure
- Le resultat attendu doit etre EXPLICITE et OBSERVABLE

Exemples de smoke tests valides :
- "instance paused → `python -c 'from services.outreach_sender import ...; ...'` → aucun envoi"
- "curl -X POST /client/chat/stratege → retourne 200 avec status processing"
- "grep 'instance.status' outreach_sender.py → guard present a la ligne X"

Exemples de smoke tests INVALIDES :
- "ca devrait marcher"
- "le typecheck passe donc c'est bon"
- "j'ai relu le code et ca me parait correct"

**Si SMOKE echoue** → passer a `/cycle-mkr error`

#### Phase 6 — COMMIT

```bash
git add {fichiers_du_patch_uniquement}
git commit -m "{message decrivant la propriete creee}"
```

Puis mettre a jour le MANIFEST.md :
- Cocher `[x] done` sur le patch
- Ajouter les decouvertes eventuelles dans "Decouvertes de session"
- Si c'est le dernier patch du bloc : passer l'etat a `done` et lancer les regressions

---

### `/cycle-mkr check`

Lance la phase CHECK seule (utile pour re-verifier apres un fix).

Execute :
1. py_compile sur les .py modifies
2. `from main import app` import check
3. tsc --noEmit si fichiers TS modifies
4. Grep des symboles modifies dans tout le projet
5. Rapport : PASS ou FAIL avec details

---

### `/cycle-mkr smoke`

Lance la phase SMOKE seule.

1. Lire le manifest pour trouver le patch en cours
2. Executer la preuve primaire
3. Executer la preuve de non-cassure
4. Rapport : PASS ou FAIL avec details

---

### `/cycle-mkr error`

Active le protocole d'erreur. Sequence stricte :

```
1. STOP — ne pas enchainer de tentatives
2. Relire le fichier ENTIER (pas juste la zone d'erreur)
3. Grep les dependances du symbole en erreur
4. Comparer l'etat actuel au patch planifie dans le manifest
5. CLASSIFIER l'erreur :
   a) Erreur locale d'implementation — typo, mauvaise syntaxe, oubli d'import
   b) Mauvaise hypothese sur dependance — le code appele ne fait pas ce qu'on croyait
   c) Patch trop large — trop de choses changees en meme temps
   d) Plan faux — le diff planifie ne peut pas fonctionner tel quel
6. Afficher la classification au user
7. Deuxieme tentative MAXIMUM — avec correction basee sur la classification
8. Si echec encore :
   - git checkout -- {fichiers du patch}   (revert)
   - Mettre a jour MANIFEST.md : marquer le patch comme "blocked"
   - Noter la cause dans DECISIONS.md
   - Proposer une re-scission du patch au user
```

**REGLE CRITIQUE** : la classification est OBLIGATOIRE. Sans elle, on repete des tentatives aveugles. Un LLM qui retry sans classifier ne fait que varier le bruit.

---

### `/cycle-mkr handoff`

Termine proprement une session. Execute dans l'ordre :

1. **Verifier git status** — aucun fichier modifie non commite
   - Si fichiers non commites : proposer commit ou stash, ne PAS quitter sans resoudre
2. **Mettre a jour MANIFEST.md** :
   - Etat de chaque patch (done / in_progress / blocked)
   - Decouvertes de session
   - Prochain patch a faire
3. **Mettre a jour DECISIONS.md** si des arbitrages ont ete pris
4. **Rapport de session** au user :
   - Patches termines
   - Patches restants
   - Blocages eventuels
   - Prochaine action recommandee

**4 conditions de sortie — TOUTES obligatoires** :
- [ ] Aucun code modifie non commite
- [ ] Manifest a jour
- [ ] Decisions notees
- [ ] Aucun patch dans un etat ambigu

---

### `/cycle-mkr status`

Affiche l'etat courant sans rien modifier.

1. Trouver tous les `_rd/bloc-*/MANIFEST.md`
2. Pour chaque bloc :
   - Etat du bloc
   - Nombre de patches done / total
   - Dernier patch termine
   - Prochain patch
3. Verifier `git status` pour modifications pendantes
4. Afficher un resume synthetique

### `/cycle-mkr audit`

Boucle d'audit multi-rounds. C'est l'etape ultime apres completion de la roadmap ou d'un groupe de blocs. Objectif : 0 bugs CRITICAL/HIGH.

**Quand declencher :** apres chaque serie de 3-5 blocs, ou a la fin de la roadmap complete.

#### Structure d'un round

Chaque round suit strictement ces 3 phases :

**Phase 1 — ANALYSE (agents paralleles)**

Lancer 5+ agents en parallele, chacun couvrant un domaine DISTINCT :

| Agent | Domaine | Ce qu'il cherche |
|-------|---------|------------------|
| A1 | Routers / endpoints | Permissions manquantes, route ordering, UUID validation, error responses, path params |
| A2 | Services / workers | Race conditions, dead code, resource leaks, error handling, stale content |
| A3 | Models / DB | Constraint mismatches, orphan references, cascade effects, missing indexes |
| A4 | Frontend / flows | State leaks (busyRef, thinking never reset), NaN propagation, modal state cleanup, error silencing |
| A5 | Cross-cutting | Auth flows end-to-end, SSE reliability, JSON serialization, quota atomicity |
| A6+ | Live tests | Smoke tests reels (curl, docker logs, DB queries) si acces VPS disponible |

**Regles agents :**
- Chaque agent lit les fichiers EN ENTIER, pas des extraits
- Chaque finding doit citer : fichier, ligne, severite (CRITICAL/HIGH/MEDIUM/LOW), correction proposee
- Pas d'opinions, pas de style — uniquement des bugs fonctionnels ou de securite

**Phase 2 — CORRECTION**

Pour chaque finding CRITICAL puis HIGH :
1. Lire le fichier entier
2. Appliquer le fix
3. CHECK (py_compile / tsc --noEmit)
4. Grep les dependances du symbole modifie

Ne PAS corriger les MEDIUM/LOW dans le meme round — ils risquent d'introduire des regressions. Les noter pour le round suivant.

**Phase 3 — COMMIT + NEXT ROUND**

1. `git add` uniquement les fichiers modifies
2. Commit avec message : `audit R{N}: {description des corrections}`
3. Re-CHECK complet (py_compile ALL + tsc)
4. Lancer Round N+1

#### Condition d'arret

La boucle s'arrete quand un round complet retourne **0 findings CRITICAL ou HIGH**.

Les MEDIUM/LOW restants sont documentes dans `_rd/AUDIT.md` comme dette technique connue.

#### Elargissement entre rounds

A chaque round, **elargir les axes d'analyse** :
- Round 1 : permissions, route ordering (surface evidente)
- Round 2 : error handling, null guards, race conditions
- Round 3 : workers, SSE, data integrity, frontend state leaks
- Round 4+ : end-to-end flows, edge cases, cross-service dependencies

Ne JAMAIS se concentrer sur le meme aspect deux rounds de suite. L'audit est exploratoire par nature — si un round ne trouve rien de nouveau, c'est qu'on ne cherche pas assez large.

#### Rapport de fin d'audit

Apres le dernier round (0 CRITICAL/HIGH) :
```markdown
# Audit Report — {date}

## Rounds executes : {N}
## Findings total : {count} (CRITICAL: X, HIGH: Y, MEDIUM: Z, LOW: W)
## Fixes appliques : {count}
## Dette residuelle : {count MEDIUM/LOW non corriges}

## Corrections par round :
- R1: ...
- R2: ...
- RN: 0 CRITICAL/HIGH → audit termine
```

---

## Matrice d'invariants globaux

Ces invariants sont verifies apres CHAQUE bloc termine. La liste grandit avec les blocs.

```
INVARIANTS GLOBAUX (toujours vrais) :
- [ ] Login owner fonctionne
- [ ] Login member fonctionne
- [ ] Chat agent repond (POST /client/chat/{agent_id} → 200)
- [ ] SSE events arrivent au dashboard
- [ ] War Room demarre et conclut
- [ ] Pause instance conserve son sens
- [ ] 4 workers demarrent sans crash (outreach, cron, schedule, content)
- [ ] Admin panel accessible

INVARIANTS SOUS-SYSTEME (si touche) :
- Outreach : envoi, tracking, sequences, statuts
- Coordination : start, cancel, timeout, synthese
- Quotas : refus, consommation, plan, page usage
- Auth : owner login, member login, refresh, permissions
- Scheduling : crons executent, self-scheduling, templates
- Checkpoints : creation, approbation, rejet, expiration
- Integrations : connect, disconnect, execute_action
```

---

## Emplacement des fichiers de pilotage

```
{project-root}/
  _rd/
    INVARIANTS.md         ← matrice globale, grandit avec les blocs
    METHOD.md             ← copie de reference de la methode
    bloc-00/
      DOSSIER.md          ← intention du bloc
      MANIFEST.md         ← patches, preuves, etat
      DECISIONS.md        ← arbitrages et raisons
    bloc-01/
      ...
```

Les fichiers `_rd/` sont DANS le repo, commites avec le code. Pas dans la memoire Claude. Lisibles a chaque reprise de session sans dependance a la compaction.

---

## Patterns appris en production (post-mortem blocs 0-12)

Ces patterns n'etaient pas prevus a la creation du protocole. Ils sont issus de bugs reels, d'erreurs de process, et de decouvertes pendant l'execution des 12 blocs R&D M-CORP.

### P1 — `python3` pas `python`

La commande CHECK utilise `python -m py_compile`. Sur les systemes modernes (Ubuntu 24+, Pop!_OS), `python` n'existe pas — seul `python3` est disponible. **Toujours utiliser `python3`.**

```bash
# CORRECT
python3 -m py_compile fichier.py

# FAUX — exit code 127 "command not found"
python -m py_compile fichier.py
```

### P2 — Route ordering FastAPI (specifique → generique)

Dans FastAPI, les routes a path params (`{id}`) capturent tout ce qui n'a pas ete matche avant. Les routes fixes DOIVENT etre declarees AVANT les routes parametrees dans le meme prefixe.

```python
# CORRECT
@router.get("/prospects/duplicates")   # fixe — AVANT
@router.get("/prospects/merge")        # fixe — AVANT
@router.get("/prospects/{prospect_id}")  # param — APRES

# FAUX — "duplicates" sera capture comme prospect_id
@router.get("/prospects/{prospect_id}")  # param — capture tout
@router.get("/prospects/duplicates")     # jamais atteint
```

**CHECK obligatoire** : a chaque ajout de route, grep le prefixe et verifier l'ordre de toutes les routes partageant ce prefixe.

### P3 — Migration SQL manuelle = patch separe

Le protocole original ne prevoyait pas de step explicite pour les migrations DB. En pratique, chaque table/colonne ajoutee necessite :

1. Un fichier modele SQLAlchemy (dans le patch code)
2. Une migration SQL manuelle executee sur le VPS via `docker exec`
3. Des policies RLS + GRANTS si la table est accessible par `corp_user`

**Regle** : la migration SQL est documentee dans le MANIFEST.md du patch qui cree le modele, et executee au moment du deploy — PAS dans un patch separe.

Template migration :
```sql
-- CREATE TABLE (si nouveau modele)
CREATE TABLE IF NOT EXISTS corp_xxx (...);
CREATE INDEX IF NOT EXISTS idx_xxx ON corp_xxx (...);

-- RLS (si donnees client)
ALTER TABLE corp_xxx ENABLE ROW LEVEL SECURITY;
CREATE POLICY xxx_isolation ON corp_xxx
    FOR ALL TO corp_user
    USING (instance_id IN (SELECT id FROM corp_instances WHERE client_id = current_setting('app.current_client_id')::uuid));
GRANT SELECT, INSERT, UPDATE, DELETE ON corp_xxx TO corp_user;
GRANT ALL ON corp_xxx TO corp_admin;

-- ALTER TABLE (si ajout de colonne)
ALTER TABLE corp_xxx ADD COLUMN IF NOT EXISTS yyy TYPE DEFAULT val;
```

### P4 — Deploy = push + VPS pull + build + restart + logs

Le cycle deploy est toujours le meme. Le dashboard deploie automatiquement via Vercel au push. L'API necessite un rebuild manuel.

```bash
# 1. Push
git push origin main

# 2. VPS
ssh vps-api "cd /opt/marpeap-corp && git pull origin main"
ssh vps-api "cd /opt/marpeap-corp && docker compose -f docker-compose.corp.yml build --no-cache corp-api"
ssh vps-api "cd /opt/marpeap-corp && docker compose -f docker-compose.corp.yml up -d corp-api"
sleep 3
ssh vps-api "docker logs corp_api --tail 10"
```

**JAMAIS** : `docker compose build corp-dashboard` — ce service n'existe pas. Le dashboard est sur Vercel.

### P5 — Permission checks : le pattern complet

Chaque endpoint `client.py` DOIT avoir cette sequence :
```python
token, db = auth
_require_client(token)                    # Bloque les admins
require_permission(token, "page:xxx")     # Bloque les membres sans permission
instance = await _get_instance(db, token) # Charge l'instance
```

**Si l'un des 3 manque**, c'est un bug de securite. La phase CHECK apres chaque patch qui touche `client.py` doit grep `_require_client` et `require_permission` sur chaque endpoint.

### P6 — UUID validation sur path params

FastAPI ne valide PAS les string path params comme des UUIDs. Si `prospect_id: str` recoit `"abc"`, ca passera au `.where(CorpProspect.id == "abc")` et SQLAlchemy lancera une erreur de cast.

**Pattern** :
```python
try:
    _uuid.UUID(prospect_id)
except ValueError:
    raise HTTPException(status_code=422, detail="ID invalide")
```

A appliquer sur TOUT path param qui sera utilise comme UUID dans une query DB.

### P7 — `flag_modified` pour JSONB

SQLAlchemy ne detecte pas les mutations in-place sur les colonnes JSONB. Apres modification, appeler `flag_modified` :

```python
from sqlalchemy.orm.attributes import flag_modified

instance.brand_guidelines = new_value
flag_modified(instance, "brand_guidelines")
await db.flush()
```

L'import doit etre au top du fichier, PAS a l'interieur de la fonction (redondance).

### P8 — CheckConstraints : modele ≠ DB

Les `CheckConstraint` dans les modeles SQLAlchemy sont informatifs. Les vrais constraints sont dans la DB (via migrations). Si on ajoute une valeur au modele (ex: `'sending'` dans outreach status), il faut AUSSI :

1. `ALTER TABLE DROP CONSTRAINT` l'ancien
2. `ALTER TABLE ADD CONSTRAINT` avec la nouvelle liste

**Pattern de verification** :
```sql
SELECT conname FROM pg_constraint WHERE conrelid = 'corp_xxx'::regclass AND contype = 'c';
```

### P9 — Boucle d'audit multi-rounds (voir `/cycle-mkr audit`)

Apres chaque serie de blocs (3-5), ou a la fin de la roadmap, lancer `/cycle-mkr audit`. Voir la commande dediee ci-dessous.

### P11 — JSON serialization safety

`json.dumps` crash silencieusement sur les types non-serializables (UUID, datetime, Decimal, set). Avant tout `json.dumps` sur un dict contenant des valeurs provenant de la DB :

```python
safe = {}
for k, v in payload.items():
    if isinstance(v, (str, int, float, bool, type(None), list, dict)):
        safe[k] = v
    else:
        safe[k] = str(v)
json.dumps(safe)
```

### P12 — Expired state guard

Tout objet avec un `expires_at` doit etre verifie AVANT action. Ne pas se fier uniquement au `.status == "pending"` — le status peut ne pas avoir ete mis a jour si le cron d'expiration n'a pas encore tourne.

```python
if obj.expires_at and obj.expires_at < datetime.now(timezone.utc):
    obj.status = "expired"
    raise HTTPException(status_code=410, detail="Objet expire")
```

### P13 — FK reassignment avant delete

Avant de supprimer une entite (prospect, instance, etc.), TOUJOURS reassigner les FK dependantes :

```python
# AVANT db.delete(secondary)
await db.execute(update(ChildTable).where(ChildTable.parent_id == secondary.id).values(parent_id=primary.id))
```

Les FK avec `ondelete="CASCADE"` supprimeraient les enfants. Les FK avec `ondelete="SET NULL"` les orphelineraient. Ni l'un ni l'autre n'est souhaitable dans un merge — il faut reassigner.

### P14 — Frontend state cleanup on close/error

Chaque modal ou flow qui set un state bloquant (`connecting`, `busy`, `loading`) DOIT le reset dans :
- `onClose` callback
- `catch` block
- cleanup function du `useEffect`

```typescript
onClose={() => { setShowModal(false); setConnecting(null); connectingRef.current = false; }}
```

### P15 — NaN propagation

`Number("")` retourne `0`, mais `Number("abc")` retourne `NaN`. Toujours ajouter un fallback :

```typescript
onChange={(e) => { const v = parseInt(e.target.value); setValue(isNaN(v) ? 0 : Math.max(0, v)); }}
```

### P10 — Mode autonome

Quand le user donne l'instruction "continues sans t'arreter" ou "je te laisse gerer", le protocole passe en mode autonome :

- **Phase 2 (PLAN)** : ne PAS attendre validation explicite — afficher le plan et enchainer
- **Phase 6 (COMMIT)** : committer et passer au patch suivant
- **Handoff** : reporter au user uniquement en fin de bloc, pas a chaque patch
- **Les regles dures restent applicables** : CHECK et SMOKE ne sont pas optionnels meme en mode autonome

### P16 — `admin_tx()` obligatoire pour `publish_event()` en background

Les workers/crons qui utilisent `AdminSessionLocal()` directement ne flushent PAS les events Redis. `publish_event()` queue les events sur `db.info["pending_redis_events"]`, mais seul `admin_tx()` (ou `get_admin_db`) appelle `_flush_redis_events()` apres commit.

```python
# FAUX — events silencieusement perdus
async with AdminSessionLocal() as db:
    async with db.begin():
        await publish_event(db, ...)
    # _flush_redis_events() JAMAIS appele

# CORRECT
async with admin_tx() as db:
    await publish_event(db, ...)
# _flush_redis_events() appele automatiquement
```

**Origine** : bug CRITICAL decouvert en R7 — le content publisher publiait des events que le dashboard ne recevait jamais.

### P17 — Toute dependance auth DOIT checker le statut membre

`get_current_client()` et `get_authenticated_db()` sont deux chemins auth distincts. Seul `get_authenticated_db()` appelait `_check_member_status()`. Un membre suspendu/supprime gardait l'acces SSE via `get_current_client()`.

**Regle** : chaque nouvelle dependance auth qui retourne un `TokenData` DOIT appeler `_check_member_status(token_data)` avant de retourner.

**Origine** : bug CRITICAL decouvert en R7 auth audit.

### P18 — FOR UPDATE sur check-then-modify

Tout endpoint qui lit un statut, le verifie, puis le modifie est une race condition sans `FOR UPDATE`. Deux requetes concurrentes peuvent toutes deux lire `status="pending"` et toutes deux approuver/rejeter.

```python
# FAUX — race condition
result = await db.execute(
    select(CorpCheckpoint).where(CorpCheckpoint.status == "pending")
)

# CORRECT
result = await db.execute(
    select(CorpCheckpoint).where(CorpCheckpoint.status == "pending")
    .with_for_update()
)
```

**Appliquer a** : approve, reject, status transitions, integration polling.

**Origine** : bugs CRITICAL x3 decouverts en R6 race conditions audit.

### P19 — Rollback optimiste par ID, pas par position

`setMessages(prev => prev.slice(0, -1))` supprime le dernier message. Si un event SSE a ajoute un message entre-temps, c'est le mauvais message qui est supprime.

```typescript
// FAUX
setMessages((prev) => prev.slice(0, -1));

// CORRECT — capturer l'ID avant l'ajout
const localId = nextLocalId();
setMessages((prev) => [...prev, { id: localId, ... }]);
// En cas d'erreur :
setMessages((prev) => prev.filter((m) => m.id !== localId));
```

**Origine** : bug HIGH decouvert en R7 frontend audit.

### P20 — Guard synchrone (useRef) pour les async handlers

Le state React (`sending`) dans un `useCallback` est capture dans une closure stale. Deux clics rapides peuvent passer le guard si React n'a pas encore batch-update le state.

```typescript
// FAUX — stale closure
const send = useCallback(async () => {
  if (sending) return; // peut etre stale
  setSending(true);

// CORRECT — ref synchrone
const busyRef = useRef(false);
const send = useCallback(async () => {
  if (busyRef.current) return;
  busyRef.current = true;
```

**Origine** : bug HIGH en R7 — chat/page.tsx n'avait pas de busyRef (contrairement a [agentId]/page.tsx).

### P21 — Propager role/permissions dans les tokens derives

Quand on cree un token derive (SSE, webhook), propager `role`, `member_id`, `permissions` depuis le token parent. Sinon le token derive a `role="owner"` par defaut — privilege escalation latente.

```python
# FAUX — role/permissions perdus
sse_token = create_access_token(subject=token.sub, scope="sse")

# CORRECT
sse_token = create_access_token(
    subject=token.sub, scope="sse",
    role=token.role, member_id=token.member_id,
    permissions=token.permissions,
)
```

**Origine** : bug HIGH decouvert en R7 auth audit.

### P22 — ForeignKey(ondelete=CASCADE) sur chaque instance_id

Chaque modele avec `instance_id` DOIT avoir `ForeignKey("corp_instances.id", ondelete="CASCADE")`. Sans ca, la suppression d'instance laisse des lignes orphelines.

**Check** : apres chaque nouveau modele, grep `instance_id = Column` et verifier la presence de `ForeignKey`.

**Origine** : 3 modeles (signal, action_decision, team_member) decouverts sans FK en R6 data integrity audit.

### P23 — `onupdate` sur les colonnes `updated_at`

Chaque `updated_at` DOIT avoir `onupdate=lambda: datetime.now(timezone.utc)`, pas seulement `default`. Sinon la colonne n'est settee qu'a l'insert.

```python
# FAUX
updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

# CORRECT
updated_at = Column(DateTime(timezone=True),
    default=lambda: datetime.now(timezone.utc),
    onupdate=lambda: datetime.now(timezone.utc))
```

**Origine** : CorpPlaybook et CorpPlaybookStandard decouverts en R7 DB audit.

### P24 — `server_default` sur les colonnes JSONB

Chaque colonne JSONB avec un `default` Python DOIT aussi avoir un `server_default`. Sans ca, les INSERT via raw SQL ou migration laissent la colonne NULL, et le code Python crashe sur `obj.metrics["likes"]`.

```python
metrics = Column(JSONB,
    default=lambda: {"likes": 0},
    server_default='{"likes":0}')
```

**Origine** : CorpContent.metrics decouvert en R7 DB audit.

### P25 — `.limit()` sur toute query liste

Toute query SELECT qui retourne une liste DOIT avoir un `.limit()`. Sans ca, un agent qui accumule des milliers de drafts fait OOM.

**Origine** : content calendar sans limit, export unbounded — R7 DB audit.

### P26 — Reset des etats d'erreur avant refetch

Un `useEffect` qui fetch des donnees DOIT reset les etats d'erreur au debut :

```typescript
useEffect(() => {
  setError(null);      // OBLIGATOIRE
  setNoInstance(false); // OBLIGATOIRE si applicable
  api.getData(token).then(...).catch(...)
}, [token]);
```

Sans ca, une erreur d'un premier chargement persiste meme apres un retry reussi.

**Origine** : overview/page.tsx — R7 frontend audit.

### P27 — State machine : valider le statut source avant transition

Les endpoints qui changent un statut DOIVENT verifier le statut actuel :

```python
if content.status not in ("draft", "scheduled"):
    raise HTTPException(status_code=409, detail=f"Cannot publish from '{content.status}'")
content.status = "published"
```

Sans ca, un agent peut re-publier du contenu deja publie ou ressusciter du contenu echoue.

**Origine** : content publish/schedule sans validation — R6 data integrity audit.

### P28 — RLS + GRANT sur CHAQUE nouvelle table

Chaque table avec `instance_id` accessible par les clients necessite :
1. `ALTER TABLE ENABLE ROW LEVEL SECURITY`
2. `CREATE POLICY` avec le bon predicat
3. `GRANT SELECT, INSERT, UPDATE, DELETE TO corp_user`

**8 tables** etaient sans RLS a la fin du bloc-12 (signals, action_decisions, touchpoints, playbooks, playbook_standards, kling_tasks, artifacts, artifact_settings).

**Origine** : bug CRITICAL decouvert en R7 DB audit.

### P29 — Redis publish dans un try-except en boucle critique

Tout `redis_client.publish()` dans une boucle (coordination, workers, SSE relay) DOIT etre dans un try-except. Une erreur Redis non catchee tue la boucle entiere.

```python
async def _safe_publish(channel: str, payload: str) -> None:
    try:
        await redis_client.publish(channel, payload)
    except Exception as e:
        logger.warning("Redis publish failed: %s", e)
```

**Origine** : 5 publish non proteges dans coordination_service — R6 race conditions audit.

---

## Regles dures — rappel

1. **Blast radius** : 1 propriete, 1 risque, 1 smoke, 4 fichiers max par patch
2. **Preuves** : definies AVANT codage, pas apres
3. **CHECK ≠ SMOKE** : compilation ≠ comportement
4. **Error loop** : classifier AVANT de retry, 2 tentatives max, puis revert
5. **Handoff** : rien ne reste en suspens entre sessions
6. **Resume** : lire dossier → manifest → decisions → commit → code (dans cet ordre)
7. **Pas d'improvisation** : si un cas imprevu apparait, STOP, noter, ajuster le plan, informer le user
8. **Pas de melange** : migration DB + worker + UI = 3 patches, pas 1
9. **Permission checks** : chaque endpoint client.py = _require_client + require_permission + _get_instance (P5)
10. **Route ordering** : grep le prefixe apres ajout, verifier ordre specifique → generique (P2)
11. **UUID validation** : chaque path param UUID doit etre valide AVANT la query DB (P6)
12. **CheckConstraint sync** : modele ET DB doivent avoir les memes valeurs (P8)
13. **JSON serialization** : `json.dumps` crash sur UUID/datetime → coercer en `str()` avant publish (P11)
14. **Expired state guard** : toujours verifier l'expiration AVANT d'agir sur un objet avec TTL (P12)
15. **Merge reassignment** : avant de supprimer une entite, reassigner toutes ses FK dependantes (P13)
16. **Frontend state cleanup** : chaque modal/flow qui set un state busy/connecting DOIT reset sur close/error (P14)
17. **NaN propagation** : chaque `Number(e.target.value)` sur un input DOIT fallback sur 0 ou valeur par defaut (P15)
18. **admin_tx pour publish_event** : tout background worker qui appelle `publish_event` DOIT utiliser `admin_tx()`, jamais `AdminSessionLocal()` nu (P16)
19. **Auth status check** : toute dependance auth doit appeler `_check_member_status()` (P17)
20. **FOR UPDATE** : tout check-then-modify sur un statut → `.with_for_update()` (P18)
21. **Rollback par ID** : rollback optimiste frontend = `filter(m => m.id !== localId)`, jamais `slice(0,-1)` (P19)
22. **Guard useRef** : guard contre double-exec dans async callback = `busyRef.current`, pas state (P20)
23. **Token derive complet** : propager role/member_id/permissions dans les tokens SSE/webhook (P21)
24. **FK instance_id** : chaque modele avec instance_id → `ForeignKey("corp_instances.id", ondelete="CASCADE")` (P22)
25. **onupdate updated_at** : chaque updated_at → `onupdate=lambda: datetime.now(timezone.utc)` (P23)
26. **server_default JSONB** : chaque JSONB avec default Python → ajouter server_default (P24)
27. **Limit sur les listes** : toute query SELECT liste → `.limit(N)` (P25)
28. **Reset erreur avant fetch** : `setError(null)` au debut de chaque useEffect qui fetch (P26)
29. **State machine** : valider status source avant transition (P27)
30. **RLS + GRANT** : chaque nouvelle table avec instance_id → ENABLE RLS + POLICY + GRANT (P28)
31. **Redis try-except** : tout publish Redis dans une boucle → try-except avec log warning (P29)
