---
name: cycle-mkr
description: Protocole R&D par patches atomiques pour travail rigoureux sur la roadmap M-CORP et les sous-systemes critiques. Gere init bloc, reprise de session, execution de patch (LIRE/PLAN/CODER/CHECK/SMOKE/COMMIT), release gate, boucle d'erreur, handoff, exceptions, audit et apprentissage post-incident.
user-invocable: true
argument-hint: "init <bloc-id> | resume | patch <P-id> | check | smoke | release | error | handoff | status | audit | exception | incident"
---

# /cycle-mkr

## 0. But

Le protocole sert a faire avancer un systeme vivant sans casser ses invariants, sans perdre l'etat entre sessions, et sans exposer un changement risqué sans preuves adaptees.

> On ne valide jamais un patch parce qu'il compile ; on le valide parce qu'il cree une propriete observable sans violer les invariants connus.

Definitions :

- Un **bloc** est une propriete systeme a creer.
- Un **patch** est le plus petit changement reversible qui fait progresser vers cette propriete avec une preuve verifiable.
- Une **session** est une suite finie de patches documentes, verifiables et reprenables sans ambiguite.
- Une **release** est une unite d'exposition au risque en environnement reel. Un patch n'est pas automatiquement une release.
- Un **incident** est une deviation observee en exploitation, en audit ou en verification de promotion.

---

## 1. Source de verite

### 1.1 Canon

La source canonique est le **repo**.

Ordre de priorite en cas de conflit :

1. code et fichiers du repo
2. historique git
3. fichiers `_rd/`
4. memoire conversationnelle ou resume externe

La memoire peut aider a retrouver du contexte, mais ne gagne jamais contre le repo.

### 1.2 Fichiers de pilotage

Tous les fichiers de pilotage sont commites dans le repo.

```text
{project-root}/
  _rd/
    INVARIANTS.md
    METHOD.md
    EXCEPTIONS.md
    AUDIT.md
    INCIDENTS.md
    bloc-00/
      DOSSIER.md
      MANIFEST.md
      DECISIONS.md
    bloc-01/
      ...
```

---

## 2. Modes d'execution

### 2.1 Mode standard

- le plan est affiche
- la validation user est attendue avant CODER
- le reporting est fait a chaque patch

### 2.2 Mode autonome

Active seulement si le user donne explicitement une instruction du type :
- "continue sans t'arreter"
- "je te laisse gerer"
- "enchaine"

En mode autonome :
- le plan est affiche puis execute sans attente explicite
- les commits s'enchainent patch par patch
- le reporting detaille se fait en fin de bloc ou en cas de blocage

Les regles dures restent obligatoires en mode autonome.

---

## 3. Regles cardinales

1. **Repo first** : le repo est la source canonique.
2. **Un patch n'est pas une release**.
3. **Toute preuve est definie avant codage**.
4. **Tout patch a une classe de risque**.
5. **Toute exception est tracee**.
6. **Tout changement stateful a un plan de compatibilite**.
7. **Tout rollback est pense avant merge**.
8. **CHECK et SMOKE sont distincts et tous deux obligatoires**.
9. **Pas de retry sans classification de l'erreur**.
10. **Tout incident important enrichit la methode**.

---

## 4. Classes de regles

### 4.1 Regles dures

Violation interdite sauf ordre explicite du user et exception tracee :

- pas de codage avant lecture suffisante
- pas de patch sans preuve primaire et preuve de non-cassure definies
- CHECK et SMOKE obligatoires
- pas de retry aveugle
- pas de handoff ambigu
- pas de changement stateful sans plan de compatibilite ou justification explicite
- pas d'exception implicite
- pas de merge d'un patch dont le rollback n'est pas pense

### 4.2 Heuristiques fortes

A appliquer par defaut. Toute exception doit etre justifiee dans `DECISIONS.md` ou `EXCEPTIONS.md`.

- viser 1 propriete locale par patch
- viser 1 risque dominant par patch
- viser 1 smoke principal par patch
- viser 4 fichiers max par patch
- ne pas melanger DB + worker + policy + UI dans le meme patch
- toute query liste doit etre bornee, paginee ou explicitement justifiee
- toute surface testable doit avoir une preuve automatisee ciblee
- tout patch C4/C5 doit faire l'objet d'une mini-revue securite

### 4.3 Patterns d'audit

Ce sont des signaux issus de bugs reels. Ils doivent etre verifies quand ils sont pertinents, sans etre traites comme des lois aveugles.

---

## 5. Taxonomie officielle des patches

Chaque patch doit etre classe des la phase PLAN.

### C0 — Cosmétique / texte / commentaire
Blast radius quasi nul. Pas de logique runtime.

### C1 — Refactor local stateless
Changement interne borne, sans effet de contrat ni etat persistant.

### C2 — Logique applicative isolee
Changement de logique locale avec effet observable borne.

### C3 — Endpoint / service / flux integre
Touche une interaction entre composants ou une surface utilisateur/API.

### C4 — Auth / permissions / donnees client / serialization / contrats
Surface sensible. Risque securite, compatibilite ou fuite de donnees.

### C5 — Stateful critique
Schema DB, migration de donnees, workers, files, events, quotas, transitions concurrentes, jobs, cron, contrats d'evenement ou toute surface difficile a rollback.

### Effet de la classe

Plus la classe monte :
- plus la preuve minimale monte
- plus le rollback doit etre explicite
- plus l'audit requis monte
- plus la promotion doit etre graduelle

---

## 6. Evidence Ladder

Le duo CHECK/SMOKE est conserve, mais les preuves sont graduees.

### E1 — Structure locale
- syntaxe
- imports
- typecheck
- greps de coherence

### E2 — Test automatise cible
- test unitaire
- test service
- test d'integration local cible

### E3 — Scenario comportemental local
- smoke manuel ou script
- preuve observable de propriete creee

### E4 — Validation sous environnement representatif
- staging
- pre-prod
- donnees representatives ou anonymisees
- test de migration ou d'interaction inter-services

### E5 — Validation de promotion
- rollout partiel
- feature flag
- canary
- verification post-deploiement
- seuil d'arret explicite

### Minimum par classe

- C0 : E1
- C1 : E1 + E2 si testable facilement
- C2 : E1 + E2 + E3
- C3 : E1 + E2 + E3
- C4 : E1 + E2 + E3 + revue securite ciblee
- C5 : E1 + E2 + E3 + E4 + plan E5

Si une marche de preuve est impossible, il faut ouvrir une exception tracee.

---

## 7. Structure d'un bloc

### `/cycle-mkr init <bloc-id>`

Initialise un nouveau bloc.

Ordre d'execution :

1. lire la roadmap canonique
   - `corp-rd-roadmap.md` depuis le repo
2. lire l'analyse produit canonique
   - `corp-rd-product-analysis.md` depuis le repo si present
   - sinon noter explicitement l'absence
3. lire `_rd/INVARIANTS.md` si present
4. explorer le code deja suspecte d'etre touche
   - lecture entiere
   - grep dependances
5. creer le dossier du bloc
   - `_rd/bloc-{id}/DOSSIER.md`
   - `_rd/bloc-{id}/MANIFEST.md`
   - `_rd/bloc-{id}/DECISIONS.md`
6. etendre `_rd/INVARIANTS.md` si de nouveaux invariants de sous-systeme sont identifies
7. presenter le manifest
   - mode standard : attendre validation
   - mode autonome : afficher puis enchainer

---

## 8. Templates des fichiers de bloc

### 8.1 DOSSIER.md

```markdown
# Bloc {id} — {nom}

## Propriete creee
{Une seule phrase. Pas "ajouter X", mais "apres ce bloc, le systeme garantit Y".}

## Invariants a preserver
{Liste explicite de ce qui ne doit pas changer. Copier les invariants globaux + ajouter les invariants sous-systeme pertinents.}

## Surface touchee
{Sous-systemes, modeles, workers, routes, jobs, etats metier, configs, contrats — avec chemins de fichiers exacts.}

## Actifs reutilises
{Code, tables, services existants reutilises. Avec references fichier:ligne si possible.}

## Angles morts connus
{Ce qu'on sait ne pas couvrir dans ce bloc. Limites explicites.}

## Classe(s) de patch attendue(s)
{C0/C1/C2/C3/C4/C5 selon la taxonomie ci-dessus.}

## Strategie de release attendue
{Aucune / flag / canary / rollout progressif / migration expand-migrate-contract / autre.}
```

### 8.2 MANIFEST.md

```markdown
# Manifest — Bloc {id}

Etat : not_started

## Patches

P1 — {classe} — {description} — {fichiers cibles} — {preuve primaire} — {preuve non-cassure} — {preuves minimales E1..E5} — {rollback} — [ ] done
P2 — ...

## Regressions a verifier apres bloc
- [ ] Login owner fonctionne
- [ ] Login member fonctionne
- [ ] Chat agent repond
- [ ] SSE events arrivent au dashboard
- [ ] War Room demarre et conclut
- [ ] Pause instance conserve son sens
- [ ] Workers ne crashent pas au demarrage
- [ ] Admin panel accessible
{+ invariants sous-systeme specifiques}

## Release gate du bloc
- [ ] Risque d'exposition qualifie
- [ ] Strategie de promotion notee
- [ ] Signal d'arret explicite
- [ ] Plan rollback ou rollforward note

## Decouvertes de session
{Vide au depart. Rempli au fil des patches.}
```

### 8.3 DECISIONS.md

```markdown
# Decisions — Bloc {id}

## {date/heure} — {titre court}
### Contexte
{Pourquoi une decision etait necessaire}

### Options considerees
- Option A : ...
- Option B : ...

### Option retenue
{Laquelle}

### Raison
{Pourquoi}

### Consequences attendues
{Effets positifs vises}

### Consequences negatives acceptees
{Dette, cout, risque residuel}

### Impact rollback
{Facile / difficile / rollforward seulement / n/a}

### Horizon de revision
{Quand relire cette decision}
```

### 8.4 EXCEPTIONS.md

```markdown
# Exceptions

## X-{id}
- Date : {date}
- Bloc/Patch : {bloc}/{patch}
- Regle contournee : {regle}
- Raison : {pourquoi}
- Risque accepte : {risque}
- Compensation : {preuve ou controle compensatoire}
- Owner : {nom}
- Expiration : {date}
- Sortie prevue : {comment fermer l'exception}
- Statut : open|closed
```

### 8.5 INCIDENTS.md

```markdown
# Incidents et apprentissages

## I-{id} — {titre}
- Date : {date}
- Detecte par : {prod|audit|smoke|check|user}
- Symptomes : {factuels}
- Impact : {quoi, qui, combien}
- Classe de defaut : {implementation|hypothese|design|process|release|observabilite}
- Barriere manquante : {ce qui aurait du stopper}
- Correctif : {ce qui a ete change}
- Changement de methode : {nouvelle regle|pattern|checklist|test|monitoring}
- Owner : {nom}
- Statut : open|closed
```

---

## 9. Reprise de session

### `/cycle-mkr resume`

Ordre fixe, non negociable :

1. identifier le bloc en cours
   - trouver le `_rd/bloc-*/MANIFEST.md` avec `Etat : in_progress`
   - si aucun, afficher les blocs ouverts ou bloques
2. lire `DOSSIER.md`
3. lire `MANIFEST.md`
4. lire `DECISIONS.md`
5. lire `git log -1 --format="%H %s"`
6. verifier `git status --short`
7. seulement ensuite, relire le code concerne par le prochain patch
8. afficher :
   - bloc courant
   - dernier patch termine
   - prochain patch
   - classe du prochain patch
   - preuves minimales attendues
   - decouvertes notees
   - presence ou non de modifications pendantes

### Alerte resume

Si `git status` montre des modifications non commitees :
- alerte explicite
- ne pas continuer comme si l'etat etait propre
- qualifier la situation :
  - travail local legitime en cours
  - handoff non respecte
  - etat ambigu a nettoyer

---

## 10. Execution d'un patch

### `/cycle-mkr patch <P-id>`

6 phases strictement sequentielles.

### Phase 1 — LIRE

Obligatoire avant tout plan.

- lire en entier chaque fichier liste dans le patch
- grep chaque symbole qui sera modifie ou ajoute dans tout le projet
- identifier les dependances :
  - qui importe ce fichier
  - qui utilise ce type
  - qui appelle cette fonction
  - quels tests couvrent deja cette zone
  - quelles configs, jobs, events, permissions ou migrations sont touches
- relever les invariants locaux a ne pas casser
- pour les patches C4/C5, identifier aussi :
  - surfaces auth/permissions
  - donnees client
  - schema, cron, worker, queues, cache, event contracts
  - conditions de concurrence et transitions d'etat

Blocker :
- ne pas passer a PLAN si un fichier cible n'a pas ete lu
- ne pas passer a PLAN si une dependance critique n'a pas ete greppee

### Phase 2 — PLAN

Le plan doit decrire le diff attendu, pas seulement l'intention.

Obligatoire :
- classe du patch
- changement attendu concret
- risque dominant
- preuve primaire
- preuve de non-cassure
- marches de preuve minimales E1..E5
- mini-revue securite si C4/C5
- rollback prevu
- si C5 : strategie stateful et compatibilite
- si exposition reelle necessaire : note release gate

Optionnel mais recommande :
- option alternative ecartee
- raison du choix

Template :

```markdown
## Plan patch {P-id}

### Classe
{C0|C1|C2|C3|C4|C5}

### Diff attendu
- fichier A : ...
- fichier B : ...

### Risque dominant
{regression auth / race condition / schema mismatch / UI stale state / compatibilite / autre}

### Preuve primaire
{Scenario observable prouvant que la propriete existe}

### Preuve de non-cassure
{Scenario prouvant que l'invariant tient}

### Evidence Ladder minimale
- E1 : ...
- E2 : ...
- E3 : ...
- E4 : ...
- E5 : ...

### Securite
{n/a ou revue ciblee}

### Rollback prevu
{restore local / revert commit / rollout stop / rollforward / autre}

### Stateful
{n/a ou expand -> migrate -> switch -> contract}

### Option ecartee
{si utile}
```

En mode standard :
- afficher le plan
- attendre validation user

En mode autonome :
- afficher le plan
- enchainer directement

### Phase 3 — CODER

- implementer exactement le diff planifie
- rester dans le blast radius defini
- ne pas improviser de changements non planifies

Si un cas imprevu apparait :
1. STOP
2. evaluer si cela change le plan
3. si oui :
   - noter dans `DECISIONS.md`
   - ajuster le plan
   - informer le user
4. si non :
   - continuer
   - noter si necessaire dans `Decouvertes de session`

### Phase 4 — CHECK

CHECK = verification structurelle. CHECK ne prouve pas le comportement.

Minimum obligatoire :

**Python / FastAPI**
```bash
python3 -m py_compile {fichier_modifie}
python3 -c "from main import app; print('OK')"
```

**TypeScript / Next.js**
```bash
./node_modules/.bin/tsc --noEmit
```

Grep de coherence :
- grep chaque symbole ajoute, renomme ou supprime dans tout le projet
- verifier imports
- verifier usages dependants
- verifier qu'aucun fichier adjacent n'est casse

Preuves automatisees :
- executer E1
- executer E2 si requise par la classe
- preparer E3 si applicable
- pour C5, verifier que le plan stateful reste coherent

Rapport CHECK :
- PASS
- FAIL, avec raison precise

Si CHECK echoue :
- passer a `/cycle-mkr error`

### Phase 5 — SMOKE

SMOKE = verification comportementale. SMOKE prouve que la propriete demandee existe reellement.

Obligatoire :
- executer la preuve primaire du manifest
- executer la preuve de non-cassure
- rendre le resultat attendu explicite et observable

Exemples valides :
- `curl -X POST ...` retourne `200` avec structure attendue
- scenario paused n'envoie rien
- event publie et visible au dashboard
- guard visible et activable dans le flux reel

Exemples invalides :
- "le typecheck passe donc c'est bon"
- "j'ai relu le code"
- "ca devrait marcher"

Si SMOKE echoue :
- passer a `/cycle-mkr error`

### Phase 6 — COMMIT

Seulement si CHECK + SMOKE = PASS.

```bash
git add {fichiers du patch uniquement}
git commit -m "{message decrivant la propriete creee}"
```

Puis mettre a jour `MANIFEST.md` :
- cocher `[x] done`
- noter les decouvertes
- si dernier patch du bloc :
  - `Etat : done`
  - lancer les regressions du bloc

Un patch `done` n'est pas automatiquement `promotable`.

---

## 11. Protocole stateful

Tout patch C5 suit ce protocole sauf justification explicite contraire.

### 11.1 Sequence recommandee

1. **Expand**
   - ajouter schema, colonne, index, champ ou contrat compatible
   - conserver l'ancien chemin utilisable
2. **Migrate**
   - backfill ou transition progressive
   - mesurer, verifier, journaliser
3. **Switch**
   - activer la nouvelle voie
   - garder retour arriere si possible
4. **Contract**
   - retirer l'ancien chemin seulement apres stabilisation

### 11.2 Si compatibilite impossible

Le plan doit ecrire explicitement :
- pourquoi l'approche compatible n'est pas possible
- quel est le vrai risque
- si le rollback est impossible
- quel rollforward est prevu
- quelle exception couvre cette situation

### 11.3 Statefulness a identifier systematiquement

- schema DB
- migrations de donnees
- RLS et GRANT
- workers et cron
- queues et retries
- events et SSE
- contrats API et serialisation
- quotas et compteurs
- cache et invalidation
- tokens derives
- transitions concurrentes

---

## 12. Release gate

### `/cycle-mkr release`

Le release gate est distinct du patch gate. Il ne se lance qu'apres completion du patch ou du bloc concerne.

Questions obligatoires :

1. le changement est-il reversible ?
2. s'il ne l'est pas, le rollforward est-il defini ?
3. le changement touche-t-il un etat persistant ?
4. peut-il etre cache derriere un flag ?
5. peut-il etre canarie ou expose progressivement ?
6. quel signal stoppe la promotion ?
7. quel signal autorise l'elargissement ?
8. quel runbook s'applique si l'exposition partielle echoue ?
9. quel monitoring ou log prouve que la release est saine ?
10. quelle exception ouvrir si une marche E4/E5 manque ?

### Sorties possibles du release gate

- **promotable**
- **promotable avec garde-fous**
- **non promotable**

### Promotion minimale par classe

- C0-C1 : souvent pas de release gate fort si aucune exposition runtime
- C2-C3 : promotion normale avec verification post-deploiement
- C4 : promotion avec garde-fous et verification securite
- C5 : promotion graduelle, canary/flag si possible, stop signal obligatoire, plan rollforward obligatoire si rollback dur

---

## 13. CHECK seul

### `/cycle-mkr check`

Lance uniquement la phase CHECK.

Execute :
1. `py_compile` sur les `.py` modifies
2. import check `from main import app`
3. `tsc --noEmit` si TS touche
4. grep de coherence sur les symboles modifies
5. test automatise cible si applicable
6. verification du plan stateful si C5
7. rapport PASS ou FAIL

---

## 14. SMOKE seul

### `/cycle-mkr smoke`

Lance uniquement la phase SMOKE.

Execute :
1. lire le manifest pour trouver le patch en cours
2. executer la preuve primaire
3. executer la preuve de non-cassure
4. rapport PASS ou FAIL

---

## 15. Protocole d'erreur

### `/cycle-mkr error`

Sequence stricte :

1. STOP
2. relire le fichier entier
3. grep les dependances du symbole en erreur
4. comparer l'etat actuel au patch planifie
5. classifier l'erreur

Classes d'erreur :
- **a) Erreur locale d'implementation**
  - typo, oubli d'import, syntaxe, nom incorrect
- **b) Mauvaise hypothese sur dependance**
  - fonction appelee ne fait pas ce qu'on croyait
  - type ou contrat reel different
- **c) Patch trop large**
  - trop de modifications coulees ensemble
  - blast radius mal controle
- **d) Plan faux**
  - le diff planifie ne peut pas fonctionner tel quel
- **e) Environnement / outillage**
  - commande incorrecte, container absent, script manquant, fixture invalide
- **f) Release / state mismatch**
  - le patch marche localement mais casse sous etat reel, donnees reelles, ordre de jobs, concurrence ou exposition progressive

6. afficher la classification au user
7. faire une seconde tentative maximum
8. si nouvel echec :
   - revert du patch
   - marquer le patch `blocked`
   - noter la cause dans `DECISIONS.md`
   - ouvrir une entree d'incident ou d'exception si utile
   - proposer une re-scission

Regle critique :
La classification est obligatoire. Pas de retry aveugle.

---

## 16. Strategie de rollback

Le rollback depend de l'etat du patch.

### Cas 1 — Modifications locales non commitees
```bash
git restore {fichiers_du_patch}
```

### Cas 2 — Patch commite localement mais non pousse
- preferer `git revert <commit>` si le commit a deja servi de point de reference
- sinon reset local seulement si cela ne rend pas l'historique ambigu

### Cas 3 — Patch deja pousse / partage
- utiliser `git revert <commit>`
- ne pas rewriter l'historique partage sauf consigne explicite

### Cas 4 — Changement stateful ou irreversibilite partielle
- documenter que le rollback de code seul ne suffit pas
- definir un rollforward
- ouvrir une exception si necessaire
- ne jamais faire semblant qu'un revert git restaure l'etat persistant

Le rollback choisi doit etre note si le patch devient `blocked` ou si la release est stoppee.

---

## 17. Handoff de session

### `/cycle-mkr handoff`

Termine proprement une session.

Ordre :

1. verifier `git status`
2. si fichiers non commites :
   - commit propre
   - ou revert
   - ou stash si explicitement justifie
3. mettre a jour `MANIFEST.md`
   - etat des patches
   - prochain patch
   - decouvertes
4. mettre a jour `DECISIONS.md` si arbitrages
5. fermer ou mettre a jour `EXCEPTIONS.md` si necessaire
6. rapport au user :
   - patches termines
   - patches restants
   - blocages
   - exceptions ouvertes
   - prochaine action recommandee

Conditions de sortie obligatoires :

- [ ] aucun code modifie non commite, sauf stash explicitement note
- [ ] manifest a jour
- [ ] decisions a jour si necessaire
- [ ] exceptions a jour si necessaire
- [ ] aucun patch en etat ambigu

---

## 18. Status

### `/cycle-mkr status`

Affiche l'etat courant sans rien modifier.

1. trouver tous les `_rd/bloc-*/MANIFEST.md`
2. pour chaque bloc :
   - etat
   - nombre de patches done / total
   - dernier patch termine
   - prochain patch
   - classes de patch restantes
3. verifier `git status`
4. lister les exceptions ouvertes
5. afficher un resume synthetique

---

## 19. Exceptions

### `/cycle-mkr exception`

Utiliser cette commande quand une regle doit etre contournee de facon explicite.

Ordre :
1. identifier la regle contournee
2. ecrire pourquoi elle ne peut pas etre respectee ici
3. nommer le risque accepte
4. nommer les controles compensatoires
5. nommer un owner
6. fixer une expiration
7. definir une sortie prevue
8. ecrire l'entree dans `_rd/EXCEPTIONS.md`

Regle :
Une exception non tracee = violation de protocole.

---

## 20. Incident et apprentissage

### `/cycle-mkr incident`

A utiliser apres incident notable, audit critique, patch bloque recurrent ou echec de release.

Ordre :
1. decrire les faits, pas les opinions
2. qualifier l'impact
3. classer le defaut
4. identifier la barriere manquante
5. ecrire le correctif applique
6. decider si la methode doit etre enrichie par :
   - nouvelle regle
   - nouveau pattern
   - nouvelle checklist
   - nouveau smoke
   - nouveau test
   - nouvelle instrumentation
7. noter le changement dans `_rd/METHOD.md`
8. si utile, etendre `_rd/INVARIANTS.md`
9. enregistrer l'entree dans `_rd/INCIDENTS.md`

Objectif : chaque incident important doit laisser une barriere de prevention plus forte qu'avant.

---

## 21. Audit multi-rounds

### `/cycle-mkr audit`

Objectif : ramener les findings CRITICAL/HIGH a zero.

A declencher :
- apres chaque serie de 3 a 5 blocs
- ou en fin de roadmap
- ou avant une phase de stabilisation ou deploy majeur

### 21.1 Deux modes d'audit

#### Mode A — audit parallele
Si plusieurs agents sont disponibles, couvrir plusieurs domaines en parallele.

#### Mode B — audit sequentiel
Si un seul operateur/agent est disponible, simuler les domaines par passes successives. Ce mode est valide. L'important est la separation des angles d'analyse.

### 21.2 Domaines d'analyse

| Agent/Pass | Domaine | Ce qu'il cherche |
|---|---|---|
| A1 | Routers / endpoints | permissions manquantes, ordering, validation UUID, erreurs HTTP |
| A2 | Services / workers | race conditions, dead code, leaks, error handling |
| A3 | Models / DB | contraintes, FK, indexes, RLS, data integrity |
| A4 | Frontend / flows | stale state, busy locks, NaN, cleanup, optimistic rollback |
| A5 | Cross-cutting | auth end-to-end, SSE, JSON serialization, quotas, event flows |
| A6 | Live tests | smoke reels, curl, logs, DB verification si environnement dispo |

### 21.3 Regles de lecture

Chaque agent/pass :
- lit les fichiers en entier
- cite fichier + ligne si possible
- donne severite
- donne correction proposee
- ne remonte que des bugs fonctionnels, de securite ou de fiabilite

### 21.4 Correction par severite

Dans un round :
1. corriger d'abord CRITICAL
2. puis HIGH
3. ne pas corriger MEDIUM/LOW dans le meme round sauf raison explicite

Apres chaque fix :
- relire le fichier entier
- CHECK
- grep dependances

### 21.5 Commit et round suivant

1. `git add` des seuls fichiers modifies
2. `git commit -m "audit R{N}: {description}"`
3. re-CHECK complet
4. lancer round suivant

### 21.6 Elargissement obligatoire entre rounds

Ne pas analyser le meme angle deux rounds de suite.

Progression typique :
- Round 1 : permissions, route ordering, surface evidente
- Round 2 : error handling, null guards, race conditions
- Round 3 : workers, SSE, data integrity, frontend state leaks
- Round 4+ : end-to-end, edge cases, cross-service dependencies

### 21.7 Condition d'arret

L'audit s'arrete quand un round complet retourne :
- 0 finding CRITICAL
- 0 finding HIGH

Les MEDIUM/LOW restants sont notes dans `_rd/AUDIT.md`.

### 21.8 Rapport final

```markdown
# Audit Report — {date}

## Rounds executes : {N}
## Findings total : {count} (CRITICAL: X, HIGH: Y, MEDIUM: Z, LOW: W)
## Fixes appliques : {count}
## Dette residuelle : {count MEDIUM/LOW}

## Corrections par round
- R1 : ...
- R2 : ...
- RN : 0 CRITICAL/HIGH -> audit termine
```

---

## 22. Mini-revue securite obligatoire pour C4/C5

Pour tout patch touchant :
- auth
- permissions
- tokens
- endpoints client
- serialisation
- RLS
- donnees client
- integrations

Verifier explicitement :
- validation d'entree
- controle d'autorisation
- fuite de donnees possibles
- propagation correcte des roles et permissions
- traces et auditabilite
- secret handling
- compatibilite de contrat et securite des payloads

Si un de ces axes n'est pas evalue, ouvrir une exception.

---

## 23. Matrice d'invariants globaux

A verifier apres chaque bloc termine.

```text
INVARIANTS GLOBAUX
- [ ] Login owner fonctionne
- [ ] Login member fonctionne
- [ ] Chat agent repond (POST /client/chat/{agent_id} -> 200)
- [ ] SSE events arrivent au dashboard
- [ ] War Room demarre et conclut
- [ ] Pause instance conserve son sens
- [ ] 4 workers demarrent sans crash
- [ ] Admin panel accessible

INVARIANTS SOUS-SYSTEME (si touche)
- Outreach : envoi, tracking, sequences, statuts
- Coordination : start, cancel, timeout, synthese
- Quotas : refus, consommation, plan, page usage
- Auth : owner login, member login, refresh, permissions
- Scheduling : crons executent, self-scheduling, templates
- Checkpoints : creation, approbation, rejet, expiration
- Integrations : connect, disconnect, execute_action
```

---

## 24. Metriques du protocole

Suivre au minimum :
- taille mediane des patches
- taux de patches bloques
- temps median de reprise de session
- taux de rollback par classe de patch
- incidents lies a changements recents
- pourcentage de patches C4/C5 avec Evidence Ladder complete
- delai moyen entre incident et ajout d'une barriere methodologique

Le but n'est pas seulement d'etre rigoureux, mais de verifier que la rigueur ameliore reellement la fiabilite.

---

## 25. Patterns appris en production

Ces patterns viennent de bugs reels. Ils doivent etre verifies quand la surface touchee les rend pertinents.

### P1 — `python3` et non `python`
Toujours utiliser `python3` pour CHECK et scripts Python.

### P2 — Route ordering FastAPI
Les routes fixes doivent preceder les routes parametrees sous le meme prefixe.

### P3 — Migration SQL manuelle documentee
Le patch code peut creer le modele, mais la migration SQL et les policies associees doivent etre documentees explicitement dans le patch et executees lors du deploy si le workflow du projet l'exige.

### P4 — Deploy API documente
Le protocole d'implementation ne remplace pas le protocole de deploy. Tout bloc qui change l'API doit noter le workflow de deploy si necessaire.

### P5 — Permission checks sur `client.py`
Chaque endpoint client doit verifier `_require_client(token)`, `require_permission(...)` et `_get_instance(...)`.

### P6 — Validation UUID des path params
Tout path param string utilise comme UUID dans une query doit etre valide explicitement avant appel DB.

### P7 — `flag_modified` pour JSONB
Les mutations in-place JSONB doivent etre marquees pour SQLAlchemy.

### P8 — Sync modele / DB pour les contraintes
Les `CheckConstraint` ORM ne suffisent pas si la DB a deja une contrainte divergente.

### P9 — Audit multi-rounds
L'audit doit elargir les axes entre rounds.

### P10 — Mode autonome
Le mode autonome n'annule jamais les regles dures.

### P11 — JSON serialization safety
Avant `json.dumps`, coercer UUID/datetime/Decimal/set si le payload vient de la DB.

### P12 — Expired state guard
Tout objet avec TTL ou `expires_at` doit etre verifie avant action.

### P13 — Reassign des FK avant delete
En merge ou remplacement d'entite, reassigner les dependances avant suppression.

### P14 — Frontend state cleanup
Tout state bloquant doit etre reset sur close, catch et cleanup.

### P15 — NaN propagation
Toute conversion numerique d'input doit avoir un fallback explicite.

### P16 — `admin_tx()` pour `publish_event()` en background
Ne pas utiliser une session admin nue si les events doivent etre flushes apres commit.

### P17 — Check statut membre dans toute dependance auth
Toute dependance auth derivant un token utilisable doit verifier le statut du membre.

### P18 — `FOR UPDATE` sur check-then-modify
Toute transition de statut concurrente doit locker explicitement.

### P19 — Rollback optimiste par ID
En frontend, retirer l'entite ajoutee par identifiant, jamais par position.

### P20 — Guard synchrone via `useRef`
Dans les handlers async frontend, le guard doit etre synchrone si double submit possible.

### P21 — Propager role / permissions dans les tokens derives
SSE, webhook, tokens derives : ne jamais perdre le contexte auth.

### P22 — `ForeignKey(..., ondelete="CASCADE")` sur `instance_id`
Tout modele rattache a une instance doit exprimer proprement sa contrainte relationnelle.

### P23 — `onupdate` sur `updated_at`
Ne pas laisser un `updated_at` fige a l'insert si la table evolue ensuite.

### P24 — `server_default` sur JSONB si ecriture hors ORM possible
Fortement recommande si la colonne peut etre creee ou alimentee hors ORM.

### P25 — Query liste bornee
Toute query liste doit etre limitee, paginee ou explicitement justifiee.

### P26 — Reset des etats d'erreur avant refetch
Un refetch doit repartir d'un etat visuel propre.

### P27 — Valider le statut source avant transition
Toute state machine doit verifier le statut courant avant mutation.

### P28 — RLS + GRANT sur les nouvelles tables client
Toute table accessible a `corp_user` doit definir explicitement sa politique d'acces.

### P29 — Redis publish protege en boucle critique
Toute publication Redis dans une boucle critique doit etre protegee par un `try/except`.

---

## 26. Rappel court

1. lire avant de planifier
2. planifier avant de coder
3. definir les preuves avant implementation
4. classer le patch
5. CHECK n'est pas SMOKE
6. patch done n'est pas release done
7. classifier avant retry
8. tracer toute exception
9. traiter explicitement le stateful
10. faire en sorte que chaque incident renforce la methode

---

## 27. Critere de qualite d'un patch

Un patch est bon si :
- sa propriete locale est claire
- son blast radius est borne
- sa classe est correcte
- son Evidence Ladder minimale est satisfaite
- sa preuve primaire est observable
- sa preuve de non-cassure est credible
- son rollback ou rollforward est compris
- sa session peut reprendre sans interpretation orale
- sa promotion est gouvernee selon le risque reel
